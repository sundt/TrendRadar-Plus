// PublishBridge - 网页与插件的通信桥
// 注入到 hot.uihash.com 编辑器页面，处理发布请求

(function() {
  'use strict';

  // 只在 HotNews 域名下运行
  const hostname = window.location.hostname;
  if (!hostname.includes('uihash.com') && 
      !hostname.includes('localhost') &&
      !hostname.startsWith('127.') &&
      !hostname.startsWith('192.168.')) {
    return;
  }

  // 避免重复注入
  if (window.__HOTNEWS_PUBLISH_BRIDGE__) {
    return;
  }
  window.__HOTNEWS_PUBLISH_BRIDGE__ = true;

  console.log('[PublishBridge] 初始化...');

  /**
   * 发送响应到网页
   */
  function sendResponse(action, success, data, error) {
    window.postMessage({
      type: 'HOTNEWS_PUBLISH_RESPONSE',
      action,
      success,
      data: data || null,
      error: error || null
    }, '*');
  }

  /**
   * 处理来自网页的消息
   */
  async function handleMessage(event) {
    // 只处理来自同源的消息
    if (event.source !== window) return;
    if (event.data?.type !== 'HOTNEWS_PUBLISH') return;

    const { action, payload } = event.data;
    console.log('[PublishBridge] 收到消息:', action, payload);

    try {
      switch (action) {
        case 'check_installed':
          // 检查插件是否安装
          const installResult = await chrome.runtime.sendMessage({
            type: 'PUBLISH_CHECK_INSTALLED'
          });
          sendResponse(action, true, installResult.data);
          break;

        case 'check_login':
          // 检查平台登录状态
          const loginResult = await chrome.runtime.sendMessage({
            type: 'PUBLISH_CHECK_LOGIN',
            platforms: payload.platforms
          });
          sendResponse(action, loginResult.success, loginResult.data, loginResult.error);
          break;

        case 'publish':
          // 发布文章
          const publishResult = await chrome.runtime.sendMessage({
            type: 'PUBLISH_ARTICLE',
            platforms: payload.platforms,
            articleData: payload.data
          });
          sendResponse(action, publishResult.success, publishResult.data, publishResult.error);
          break;

        case 'get_status':
          // 获取发布状态
          const statusResult = await chrome.runtime.sendMessage({
            type: 'PUBLISH_GET_STATUS',
            taskId: payload.taskId
          });
          sendResponse(action, statusResult.success, statusResult.data);
          break;

        case 'cancel':
          // 取消发布
          await chrome.runtime.sendMessage({
            type: 'PUBLISH_CANCEL',
            taskId: payload.taskId
          });
          sendResponse(action, true);
          break;

        case 'get_pending_content':
          // 获取从右键菜单传递的内容
          const storageResult = await chrome.storage.local.get(['pendingEditorContent']);
          if (storageResult.pendingEditorContent) {
            const content = storageResult.pendingEditorContent;
            // 清除已读取的内容
            await chrome.storage.local.remove(['pendingEditorContent']);
            sendResponse(action, true, content);
          } else {
            sendResponse(action, false, null, '没有待导入的内容');
          }
          break;

        default:
          sendResponse(action, false, null, `未知操作: ${action}`);
      }
    } catch (error) {
      console.error('[PublishBridge] 处理消息失败:', error);
      sendResponse(action, false, null, error.message || '通信失败');
    }
  }

  // 监听网页消息
  window.addEventListener('message', handleMessage);

  // 通知网页插件已就绪
  setTimeout(() => {
    sendResponse('ready', true, {
      version: chrome.runtime.getManifest().version,
      supportedPlatforms: ['zhihu', 'juejin', 'csdn', 'weixin']
    });
  }, 100);

  console.log('[PublishBridge] 初始化完成');
})();
