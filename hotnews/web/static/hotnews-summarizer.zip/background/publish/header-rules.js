// HeaderRules - 动态请求头规则管理
// 使用 declarativeNetRequest API 修改请求头，绕过 CORS 限制

/**
 * Header 规则管理器
 * 参考 Wechatsync 的 RuntimeInterface.headerRules 实现
 */
export class HeaderRulesManager {
  constructor() {
    this.ruleIdCounter = 1000; // 从 1000 开始，避免与其他规则冲突
    this.activeRules = new Map(); // ruleId -> rule info
  }

  /**
   * 添加请求头规则
   * @param {Object} rule - 规则配置
   * @param {string} rule.urlFilter - URL 匹配模式
   * @param {Object} rule.headers - 要设置的请求头
   * @param {string[]} [rule.resourceTypes] - 资源类型，默认 ['xmlhttprequest']
   * @returns {Promise<string>} 规则 ID
   */
  async add(rule) {
    const ruleId = this.ruleIdCounter++;
    
    const requestHeaders = Object.entries(rule.headers).map(([header, value]) => ({
      header,
      operation: 'set',
      value
    }));

    const dynamicRule = {
      id: ruleId,
      priority: 1,
      action: {
        type: 'modifyHeaders',
        requestHeaders
      },
      condition: {
        urlFilter: rule.urlFilter,
        resourceTypes: rule.resourceTypes || ['xmlhttprequest']
      }
    };

    try {
      await chrome.declarativeNetRequest.updateDynamicRules({
        addRules: [dynamicRule]
      });
      
      this.activeRules.set(String(ruleId), {
        ...rule,
        id: ruleId,
        createdAt: Date.now()
      });
      
      console.log('[HeaderRules] Added rule:', ruleId, rule.urlFilter);
      return String(ruleId);
    } catch (error) {
      console.error('[HeaderRules] Failed to add rule:', error);
      throw error;
    }
  }

  /**
   * 移除请求头规则
   * @param {string} ruleId - 规则 ID
   */
  async remove(ruleId) {
    const numericId = Number(ruleId);
    
    try {
      await chrome.declarativeNetRequest.updateDynamicRules({
        removeRuleIds: [numericId]
      });
      
      this.activeRules.delete(ruleId);
      console.log('[HeaderRules] Removed rule:', ruleId);
    } catch (error) {
      console.error('[HeaderRules] Failed to remove rule:', error);
      throw error;
    }
  }

  /**
   * 清除所有规则
   */
  async clear() {
    const ruleIds = Array.from(this.activeRules.keys()).map(Number);
    
    if (ruleIds.length === 0) return;
    
    try {
      await chrome.declarativeNetRequest.updateDynamicRules({
        removeRuleIds: ruleIds
      });
      
      this.activeRules.clear();
      console.log('[HeaderRules] Cleared all rules');
    } catch (error) {
      console.error('[HeaderRules] Failed to clear rules:', error);
      throw error;
    }
  }

  /**
   * 获取当前活动的规则数量
   */
  getActiveCount() {
    return this.activeRules.size;
  }
}

// 导出单例
export const headerRules = new HeaderRulesManager();
