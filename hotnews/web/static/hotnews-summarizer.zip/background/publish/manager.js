// PublishManager - 发布流程管理器
// 负责协调多平台发布流程

import { ZhihuAdapter } from './adapters/zhihu.js';
import { JuejinAdapter } from './adapters/juejin.js';
import { CsdnAdapter } from './adapters/csdn.js';
import { WeixinAdapter } from './adapters/weixin.js';
import { JianshuAdapter } from './adapters/jianshu.js';

/**
 * 发布任务状态
 */
const TaskStatus = {
  PENDING: 'pending',
  RUNNING: 'running',
  SUCCESS: 'success',
  FAILED: 'failed',
  CANCELLED: 'cancelled'
};

/**
 * 发布管理器
 */
export class PublishManager {
  constructor() {
    this.adapters = {};
    this.tasks = new Map(); // taskId -> task info
    this.loadAdapters();
  }

  /**
   * 加载所有平台适配器
   */
  loadAdapters() {
    this.adapters = {
      zhihu: new ZhihuAdapter(),
      juejin: new JuejinAdapter(),
      csdn: new CsdnAdapter(),
      weixin: new WeixinAdapter(),
      jianshu: new JianshuAdapter()
    };
  }

  /**
   * 获取支持的平台列表
   */
  getSupportedPlatforms() {
    return Object.entries(this.adapters).map(([key, adapter]) => ({
      id: key,
      name: adapter.displayName,
      icon: adapter.icon || null,
      limits: adapter.limits || {}
    }));
  }

  /**
   * 发布文章到多个平台
   * @param {string[]} platforms - 平台列表
   * @param {Object} articleData - 文章数据
   * @returns {Promise<Object>} 发布结果
   */
  async publish(platforms, articleData) {
    const taskId = this.generateTaskId();
    const results = [];

    // 初始化任务
    this.tasks.set(taskId, {
      id: taskId,
      status: TaskStatus.RUNNING,
      platforms,
      results: [],
      startedAt: Date.now()
    });

    for (const platform of platforms) {
      const adapter = this.adapters[platform];
      
      if (!adapter) {
        results.push({
          platform,
          status: TaskStatus.FAILED,
          error: { code: 'UNSUPPORTED', message: '不支持的平台' }
        });
        continue;
      }

      // 检查任务是否被取消
      const task = this.tasks.get(taskId);
      if (task?.status === TaskStatus.CANCELLED) {
        results.push({
          platform,
          status: TaskStatus.CANCELLED,
          error: { code: 'CANCELLED', message: '发布已取消' }
        });
        continue;
      }

      try {
        // 验证文章数据
        const validationErrors = this.validateForPlatform(platform, articleData);
        if (validationErrors.length > 0) {
          results.push({
            platform,
            status: TaskStatus.FAILED,
            error: { 
              code: 'VALIDATION_ERROR', 
              message: validationErrors.join('; '),
              retryable: false
            }
          });
          continue;
        }

        // 执行发布
        const result = await this.publishToPlatform(adapter, articleData);
        
        // 检查是否有错误
        if (result.error) {
          results.push({
            platform,
            status: TaskStatus.FAILED,
            tabId: result.tabId,
            error: {
              code: 'INJECT_ERROR',
              message: result.error,
              retryable: false
            }
          });
        } else {
          // 脚本已注入，视为成功（用户需要手动检查）
          results.push({
            platform,
            status: TaskStatus.SUCCESS,
            tabId: result.tabId,
            url: result.url,
            message: result.message || '内容已填充，请检查后手动发布'
          });
        }

      } catch (error) {
        console.error(`[PublishManager] 发布到 ${platform} 失败:`, error);
        results.push({
          platform,
          status: TaskStatus.FAILED,
          error: {
            code: error.code || 'PUBLISH_ERROR',
            message: error.message || '发布失败',
            retryable: error.retryable !== false
          }
        });
      }
    }

    // 更新任务状态
    const task = this.tasks.get(taskId);
    if (task) {
      task.results = results;
      task.status = results.every(r => r.status === TaskStatus.SUCCESS) 
        ? TaskStatus.SUCCESS 
        : TaskStatus.FAILED;
      task.completedAt = Date.now();
    }

    return { taskId, results };
  }

  /**
   * 发布到单个平台
   * 优先使用 API 方式，降级使用 DOM 注入
   */
  async publishToPlatform(adapter, articleData) {
    console.log('[PublishManager] 开始发布到:', adapter.name);
    
    // 检查适配器是否支持 API 方式发布
    if (typeof adapter.publish === 'function') {
      console.log('[PublishManager] 使用 API 方式发布');
      
      try {
        const result = await adapter.publish(articleData);
        
        if (result.success) {
          // API 发布成功，打开编辑页面
          if (result.postUrl) {
            const tab = await chrome.tabs.create({
              url: result.postUrl,
              active: true
            });
            return {
              tabId: tab.id,
              url: result.postUrl,
              postId: result.postId,
              message: result.message || '草稿已创建，请检查后发布'
            };
          }
          return {
            url: result.postUrl,
            postId: result.postId,
            message: result.message || '发布成功'
          };
        } else {
          // API 发布失败，尝试降级到 DOM 注入
          console.log('[PublishManager] API 发布失败，尝试 DOM 注入:', result.error);
          return await this.publishViaDomInjection(adapter, articleData);
        }
      } catch (error) {
        console.error('[PublishManager] API 发布出错，尝试 DOM 注入:', error);
        return await this.publishViaDomInjection(adapter, articleData);
      }
    }
    
    // 没有 publish 方法，使用 DOM 注入
    return await this.publishViaDomInjection(adapter, articleData);
  }

  /**
   * 通过 DOM 注入方式发布（降级方案）
   */
  async publishViaDomInjection(adapter, articleData) {
    console.log('[PublishManager] 使用 DOM 注入方式发布');
    
    // 创建新标签页
    const tab = await chrome.tabs.create({
      url: adapter.editUrl,
      active: true
    });
    
    console.log('[PublishManager] 标签页已创建:', tab.id, tab.url);

    try {
      // 等待页面加载完成
      await this.waitForTabLoad(tab.id, 30000);
      console.log('[PublishManager] 页面加载完成');

      // 额外等待确保页面 JS 初始化
      await new Promise(resolve => setTimeout(resolve, 3000));

      // 注入发布脚本
      if (adapter.injectScript) {
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: adapter.injectScript,
          args: [articleData]
        });
        
        console.log('[PublishManager] 脚本已注入');
        
        // 等待脚本执行
        await new Promise(resolve => setTimeout(resolve, 5000));
      }

      return {
        tabId: tab.id,
        url: null,
        message: '内容已填充，请检查后手动发布'
      };

    } catch (error) {
      console.error('[PublishManager] DOM 注入出错:', error);
      return {
        tabId: tab?.id,
        url: null,
        error: error.message || '发布失败'
      };
    }
  }

  /**
   * 等待标签页加载完成
   */
  waitForTabLoad(tabId, timeout = 30000) {
    return new Promise((resolve, reject) => {
      const timeoutId = setTimeout(() => {
        chrome.tabs.onUpdated.removeListener(listener);
        reject(new Error('页面加载超时'));
      }, timeout);

      const listener = (id, info) => {
        if (id === tabId && info.status === 'complete') {
          clearTimeout(timeoutId);
          chrome.tabs.onUpdated.removeListener(listener);
          // 额外等待一小段时间确保 JS 执行完毕
          setTimeout(resolve, 500);
        }
      };

      chrome.tabs.onUpdated.addListener(listener);
    });
  }

  /**
   * 验证文章数据是否符合平台要求
   */
  validateForPlatform(platform, articleData) {
    const adapter = this.adapters[platform];
    if (!adapter) return ['不支持的平台'];

    const errors = [];
    const limits = adapter.limits || {};

    // 标题验证
    if (!articleData.title?.trim()) {
      errors.push('标题不能为空');
    } else if (limits.titleMax && articleData.title.length > limits.titleMax) {
      errors.push(`${adapter.displayName} 标题不能超过 ${limits.titleMax} 字`);
    }

    // 内容验证
    if (!articleData.htmlContent?.trim()) {
      errors.push('内容不能为空');
    }

    // 封面验证
    if (limits.coverRequired && !articleData.cover?.url) {
      errors.push(`${adapter.displayName} 需要设置封面`);
    }

    return errors;
  }

  /**
   * 获取任务状态
   */
  getStatus(taskId) {
    return this.tasks.get(taskId) || null;
  }

  /**
   * 取消发布任务
   */
  cancel(taskId) {
    const task = this.tasks.get(taskId);
    if (task && task.status === TaskStatus.RUNNING) {
      task.status = TaskStatus.CANCELLED;
    }
  }

  /**
   * 生成任务 ID
   */
  generateTaskId() {
    return `pub_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  }
}
