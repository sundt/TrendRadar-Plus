// BaseAdapter - 平台适配器基类
// 定义所有平台适配器的通用接口

/**
 * 平台适配器基类
 * 所有平台适配器都应继承此类
 */
export class BaseAdapter {
  /** 平台标识 */
  name = '';
  
  /** 平台显示名称 */
  displayName = '';
  
  /** 编辑器页面 URL */
  editUrl = '';
  
  /** 平台图标 URL */
  icon = '';
  
  /** 平台限制 */
  limits = {
    titleMax: 100,
    coverRequired: false
  };

  /**
   * 检查登录状态
   * @returns {Promise<{isLoggedIn: boolean}>}
   */
  async checkLogin() {
    throw new Error('子类必须实现 checkLogin 方法');
  }

  /**
   * 注入脚本（在目标页面执行）
   * 此方法会被序列化后在目标页面执行，不能使用外部变量
   * @param {Object} articleData - 文章数据
   * @returns {Promise<{success: boolean, url?: string, error?: string}>}
   */
  static injectScript(articleData) {
    throw new Error('子类必须实现 injectScript 方法');
  }
}

/**
 * 等待元素出现的工具函数
 * 此函数会被注入到目标页面，所以定义为独立函数
 */
export function waitForElement(selector, timeout = 10000) {
  return new Promise((resolve, reject) => {
    const el = document.querySelector(selector);
    if (el) return resolve(el);

    const observer = new MutationObserver(() => {
      const el = document.querySelector(selector);
      if (el) {
        observer.disconnect();
        resolve(el);
      }
    });

    observer.observe(document.body, { childList: true, subtree: true });

    setTimeout(() => {
      observer.disconnect();
      reject(new Error(`等待元素 ${selector} 超时`));
    }, timeout);
  });
}

/**
 * 模拟输入的工具函数
 */
export function simulateInput(element, value) {
  element.focus();
  element.value = value;
  element.dispatchEvent(new Event('input', { bubbles: true }));
  element.dispatchEvent(new Event('change', { bubbles: true }));
}

/**
 * 模拟粘贴 HTML 内容
 */
export function simulatePasteHtml(element, html) {
  element.focus();
  
  // 尝试使用 execCommand
  if (document.queryCommandSupported('insertHTML')) {
    document.execCommand('insertHTML', false, html);
    return true;
  }
  
  // 备选：直接设置 innerHTML
  if (element.contentEditable === 'true') {
    element.innerHTML = html;
    element.dispatchEvent(new Event('input', { bubbles: true }));
    return true;
  }
  
  return false;
}

/**
 * 延迟函数
 */
export function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
