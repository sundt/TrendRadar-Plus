// WeixinAdapter - 微信公众号适配器
// 参考 MultiPost-Extension 实现，使用 API 方式发布

import { BaseAdapter } from './base.js';

/**
 * 微信公众号适配器
 * 使用微信公众号 API 直接创建草稿
 */
export class WeixinAdapter extends BaseAdapter {
  name = 'weixin';
  displayName = '微信公众号';
  editUrl = 'https://mp.weixin.qq.com/';
  icon = 'https://res.wx.qq.com/a/wx_fed/assets/res/NTI4MWU5.ico';
  
  limits = {
    titleMax: 64,
    coverRequired: true,
    digestMax: 120
  };

  /**
   * 注入脚本 - 在微信公众号页面执行
   */
  static injectScript(articleData) {
    console.log('[微信适配器] 脚本开始执行');
    
    // 主流程
    async function main() {
      // 创建浮动提示
      var host = document.createElement('div');
      host.style.position = 'fixed';
      host.style.bottom = '20px';
      host.style.right = '20px';
      host.style.zIndex = '9999';
      document.body.appendChild(host);

      var shadow = host.attachShadow({ mode: 'open' });
      var tip = document.createElement('div');
      tip.innerHTML = `
        <style>
          .float-tip {
            background: #1e293b;
            color: white;
            padding: 12px 16px;
            border-radius: 8px;
            font-size: 14px;
            box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1);
            animation: slideIn 0.3s ease-out;
          }
          @keyframes slideIn {
            from { transform: translateY(100%); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
          }
        </style>
        <div class="float-tip">正在同步文章到微信公众号...</div>
      `;
      shadow.appendChild(tip);

      function updateTip(msg, isError) {
        var floatTip = tip.querySelector('.float-tip');
        if (floatTip) {
          floatTip.textContent = msg;
          if (isError) {
            floatTip.style.backgroundColor = '#dc2626';
          }
        }
      }

      function removeTip() {
        setTimeout(function() {
          if (document.body.contains(host)) {
            document.body.removeChild(host);
          }
        }, 3000);
      }

      try {
        // 1. 获取微信公众号信息
        updateTip('正在获取公众号信息...');
        
        var response = await fetch('https://mp.weixin.qq.com/');
        var html = await response.text();
        
        var dataMatch = html.match(/window\.wx\.commonData\s*=\s*\{([\s\S]*?)\};/);
        if (!dataMatch) {
          throw new Error('无法获取微信公众号信息，请确保已登录');
        }

        var tokenMatch = dataMatch[1].match(/t:\s*["'](\d+)["']/);
        var nicknameMatch = dataMatch[1].match(/nick_name:\s*["']([^"']+)["']/);
        var ticketMatch = dataMatch[1].match(/ticket:\s*["']([^"']+)["']/);
        var userNameMatch = dataMatch[1].match(/user_name:\s*["']([^"']+)["']/);

        if (!tokenMatch) {
          throw new Error('无法获取 token，请重新登录后重试');
        }

        var token = tokenMatch[1];
        var nickname = nicknameMatch ? nicknameMatch[1] : '';
        var ticket = ticketMatch ? ticketMatch[1] : '';
        var userName = userNameMatch ? userNameMatch[1] : '';

        console.log('[微信适配器] 获取到信息:', { token, nickname });

        // 2. 上传图片函数
        async function uploadImage(imageUrl, scene) {
          scene = scene || 8;
          
          var blob = await (await fetch(imageUrl)).blob();
          var formData = new FormData();
          
          formData.append('type', blob.type);
          formData.append('id', Date.now().toString());
          formData.append('name', Date.now() + '.jpg');
          formData.append('lastModifiedDate', new Date().toString());
          formData.append('size', blob.size.toString());
          formData.append('file', blob, Date.now() + '.jpg');

          var url = new URL('https://mp.weixin.qq.com/cgi-bin/filetransfer');
          var timestamp = Math.floor(Date.now() / 1000);
          var seq = Date.now().toString();

          url.searchParams.append('action', 'upload_material');
          url.searchParams.append('f', 'json');
          url.searchParams.append('scene', scene.toString());
          url.searchParams.append('writetype', 'doublewrite');
          url.searchParams.append('groupid', '1');
          url.searchParams.append('ticket_id', userName);
          url.searchParams.append('ticket', ticket);
          url.searchParams.append('svr_time', timestamp.toString());
          url.searchParams.append('token', token);
          url.searchParams.append('lang', 'zh_CN');
          url.searchParams.append('seq', seq);
          url.searchParams.append('t', Math.random().toString());

          var uploadResponse = await fetch(url.toString(), {
            method: 'POST',
            body: formData
          });

          var result = await uploadResponse.json();
          if (result.base_resp.err_msg !== 'ok') return null;

          return {
            fileId: parseInt(result.content, 10),
            url: result.cdn_url
          };
        }

        // 3. 处理文章内容中的图片
        updateTip('正在处理文章图片...');
        
        var parser = new DOMParser();
        var doc = parser.parseFromString(articleData.htmlContent || '', 'text/html');
        var images = doc.getElementsByTagName('img');

        for (var i = 0; i < images.length; i++) {
          updateTip('上传图片 ' + (i + 1) + '/' + images.length + '...');
          var img = images[i];
          var src = img.getAttribute('src');
          if (src && !src.startsWith('https://mmbiz.qpic.cn')) {
            var uploadResult = await uploadImage(src);
            if (uploadResult) {
              img.setAttribute('src', uploadResult.url);
            }
          }
        }

        var processedContent = doc.body.innerHTML;

        // 4. 上传封面图片
        var coverUrl = '';
        if (articleData.cover && articleData.cover.url) {
          updateTip('正在上传封面图片...');
          var coverResult = await uploadImage(articleData.cover.url, 8);
          if (coverResult) {
            coverUrl = coverResult.url;
          }
        }

        // 5. 创建文章
        updateTip('正在创建文章...');
        
        var formData = new FormData();
        formData.append('token', token);
        formData.append('lang', 'zh_CN');
        formData.append('f', 'json');
        formData.append('ajax', '1');
        formData.append('random', Math.random().toString());
        formData.append('AppMsgId', '');
        formData.append('count', '1');
        formData.append('data_seq', '0');
        formData.append('operate_from', 'Chrome');
        formData.append('isnew', '0');
        
        formData.append('title0', (articleData.title || '').slice(0, 64));
        formData.append('author0', nickname || '');
        formData.append('writerid0', '0');
        formData.append('fileid0', '');
        formData.append('digest0', (articleData.digest || '').slice(0, 120));
        formData.append('auto_gen_digest0', '1');
        formData.append('content0', processedContent || '');
        formData.append('sourceurl0', '');
        formData.append('need_open_comment0', '1');
        formData.append('only_fans_can_comment0', '0');
        
        formData.append('cdn_url0', coverUrl);
        formData.append('cdn_235_1_url0', coverUrl);
        formData.append('cdn_16_9_url0', '');
        formData.append('cdn_3_4_url0', '');
        formData.append('cdn_1_1_url0', '');
        formData.append('cdn_url_back0', '');
        
        formData.append('show_cover_pic0', '0');
        formData.append('copyright_type0', '0');
        formData.append('fee0', '0');
        formData.append('ad_id0', '');
        formData.append('is_share_copyright0', '0');
        formData.append('share_page_type0', '0');
        formData.append('share_imageinfo0', JSON.stringify({ list: [] }));
        formData.append('categories_list0', '[]');

        var createUrl = new URL('https://mp.weixin.qq.com/cgi-bin/operate_appmsg');
        createUrl.searchParams.set('t', 'ajax-response');
        createUrl.searchParams.set('sub', 'create');
        createUrl.searchParams.set('type', '77');
        createUrl.searchParams.set('token', token);
        createUrl.searchParams.set('lang', 'zh_CN');

        var createResponse = await fetch(createUrl.toString(), {
          method: 'POST',
          body: formData
        });

        var createResult = await createResponse.json();
        
        if (!createResult.appMsgId) {
          var errMsg = createResult.base_resp && createResult.base_resp.err_msg;
          throw new Error(errMsg || '创建文章失败');
        }

        // 6. 跳转到编辑页
        updateTip('文章创建成功！正在跳转...');
        
        var editUrl = new URL('https://mp.weixin.qq.com/cgi-bin/appmsg');
        editUrl.searchParams.set('t', 'media/appmsg_edit');
        editUrl.searchParams.set('action', 'edit');
        editUrl.searchParams.set('type', '77');
        editUrl.searchParams.set('appmsgid', createResult.appMsgId);
        editUrl.searchParams.set('token', token);
        editUrl.searchParams.set('lang', 'zh_CN');

        removeTip();
        window.location.href = editUrl.toString();

      } catch (error) {
        console.error('[微信适配器] 错误:', error);
        updateTip('同步失败: ' + error.message, true);
        removeTip();
      }
    }
    
    // 延迟执行
    setTimeout(main, 1000);
  }

  get injectScript() {
    return WeixinAdapter.injectScript;
  }
}
