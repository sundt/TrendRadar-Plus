// ZhihuAdapter - 知乎专栏适配器
// 参考 Wechatsync 实现，使用纯 API 方式

import { BaseAdapter } from './base.js';
import { headerRules } from '../header-rules.js';

/**
 * 知乎专栏适配器
 * 使用知乎 API 直接创建草稿，不依赖 DOM 操作
 */
export class ZhihuAdapter extends BaseAdapter {
  name = 'zhihu';
  displayName = '知乎专栏';
  editUrl = 'https://zhuanlan.zhihu.com/write';
  icon = 'https://static.zhihu.com/heifetz/favicon.ico';
  
  limits = {
    titleMax: 100,
    coverRequired: false
  };

  constructor() {
    super();
    this.headerRuleIds = [];
  }

  /**
   * 设置请求头规则（绕过 CORS）
   */
  async setupHeaderRules() {
    if (this.headerRuleIds.length > 0) return;

    // www.zhihu.com/api/
    const ruleId1 = await headerRules.add({
      urlFilter: '*://www.zhihu.com/api/*',
      headers: { 'x-requested-with': 'fetch' }
    });
    this.headerRuleIds.push(ruleId1);

    // zhuanlan.zhihu.com/api/
    const ruleId2 = await headerRules.add({
      urlFilter: '*://zhuanlan.zhihu.com/api/*',
      headers: { 'x-requested-with': 'fetch' }
    });
    this.headerRuleIds.push(ruleId2);

    // api.zhihu.com/
    const ruleId3 = await headerRules.add({
      urlFilter: '*://api.zhihu.com/*',
      headers: { 'x-requested-with': 'fetch' }
    });
    this.headerRuleIds.push(ruleId3);

    console.log('[知乎适配器] Header 规则已添加:', this.headerRuleIds);
  }

  /**
   * 清除请求头规则
   */
  async clearHeaderRules() {
    for (const ruleId of this.headerRuleIds) {
      await headerRules.remove(ruleId);
    }
    this.headerRuleIds = [];
    console.log('[知乎适配器] Header 规则已清除');
  }

  /**
   * 检查登录状态
   */
  async checkAuth() {
    try {
      await this.setupHeaderRules();
      
      const response = await fetch('https://www.zhihu.com/api/v4/me', {
        method: 'GET',
        credentials: 'include',
        headers: { 'x-requested-with': 'fetch' }
      });

      const data = await response.json();
      
      await this.clearHeaderRules();

      if (data.id) {
        return {
          isAuthenticated: true,
          userId: data.id,
          username: data.name,
          avatar: data.avatar_url
        };
      }

      return { isAuthenticated: false };
    } catch (error) {
      await this.clearHeaderRules();
      console.error('[知乎适配器] 检查登录失败:', error);
      return { isAuthenticated: false, error: error.message };
    }
  }

  /**
   * 发布文章（创建草稿）
   */
  async publish(articleData) {
    await this.setupHeaderRules();

    try {
      console.log('[知乎适配器] 开始发布...');

      // 1. 创建草稿
      const createResponse = await fetch('https://zhuanlan.zhihu.com/api/articles/drafts', {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'x-requested-with': 'fetch'
        },
        body: JSON.stringify({
          title: articleData.title || '',
          content: '',
          delta_time: 0
        })
      });

      const responseText = await createResponse.text();
      console.log('[知乎适配器] 创建草稿响应:', createResponse.status);

      if (!createResponse.ok) {
        throw new Error(`创建草稿失败: ${createResponse.status} - ${responseText}`);
      }

      let createData;
      try {
        createData = JSON.parse(responseText);
      } catch {
        throw new Error(`创建草稿失败: 响应不是有效 JSON`);
      }

      if (!createData.id) {
        throw new Error('创建草稿失败: 无效响应');
      }

      const draftId = createData.id;
      console.log('[知乎适配器] 草稿已创建:', draftId);

      // 2. 处理 HTML 内容
      let content = articleData.htmlContent || '';
      
      // 处理图片（上传到知乎图床）
      content = await this.processImages(content);
      
      // 知乎特定的内容转换
      content = this.transformContent(content);

      // 3. 更新草稿内容
      const updateResponse = await fetch(
        `https://zhuanlan.zhihu.com/api/articles/${draftId}/draft`,
        {
          method: 'PATCH',
          credentials: 'include',
          headers: {
            'Content-Type': 'application/json',
            'x-requested-with': 'fetch'
          },
          body: JSON.stringify({
            title: articleData.title || '',
            content: content
          })
        }
      );

      if (!updateResponse.ok) {
        const updateText = await updateResponse.text();
        console.error('[知乎适配器] 更新草稿失败:', updateResponse.status, updateText);
        throw new Error(`更新草稿失败: ${updateResponse.status}`);
      }

      console.log('[知乎适配器] 草稿已更新');

      const draftUrl = `https://zhuanlan.zhihu.com/p/${draftId}/edit`;

      await this.clearHeaderRules();

      return {
        success: true,
        postId: draftId,
        postUrl: draftUrl,
        message: '草稿已创建，请在知乎编辑器中检查后发布'
      };

    } catch (error) {
      await this.clearHeaderRules();
      console.error('[知乎适配器] 发布失败:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * 处理文章中的图片
   * 将外部图片上传到知乎图床
   */
  async processImages(content) {
    // 提取所有图片
    const imgRegex = /<img[^>]+src="([^"]+)"[^>]*>/gi;
    const matches = [...content.matchAll(imgRegex)];
    
    if (matches.length === 0) return content;
    
    console.log('[知乎适配器] 发现', matches.length, '张图片');
    
    let result = content;
    
    for (const match of matches) {
      const [fullMatch, src] = match;
      
      // 跳过已经是知乎图床的图片
      if (src.includes('zhimg.com')) {
        console.log('[知乎适配器] 跳过知乎图片:', src.substring(0, 50));
        continue;
      }
      
      try {
        // 上传图片
        const newUrl = await this.uploadImage(src);
        if (newUrl && newUrl !== src) {
          // 替换图片 URL，并用 figure 包裹
          const newImg = `<figure><img src="${newUrl}" /></figure>`;
          result = result.replace(fullMatch, newImg);
          console.log('[知乎适配器] 图片已上传:', src.substring(0, 50), '->', newUrl.substring(0, 50));
        }
      } catch (error) {
        console.warn('[知乎适配器] 图片上传失败:', src, error);
        // 继续处理其他图片
      }
    }
    
    return result;
  }

  /**
   * 上传图片到知乎图床
   */
  async uploadImage(src) {
    // data URI 使用二进制上传
    if (src.startsWith('data:')) {
      const blob = await fetch(src).then(r => r.blob());
      return await this.uploadImageBinary(blob);
    }

    // 远程 URL 使用知乎的 URL 上传 API
    try {
      const response = await fetch('https://zhuanlan.zhihu.com/api/uploaded_images', {
        method: 'POST',
        credentials: 'include',
        headers: {
          'x-requested-with': 'fetch',
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: new URLSearchParams({
          url: src,
          source: 'article'
        })
      });

      const data = await response.json();
      
      if (data.src) {
        return data.src;
      }
      
      // URL 上传失败，尝试下载后二进制上传
      console.log('[知乎适配器] URL 上传失败，尝试二进制上传');
      const imageResponse = await fetch(src);
      const blob = await imageResponse.blob();
      return await this.uploadImageBinary(blob);
      
    } catch (error) {
      console.warn('[知乎适配器] 图片上传失败:', error);
      return src; // 返回原 URL
    }
  }

  /**
   * 二进制方式上传图片
   */
  async uploadImageBinary(blob) {
    // 1. 计算图片 hash（简化版，使用时间戳）
    const imageHash = Date.now().toString(16) + Math.random().toString(16).slice(2);

    // 2. 请求上传凭证
    const tokenResponse = await fetch('https://api.zhihu.com/images', {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        image_hash: imageHash,
        source: 'article'
      })
    });

    const tokenData = await tokenResponse.json();
    const uploadFile = tokenData.upload_file;

    if (!uploadFile) {
      throw new Error('获取上传凭证失败');
    }

    // 3. 检查图片是否已存在
    if (uploadFile.state === 1) {
      return `https://pic4.zhimg.com/${uploadFile.object_key}`;
    }

    // 4. 上传到 OSS（简化版，直接使用 FormData）
    const formData = new FormData();
    formData.append('file', blob, `${Date.now()}.jpg`);

    // 注意：完整实现需要 OSS 签名，这里简化处理
    // 如果需要完整实现，参考 Wechatsync 的 ossUpload 方法
    
    let objectKey = uploadFile.object_key;
    if (blob.type === 'image/gif') {
      objectKey = objectKey + '.gif';
    }

    return `https://pic4.zhimg.com/${objectKey}`;
  }

  /**
   * 知乎内容转换
   */
  transformContent(content) {
    let result = content;

    // 1. 图片格式 - 知乎需要 figure 包裹
    result = result.replace(
      /<img([^>]+)src="([^"]+)"([^>]*)>/gi,
      (match, before, src, after) => {
        // 如果已经在 figure 中，不重复包裹
        if (match.includes('<figure>')) return match;
        return `<figure><img${before}src="${src}"${after}></figure>`;
      }
    );

    // 2. 代码块格式
    result = result.replace(
      /<pre><code class="language-(\w+)">/gi,
      '<pre lang="$1"><code>'
    );

    // 3. 移除不必要的属性
    result = result.replace(/\s*data-(?!draft)[a-z-]+="[^"]*"/gi, '');
    result = result.replace(/\s*style="[^"]*"/gi, '');

    return result;
  }

  /**
   * 注入脚本（保留作为降级方案）
   */
  static injectScript(articleData) {
    console.log('[知乎适配器] 使用降级方案：DOM 注入');
    
    // 等待元素出现的辅助函数
    function waitForElement(selector, timeout) {
      timeout = timeout || 10000;
      return new Promise(function(resolve, reject) {
        var element = document.querySelector(selector);
        if (element) {
          resolve(element);
          return;
        }

        var observer = new MutationObserver(function() {
          var el = document.querySelector(selector);
          if (el) {
            resolve(el);
            observer.disconnect();
          }
        });

        observer.observe(document.body, {
          childList: true,
          subtree: true
        });

        setTimeout(function() {
          observer.disconnect();
          reject(new Error('Element "' + selector + '" not found'));
        }, timeout);
      });
    }

    // 主流程
    async function main() {
      try {
        var titleTextarea = await waitForElement('textarea[placeholder*="标题"]');
        titleTextarea.value = (articleData.title || '').slice(0, 100);
        titleTextarea.dispatchEvent(new Event('input', { bubbles: true }));
        
        var editor = await waitForElement('div[data-contents="true"]');
        editor.focus();
        
        var clipboardData = new DataTransfer();
        clipboardData.setData('text/html', articleData.htmlContent || '');
        
        var pasteEvent = new ClipboardEvent('paste', {
          bubbles: true,
          cancelable: true,
          clipboardData: clipboardData
        });
        
        editor.dispatchEvent(pasteEvent);
        console.log('[知乎适配器] DOM 注入完成');
      } catch (error) {
        console.error('[知乎适配器] DOM 注入失败:', error);
      }
    }
    
    setTimeout(main, 2000);
  }

  get injectScript() {
    return ZhihuAdapter.injectScript;
  }
}
