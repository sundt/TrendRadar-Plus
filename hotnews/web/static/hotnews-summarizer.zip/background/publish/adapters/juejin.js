// JuejinAdapter - 掘金适配器
// 参考 Wechatsync 实现，使用纯 API 方式

import { BaseAdapter } from './base.js';
import { headerRules } from '../header-rules.js';

/**
 * 掘金适配器
 * 使用掘金 API 直接创建草稿，不依赖 DOM 操作
 */
export class JuejinAdapter extends BaseAdapter {
  name = 'juejin';
  displayName = '掘金';
  editUrl = 'https://juejin.cn/editor/drafts/new?v=2';
  icon = 'https://lf3-cdn-tos.bytescm.com/obj/static/xitu_juejin_web/static/favicons/favicon-32x32.png';
  
  limits = {
    titleMax: 100,
    coverRequired: false
  };

  constructor() {
    super();
    this.headerRuleIds = [];
    this.cachedCsrfToken = null;
  }

  /**
   * 设置请求头规则（绕过 CORS）
   */
  async setupHeaderRules() {
    if (this.headerRuleIds.length > 0) return;

    // api.juejin.cn
    const ruleId1 = await headerRules.add({
      urlFilter: '*://api.juejin.cn/*',
      headers: {
        'Origin': 'https://juejin.cn',
        'Referer': 'https://juejin.cn/'
      }
    });
    this.headerRuleIds.push(ruleId1);

    console.log('[掘金适配器] Header 规则已添加:', this.headerRuleIds);
  }

  /**
   * 清除请求头规则
   */
  async clearHeaderRules() {
    for (const ruleId of this.headerRuleIds) {
      await headerRules.remove(ruleId);
    }
    this.headerRuleIds = [];
    console.log('[掘金适配器] Header 规则已清除');
  }

  /**
   * 获取 CSRF Token
   * Token 格式: "0,{actual_token},86370000,success,{session_id}"
   */
  async getCsrfToken() {
    if (this.cachedCsrfToken) {
      return this.cachedCsrfToken;
    }

    const response = await fetch('https://api.juejin.cn/user_api/v1/sys/token', {
      method: 'HEAD',
      credentials: 'include',
      headers: {
        'x-secsdk-csrf-request': '1',
        'x-secsdk-csrf-version': '1.2.10'
      }
    });

    const wareToken = response.headers.get('x-ware-csrf-token');
    if (!wareToken) {
      throw new Error('获取 CSRF Token 失败');
    }

    // Token 格式: "0,{actual_token},86370000,success,{session_id}"
    const parts = wareToken.split(',');
    if (parts.length < 2) {
      throw new Error('CSRF Token 格式无效');
    }

    this.cachedCsrfToken = parts[1];
    console.log('[掘金适配器] 获取 CSRF Token 成功');
    return this.cachedCsrfToken;
  }

  /**
   * 检查登录状态
   */
  async checkAuth() {
    try {
      await this.setupHeaderRules();
      
      const response = await fetch('https://api.juejin.cn/user_api/v1/user/get', {
        method: 'GET',
        credentials: 'include'
      });

      const data = await response.json();
      
      await this.clearHeaderRules();

      if (data.data?.user_id) {
        return {
          isAuthenticated: true,
          userId: data.data.user_id,
          username: data.data.user_name,
          avatar: data.data.avatar_large
        };
      }

      return { isAuthenticated: false };
    } catch (error) {
      await this.clearHeaderRules();
      console.error('[掘金适配器] 检查登录失败:', error);
      return { isAuthenticated: false, error: error.message };
    }
  }

  /**
   * 发布文章（创建草稿）
   */
  async publish(articleData) {
    await this.setupHeaderRules();

    try {
      console.log('[掘金适配器] 开始发布...');

      // 1. 获取 CSRF Token
      const csrfToken = await this.getCsrfToken();

      // 2. 处理内容
      let content = articleData.htmlContent || '';
      
      // 处理图片（上传到掘金图床）
      content = await this.processImages(content);
      
      // 转换为 Markdown（掘金使用 Markdown）
      const markdown = this.htmlToMarkdown(content);

      // 3. 创建草稿
      const createResponse = await fetch(
        'https://api.juejin.cn/content_api/v1/article_draft/create',
        {
          method: 'POST',
          credentials: 'include',
          headers: {
            'Content-Type': 'application/json',
            'x-secsdk-csrf-token': csrfToken
          },
          body: JSON.stringify({
            brief_content: '',
            category_id: '0',
            cover_image: '',
            edit_type: 10,
            html_content: 'deprecated',
            link_url: '',
            mark_content: markdown,
            tag_ids: [],
            title: articleData.title || ''
          })
        }
      );

      const responseText = await createResponse.text();
      console.log('[掘金适配器] 创建草稿响应:', createResponse.status);

      if (!createResponse.ok) {
        throw new Error(`创建草稿失败: ${createResponse.status} - ${responseText}`);
      }

      let createData;
      try {
        createData = JSON.parse(responseText);
      } catch {
        throw new Error('创建草稿失败: 响应不是有效 JSON');
      }

      // 检查业务错误
      if (createData.err_no && createData.err_no !== 0) {
        throw new Error(createData.err_msg || `创建草稿失败: 错误码 ${createData.err_no}`);
      }

      if (!createData.data?.id) {
        throw new Error(createData.err_msg || '创建草稿失败: 无效响应');
      }

      const draftId = createData.data.id;
      console.log('[掘金适配器] 草稿已创建:', draftId);

      const draftUrl = `https://juejin.cn/editor/drafts/${draftId}`;

      await this.clearHeaderRules();

      return {
        success: true,
        postId: draftId,
        postUrl: draftUrl,
        message: '草稿已创建，请在掘金编辑器中检查后发布'
      };

    } catch (error) {
      await this.clearHeaderRules();
      console.error('[掘金适配器] 发布失败:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * 处理文章中的图片
   * 将外部图片上传到掘金图床
   */
  async processImages(content) {
    // 提取所有图片
    const imgRegex = /<img[^>]+src="([^"]+)"[^>]*>/gi;
    const matches = [...content.matchAll(imgRegex)];
    
    if (matches.length === 0) return content;
    
    console.log('[掘金适配器] 发现', matches.length, '张图片');
    
    let result = content;
    
    for (const match of matches) {
      const [fullMatch, src] = match;
      
      // 跳过已经是掘金图床的图片
      if (this.isJuejinImage(src)) {
        console.log('[掘金适配器] 跳过掘金图片:', src.substring(0, 50));
        continue;
      }
      
      try {
        // 上传图片
        const newUrl = await this.uploadImage(src);
        if (newUrl && newUrl !== src) {
          result = result.replace(fullMatch, fullMatch.replace(src, newUrl));
          console.log('[掘金适配器] 图片已上传:', src.substring(0, 50), '->', newUrl.substring(0, 50));
        }
      } catch (error) {
        console.warn('[掘金适配器] 图片上传失败:', src, error);
        // 继续处理其他图片
      }
    }
    
    return result;
  }

  /**
   * 检查是否是掘金图床图片
   */
  isJuejinImage(src) {
    const patterns = ['juejin.cn', 'p1-juejin', 'p3-juejin', 'p6-juejin', 'p9-juejin', 'byteimg.com'];
    return patterns.some(p => src.includes(p));
  }

  /**
   * 上传图片到掘金图床
   * 注意：完整实现需要 ImageX 的 AWS4 签名，这里使用简化版本
   */
  async uploadImage(src) {
    // data URI 转 blob
    let blob;
    if (src.startsWith('data:')) {
      blob = await fetch(src).then(r => r.blob());
    } else {
      // 远程 URL 下载
      try {
        const response = await fetch(src);
        if (!response.ok) {
          console.warn('[掘金适配器] 图片下载失败:', src);
          return src;
        }
        blob = await response.blob();
      } catch (error) {
        console.warn('[掘金适配器] 图片下载失败:', src, error);
        return src;
      }
    }

    // 由于 ImageX 上传需要复杂的 AWS4 签名，这里暂时返回原 URL
    // 完整实现需要：
    // 1. GET https://api.juejin.cn/imagex/v2/gen_token 获取临时凭证
    // 2. GET https://imagex.bytedanceapi.com/?Action=ApplyImageUpload 申请上传（需要 AWS4 签名）
    // 3. PUT 上传到 TOS（需要 CRC32 校验）
    // 4. POST https://imagex.bytedanceapi.com/?Action=CommitImageUpload 提交
    // 5. GET https://api.juejin.cn/imagex/v2/get_img_url 获取最终 URL
    
    console.log('[掘金适配器] 图片上传暂未实现完整 ImageX 流程，使用原 URL');
    return src;
  }

  /**
   * 简单的 HTML 转 Markdown
   */
  htmlToMarkdown(html) {
    let md = html;
    
    // 标题
    md = md.replace(/<h1[^>]*>(.*?)<\/h1>/gi, '# $1\n\n');
    md = md.replace(/<h2[^>]*>(.*?)<\/h2>/gi, '## $1\n\n');
    md = md.replace(/<h3[^>]*>(.*?)<\/h3>/gi, '### $1\n\n');
    md = md.replace(/<h4[^>]*>(.*?)<\/h4>/gi, '#### $1\n\n');
    md = md.replace(/<h5[^>]*>(.*?)<\/h5>/gi, '##### $1\n\n');
    md = md.replace(/<h6[^>]*>(.*?)<\/h6>/gi, '###### $1\n\n');
    
    // 粗体和斜体
    md = md.replace(/<strong[^>]*>(.*?)<\/strong>/gi, '**$1**');
    md = md.replace(/<b[^>]*>(.*?)<\/b>/gi, '**$1**');
    md = md.replace(/<em[^>]*>(.*?)<\/em>/gi, '*$1*');
    md = md.replace(/<i[^>]*>(.*?)<\/i>/gi, '*$1*');
    
    // 链接
    md = md.replace(/<a[^>]+href="([^"]+)"[^>]*>(.*?)<\/a>/gi, '[$2]($1)');
    
    // 图片
    md = md.replace(/<img[^>]+src="([^"]+)"[^>]*alt="([^"]*)"[^>]*>/gi, '![$2]($1)');
    md = md.replace(/<img[^>]+src="([^"]+)"[^>]*>/gi, '![]($1)');
    
    // 代码块
    md = md.replace(/<pre[^>]*><code[^>]*class="language-(\w+)"[^>]*>([\s\S]*?)<\/code><\/pre>/gi, '```$1\n$2\n```\n\n');
    md = md.replace(/<pre[^>]*><code[^>]*>([\s\S]*?)<\/code><\/pre>/gi, '```\n$1\n```\n\n');
    md = md.replace(/<code[^>]*>(.*?)<\/code>/gi, '`$1`');
    
    // 引用
    md = md.replace(/<blockquote[^>]*>([\s\S]*?)<\/blockquote>/gi, (match, content) => {
      return content.split('\n').map(line => '> ' + line.trim()).join('\n') + '\n\n';
    });
    
    // 列表
    md = md.replace(/<ul[^>]*>([\s\S]*?)<\/ul>/gi, (match, content) => {
      return content.replace(/<li[^>]*>(.*?)<\/li>/gi, '- $1\n') + '\n';
    });
    md = md.replace(/<ol[^>]*>([\s\S]*?)<\/ol>/gi, (match, content) => {
      let index = 1;
      return content.replace(/<li[^>]*>(.*?)<\/li>/gi, () => `${index++}. $1\n`) + '\n';
    });
    
    // 段落
    md = md.replace(/<p[^>]*>([\s\S]*?)<\/p>/gi, '$1\n\n');
    
    // 换行
    md = md.replace(/<br\s*\/?>/gi, '\n');
    
    // 水平线
    md = md.replace(/<hr[^>]*>/gi, '---\n\n');
    
    // 移除其他 HTML 标签
    md = md.replace(/<[^>]+>/g, '');
    
    // 解码 HTML 实体
    md = md.replace(/&nbsp;/g, ' ');
    md = md.replace(/&lt;/g, '<');
    md = md.replace(/&gt;/g, '>');
    md = md.replace(/&amp;/g, '&');
    md = md.replace(/&quot;/g, '"');
    
    // 清理多余空行
    md = md.replace(/\n{3,}/g, '\n\n');
    
    return md.trim();
  }

  /**
   * 注入脚本（保留作为降级方案）
   */
  static injectScript(articleData) {
    console.log('[掘金适配器] 使用降级方案：DOM 注入');
    
    function waitForElement(selector, timeout) {
      timeout = timeout || 10000;
      return new Promise(function(resolve, reject) {
        var element = document.querySelector(selector);
        if (element) {
          resolve(element);
          return;
        }

        var observer = new MutationObserver(function() {
          var el = document.querySelector(selector);
          if (el) {
            resolve(el);
            observer.disconnect();
          }
        });

        observer.observe(document.body, {
          childList: true,
          subtree: true
        });

        setTimeout(function() {
          observer.disconnect();
          reject(new Error('Element "' + selector + '" not found'));
        }, timeout);
      });
    }

    async function main() {
      try {
        var titleInput = await waitForElement('input[placeholder="输入文章标题..."]', 15000);
        titleInput.value = (articleData.title || '').slice(0, 100);
        titleInput.dispatchEvent(new Event('input', { bubbles: true }));
        
        var editor = await waitForElement('div.CodeMirror-code[role="presentation"]', 10000);
        editor.focus();
        
        var clipboardData = new DataTransfer();
        clipboardData.setData('text/html', articleData.htmlContent || '');
        
        var pasteEvent = new ClipboardEvent('paste', {
          bubbles: true,
          cancelable: true,
          clipboardData: clipboardData
        });
        
        editor.dispatchEvent(pasteEvent);
        console.log('[掘金适配器] DOM 注入完成');
      } catch (error) {
        console.error('[掘金适配器] DOM 注入失败:', error);
      }
    }
    
    setTimeout(main, 2000);
  }

  get injectScript() {
    return JuejinAdapter.injectScript;
  }
}
