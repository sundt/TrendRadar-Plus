// JianshuAdapter - 简书适配器
// 参考 Wechatsync 实现，使用纯 API 方式

import { BaseAdapter } from './base.js';

/**
 * 简书适配器
 * 使用简书 API 直接创建草稿
 * 简书 API 相对简单，不需要复杂的签名
 */
export class JianshuAdapter extends BaseAdapter {
  name = 'jianshu';
  displayName = '简书';
  editUrl = 'https://www.jianshu.com/writer';
  icon = 'https://www.jianshu.com/favicon.ico';
  
  limits = {
    titleMax: 100,
    coverRequired: false
  };

  constructor() {
    super();
    this.defaultNotebookId = null;
  }

  /**
   * 检查登录状态
   */
  async checkAuth() {
    try {
      const response = await fetch('https://www.jianshu.com/settings/basic.json', {
        method: 'GET',
        credentials: 'include'
      });

      const data = await response.json();

      if (data.data?.nickname) {
        return {
          isAuthenticated: true,
          username: data.data.nickname,
          avatar: data.data.avatar
        };
      }

      return { isAuthenticated: false };
    } catch (error) {
      console.error('[简书适配器] 检查登录失败:', error);
      return { isAuthenticated: false, error: error.message };
    }
  }

  /**
   * 获取文集列表
   */
  async getNotebooks() {
    const response = await fetch('https://www.jianshu.com/author/notebooks', {
      method: 'GET',
      credentials: 'include',
      headers: {
        'Accept': 'application/json'
      }
    });

    return response.json();
  }

  /**
   * 获取默认文集 ID
   */
  async getDefaultNotebookId() {
    if (this.defaultNotebookId) {
      return this.defaultNotebookId;
    }

    const notebooks = await this.getNotebooks();
    if (!notebooks || notebooks.length === 0) {
      throw new Error('没有可用的文集，请先在简书创建一个文集');
    }

    this.defaultNotebookId = notebooks[0].id;
    return this.defaultNotebookId;
  }

  /**
   * 发布文章（创建草稿）
   */
  async publish(articleData) {
    try {
      console.log('[简书适配器] 开始发布...');

      // 1. 获取文集 ID
      const notebookId = await this.getDefaultNotebookId();
      console.log('[简书适配器] 使用文集:', notebookId);

      // 2. 创建文章草稿
      const createResponse = await fetch('https://www.jianshu.com/author/notes', {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({
          at_bottom: false,
          notebook_id: notebookId,
          title: articleData.title || '无标题'
        })
      });

      const createData = await createResponse.json();

      if (!createData.id) {
        throw new Error('创建草稿失败');
      }

      const draftId = createData.id;
      console.log('[简书适配器] 草稿已创建:', draftId);

      // 3. 处理内容
      let content = articleData.htmlContent || '';
      
      // 简书特定处理：移除空段落、移除尾部 br
      content = content.replace(/<p>\s*<\/p>/gi, '');
      content = content.replace(/<br\s*\/?>\s*$/gi, '');
      
      // 处理图片
      content = await this.processImages(content);

      // 4. 更新草稿内容
      const updateResponse = await fetch(
        `https://www.jianshu.com/author/notes/${draftId}`,
        {
          method: 'PUT',
          credentials: 'include',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            title: articleData.title || '无标题',
            content: content
          })
        }
      );

      const updateData = await updateResponse.json();

      if (!updateData.id) {
        throw new Error('更新草稿失败');
      }

      console.log('[简书适配器] 草稿已更新');

      const draftUrl = `https://www.jianshu.com/writer#/notebooks/${notebookId}/notes/${draftId}`;

      return {
        success: true,
        postId: String(draftId),
        postUrl: draftUrl,
        message: '草稿已创建，请在简书编辑器中检查后发布'
      };

    } catch (error) {
      console.error('[简书适配器] 发布失败:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * 处理文章中的图片
   */
  async processImages(content) {
    const imgRegex = /<img[^>]+src="([^"]+)"[^>]*>/gi;
    const matches = [...content.matchAll(imgRegex)];
    
    if (matches.length === 0) return content;
    
    console.log('[简书适配器] 发现', matches.length, '张图片');
    
    let result = content;
    
    for (const match of matches) {
      const [fullMatch, src] = match;
      
      // 跳过已经是简书图床的图片
      if (src.includes('jianshu.com') || src.includes('jianshuapi.com') || src.includes('upload-images.jianshu.io')) {
        console.log('[简书适配器] 跳过简书图片:', src.substring(0, 50));
        continue;
      }
      
      try {
        const newUrl = await this.uploadImage(src);
        if (newUrl && newUrl !== src) {
          result = result.replace(fullMatch, fullMatch.replace(src, newUrl));
          console.log('[简书适配器] 图片已上传:', src.substring(0, 50), '->', newUrl.substring(0, 50));
        }
      } catch (error) {
        console.warn('[简书适配器] 图片上传失败:', src, error);
      }
    }
    
    return result;
  }

  /**
   * 获取图片上传凭证
   */
  async getUploadToken() {
    const response = await fetch('https://www.jianshu.com/upload_images/token.json', {
      method: 'GET',
      credentials: 'include',
      headers: {
        'Accept': 'application/json'
      }
    });

    return response.json();
  }

  /**
   * 上传图片到简书图床（七牛云）
   */
  async uploadImage(src) {
    // 下载图片
    let blob;
    if (src.startsWith('data:')) {
      blob = await fetch(src).then(r => r.blob());
    } else {
      try {
        const response = await fetch(src);
        if (!response.ok) {
          console.warn('[简书适配器] 图片下载失败:', src);
          return src;
        }
        blob = await response.blob();
      } catch (error) {
        console.warn('[简书适配器] 图片下载失败:', src, error);
        return src;
      }
    }

    try {
      // 获取上传凭证
      const { token, url: uploadUrl } = await this.getUploadToken();

      // 生成文件名
      const ext = blob.type.split('/')[1] || 'png';
      const filename = `${Date.now()}.${ext}`;

      // 上传到七牛云
      const formData = new FormData();
      formData.append('file', blob, filename);
      formData.append('token', token);

      const response = await fetch(uploadUrl, {
        method: 'POST',
        body: formData
      });

      const data = await response.json();

      if (data.url) {
        return data.url;
      }

      // 七牛返回的是 key，需要拼接完整 URL
      if (data.key) {
        return `https://upload-images.jianshu.io/upload_images/${data.key}`;
      }

      console.warn('[简书适配器] 图片上传失败: 无效响应');
      return src;
    } catch (error) {
      console.warn('[简书适配器] 图片上传失败:', error);
      return src;
    }
  }

  /**
   * 注入脚本（保留作为降级方案）
   */
  static injectScript(articleData) {
    console.log('[简书适配器] 使用降级方案：DOM 注入');
    
    function waitForElement(selector, timeout) {
      timeout = timeout || 10000;
      return new Promise(function(resolve, reject) {
        var element = document.querySelector(selector);
        if (element) {
          resolve(element);
          return;
        }

        var observer = new MutationObserver(function() {
          var el = document.querySelector(selector);
          if (el) {
            resolve(el);
            observer.disconnect();
          }
        });

        observer.observe(document.body, {
          childList: true,
          subtree: true
        });

        setTimeout(function() {
          observer.disconnect();
          reject(new Error('Element "' + selector + '" not found'));
        }, timeout);
      });
    }

    async function main() {
      try {
        // 简书编辑器
        var editor = await waitForElement('[contenteditable="true"], .public-DraftEditor-content', 10000);
        editor.focus();
        
        var clipboardData = new DataTransfer();
        clipboardData.setData('text/html', articleData.htmlContent || '');
        
        var pasteEvent = new ClipboardEvent('paste', {
          bubbles: true,
          cancelable: true,
          clipboardData: clipboardData
        });
        
        editor.dispatchEvent(pasteEvent);
        console.log('[简书适配器] DOM 注入完成');
      } catch (error) {
        console.error('[简书适配器] DOM 注入失败:', error);
      }
    }
    
    setTimeout(main, 2000);
  }

  get injectScript() {
    return JianshuAdapter.injectScript;
  }
}
