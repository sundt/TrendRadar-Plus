// CsdnAdapter - CSDN 适配器
// 参考 Wechatsync 实现，使用纯 API 方式

import { BaseAdapter } from './base.js';
import { headerRules } from '../header-rules.js';

/**
 * CSDN 适配器
 * 使用 CSDN API 直接创建草稿，不依赖 DOM 操作
 */
export class CsdnAdapter extends BaseAdapter {
  name = 'csdn';
  displayName = 'CSDN';
  editUrl = 'https://editor.csdn.net/md/';
  icon = 'https://g.csdnimg.cn/static/logo/favicon32.ico';
  
  limits = {
    titleMax: 100,
    coverRequired: false
  };

  // CSDN API 签名密钥
  static API_KEY = '203803574';
  static API_SECRET = '9znpamsyl2c7cdrr9sas0le9vbc3r6ba';

  constructor() {
    super();
    this.headerRuleIds = [];
    this.userInfo = null;
  }

  /**
   * 设置请求头规则（绕过 CORS）
   */
  async setupHeaderRules() {
    if (this.headerRuleIds.length > 0) return;

    // bizapi.csdn.net
    const ruleId1 = await headerRules.add({
      urlFilter: '*://bizapi.csdn.net/*',
      headers: {
        'Origin': 'https://editor.csdn.net',
        'Referer': 'https://editor.csdn.net/'
      }
    });
    this.headerRuleIds.push(ruleId1);

    // imgservice.csdn.net
    const ruleId2 = await headerRules.add({
      urlFilter: '*://imgservice.csdn.net/*',
      headers: {
        'Origin': 'https://editor.csdn.net',
        'Referer': 'https://editor.csdn.net/'
      }
    });
    this.headerRuleIds.push(ruleId2);

    console.log('[CSDN适配器] Header 规则已添加:', this.headerRuleIds);
  }

  /**
   * 清除请求头规则
   */
  async clearHeaderRules() {
    for (const ruleId of this.headerRuleIds) {
      await headerRules.remove(ruleId);
    }
    this.headerRuleIds = [];
    console.log('[CSDN适配器] Header 规则已清除');
  }

  /**
   * 生成 UUID
   */
  createUuid() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
      const r = Math.random() * 16 | 0;
      const v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }

  /**
   * HMAC-SHA256 签名
   */
  async hmacSha256(message, secret) {
    const encoder = new TextEncoder();
    const keyData = encoder.encode(secret);
    const messageData = encoder.encode(message);

    const cryptoKey = await crypto.subtle.importKey(
      'raw',
      keyData,
      { name: 'HMAC', hash: 'SHA-256' },
      false,
      ['sign']
    );

    const signature = await crypto.subtle.sign('HMAC', cryptoKey, messageData);

    // 转换为 Base64
    const bytes = new Uint8Array(signature);
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  }

  /**
   * 生成 CSDN API 签名
   */
  async signRequest(apiPath, method = 'POST') {
    const nonce = this.createUuid();

    // GET: 没有 Content-Type
    // POST: Content-Type 为 application/json
    const signStr = method === 'GET'
      ? `GET\n*/*\n\n\n\nx-ca-key:${CsdnAdapter.API_KEY}\nx-ca-nonce:${nonce}\n${apiPath}`
      : `POST\n*/*\n\napplication/json\n\nx-ca-key:${CsdnAdapter.API_KEY}\nx-ca-nonce:${nonce}\n${apiPath}`;

    const signature = await this.hmacSha256(signStr, CsdnAdapter.API_SECRET);

    const headers = {
      'accept': '*/*',
      'x-ca-key': CsdnAdapter.API_KEY,
      'x-ca-nonce': nonce,
      'x-ca-signature': signature,
      'x-ca-signature-headers': 'x-ca-key,x-ca-nonce'
    };

    if (method === 'POST') {
      headers['content-type'] = 'application/json';
    }

    return headers;
  }

  /**
   * 检查登录状态
   */
  async checkAuth() {
    try {
      await this.setupHeaderRules();
      
      const apiPath = '/blog-console-api/v3/editor/getBaseInfo';
      const headers = await this.signRequest(apiPath, 'GET');

      const response = await fetch(`https://bizapi.csdn.net${apiPath}`, {
        method: 'GET',
        credentials: 'include',
        headers
      });

      const data = await response.json();
      
      await this.clearHeaderRules();

      if (data.code === 200 && data.data?.name) {
        this.userInfo = {
          csdnid: data.data.name,
          username: data.data.nickname || data.data.name,
          avatar: data.data.avatar
        };
        return {
          isAuthenticated: true,
          userId: data.data.name,
          username: data.data.nickname || data.data.name,
          avatar: data.data.avatar
        };
      }

      return { isAuthenticated: false };
    } catch (error) {
      await this.clearHeaderRules();
      console.error('[CSDN适配器] 检查登录失败:', error);
      return { isAuthenticated: false, error: error.message };
    }
  }

  /**
   * 发布文章（创建草稿）
   */
  async publish(articleData) {
    await this.setupHeaderRules();

    try {
      console.log('[CSDN适配器] 开始发布...');

      // 1. 确保已登录
      if (!this.userInfo) {
        const auth = await this.checkAuth();
        if (!auth.isAuthenticated) {
          throw new Error('请先登录 CSDN');
        }
      }

      // 2. 处理内容
      let content = articleData.htmlContent || '';
      
      // 处理图片（上传到 CSDN 图床）
      content = await this.processImages(content);
      
      // 转换为 Markdown
      const markdown = this.htmlToMarkdown(content);

      // 3. 生成签名并保存文章
      const apiPath = '/blog-console-api/v3/mdeditor/saveArticle';
      const headers = await this.signRequest(apiPath);

      const response = await fetch(`https://bizapi.csdn.net${apiPath}`, {
        method: 'POST',
        credentials: 'include',
        headers,
        body: JSON.stringify({
          title: articleData.title || '',
          markdowncontent: markdown,
          content: content,
          readType: 'public',
          level: 0,
          tags: '',
          status: 2, // 草稿
          categories: '',
          type: 'original',
          original_link: '',
          authorized_status: false,
          not_auto_saved: '1',
          source: 'pc_mdeditor',
          cover_images: [],
          cover_type: 1,
          is_new: 1,
          vote_id: 0,
          resource_id: '',
          pubStatus: 'draft',
          creator_activity_id: ''
        })
      });

      const responseText = await response.text();
      console.log('[CSDN适配器] 保存响应:', response.status);

      let data;
      try {
        data = JSON.parse(responseText);
      } catch {
        throw new Error('保存草稿失败: 响应不是有效 JSON');
      }

      if (data.code !== 200 || !data.data?.id) {
        throw new Error(data.msg || data.message || '保存草稿失败');
      }

      const postId = data.data.id;
      console.log('[CSDN适配器] 草稿已创建:', postId);

      const draftUrl = `https://editor.csdn.net/md?articleId=${postId}`;

      await this.clearHeaderRules();

      return {
        success: true,
        postId: postId,
        postUrl: draftUrl,
        message: '草稿已创建，请在 CSDN 编辑器中检查后发布'
      };

    } catch (error) {
      await this.clearHeaderRules();
      console.error('[CSDN适配器] 发布失败:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * 处理文章中的图片
   */
  async processImages(content) {
    const imgRegex = /<img[^>]+src="([^"]+)"[^>]*>/gi;
    const matches = [...content.matchAll(imgRegex)];
    
    if (matches.length === 0) return content;
    
    console.log('[CSDN适配器] 发现', matches.length, '张图片');
    
    let result = content;
    
    for (const match of matches) {
      const [fullMatch, src] = match;
      
      // 跳过已经是 CSDN 图床的图片
      if (src.includes('csdnimg.cn') || src.includes('csdn.net')) {
        console.log('[CSDN适配器] 跳过 CSDN 图片:', src.substring(0, 50));
        continue;
      }
      
      try {
        const newUrl = await this.uploadImage(src);
        if (newUrl && newUrl !== src) {
          result = result.replace(fullMatch, fullMatch.replace(src, newUrl));
          console.log('[CSDN适配器] 图片已上传:', src.substring(0, 50), '->', newUrl.substring(0, 50));
        }
      } catch (error) {
        console.warn('[CSDN适配器] 图片上传失败:', src, error);
      }
    }
    
    return result;
  }

  /**
   * 上传图片到 CSDN 图床
   */
  async uploadImage(src) {
    // 下载图片
    let blob;
    if (src.startsWith('data:')) {
      blob = await fetch(src).then(r => r.blob());
    } else {
      try {
        const response = await fetch(src);
        if (!response.ok) {
          console.warn('[CSDN适配器] 图片下载失败:', src);
          return src;
        }
        blob = await response.blob();
      } catch (error) {
        console.warn('[CSDN适配器] 图片下载失败:', src, error);
        return src;
      }
    }

    // 获取文件扩展名
    const ext = src.split('.').pop()?.toLowerCase()?.split('?')[0] || 'jpg';
    const validExt = ['jpg', 'jpeg', 'png', 'gif', 'webp'].includes(ext) ? ext : 'jpg';

    try {
      // 获取上传签名
      const apiPath = '/resource-api/v1/image/direct/upload/signature';
      const headers = await this.signRequest(apiPath, 'POST');

      const signatureRes = await fetch(`https://bizapi.csdn.net${apiPath}`, {
        method: 'POST',
        credentials: 'include',
        headers,
        body: JSON.stringify({
          imageTemplate: '',
          appName: 'direct_blog_markdown',
          imageSuffix: validExt
        })
      });

      const signatureData = await signatureRes.json();

      if (signatureData.code !== 200 || !signatureData.data) {
        console.warn('[CSDN适配器] 获取上传签名失败');
        return src;
      }

      const uploadData = signatureData.data;
      const customParam = uploadData.customParam;

      // 上传到华为云 OBS
      const formData = new FormData();
      formData.append('key', uploadData.filePath);
      formData.append('policy', uploadData.policy);
      formData.append('signature', uploadData.signature);
      formData.append('callbackBody', uploadData.callbackBody);
      formData.append('callbackBodyType', uploadData.callbackBodyType);
      formData.append('callbackUrl', uploadData.callbackUrl);
      formData.append('AccessKeyId', uploadData.accessId);
      formData.append('x:rtype', customParam.rtype);
      formData.append('x:filePath', customParam.filePath);
      formData.append('x:isAudit', String(customParam.isAudit));
      formData.append('x:x-image-app', customParam['x-image-app']);
      formData.append('x:type', customParam.type);
      formData.append('x:x-image-suffix', customParam['x-image-suffix']);
      formData.append('x:username', customParam.username);
      formData.append('file', blob, `image.${validExt}`);

      const obsResponse = await fetch(uploadData.host, {
        method: 'POST',
        body: formData
      });

      const obsRes = await obsResponse.json();

      if (obsRes.code !== 200 || !obsRes.data?.imageUrl) {
        console.warn('[CSDN适配器] OBS 上传失败');
        return src;
      }

      return obsRes.data.imageUrl;
    } catch (error) {
      console.warn('[CSDN适配器] 图片上传失败:', error);
      return src;
    }
  }

  /**
   * 简单的 HTML 转 Markdown
   */
  htmlToMarkdown(html) {
    let md = html;
    
    // 标题
    md = md.replace(/<h1[^>]*>(.*?)<\/h1>/gi, '# $1\n\n');
    md = md.replace(/<h2[^>]*>(.*?)<\/h2>/gi, '## $1\n\n');
    md = md.replace(/<h3[^>]*>(.*?)<\/h3>/gi, '### $1\n\n');
    md = md.replace(/<h4[^>]*>(.*?)<\/h4>/gi, '#### $1\n\n');
    md = md.replace(/<h5[^>]*>(.*?)<\/h5>/gi, '##### $1\n\n');
    md = md.replace(/<h6[^>]*>(.*?)<\/h6>/gi, '###### $1\n\n');
    
    // 粗体和斜体
    md = md.replace(/<strong[^>]*>(.*?)<\/strong>/gi, '**$1**');
    md = md.replace(/<b[^>]*>(.*?)<\/b>/gi, '**$1**');
    md = md.replace(/<em[^>]*>(.*?)<\/em>/gi, '*$1*');
    md = md.replace(/<i[^>]*>(.*?)<\/i>/gi, '*$1*');
    
    // 链接
    md = md.replace(/<a[^>]+href="([^"]+)"[^>]*>(.*?)<\/a>/gi, '[$2]($1)');
    
    // 图片
    md = md.replace(/<img[^>]+src="([^"]+)"[^>]*alt="([^"]*)"[^>]*>/gi, '![$2]($1)');
    md = md.replace(/<img[^>]+src="([^"]+)"[^>]*>/gi, '![]($1)');
    
    // 代码块
    md = md.replace(/<pre[^>]*><code[^>]*class="language-(\w+)"[^>]*>([\s\S]*?)<\/code><\/pre>/gi, '```$1\n$2\n```\n\n');
    md = md.replace(/<pre[^>]*><code[^>]*>([\s\S]*?)<\/code><\/pre>/gi, '```\n$1\n```\n\n');
    md = md.replace(/<code[^>]*>(.*?)<\/code>/gi, '`$1`');
    
    // 引用
    md = md.replace(/<blockquote[^>]*>([\s\S]*?)<\/blockquote>/gi, (match, content) => {
      return content.split('\n').map(line => '> ' + line.trim()).join('\n') + '\n\n';
    });
    
    // 列表
    md = md.replace(/<ul[^>]*>([\s\S]*?)<\/ul>/gi, (match, content) => {
      return content.replace(/<li[^>]*>(.*?)<\/li>/gi, '- $1\n') + '\n';
    });
    md = md.replace(/<ol[^>]*>([\s\S]*?)<\/ol>/gi, (match, content) => {
      let index = 1;
      return content.replace(/<li[^>]*>(.*?)<\/li>/gi, () => `${index++}. $1\n`) + '\n';
    });
    
    // 段落
    md = md.replace(/<p[^>]*>([\s\S]*?)<\/p>/gi, '$1\n\n');
    
    // 换行
    md = md.replace(/<br\s*\/?>/gi, '\n');
    
    // 水平线
    md = md.replace(/<hr[^>]*>/gi, '---\n\n');
    
    // 移除其他 HTML 标签
    md = md.replace(/<[^>]+>/g, '');
    
    // 解码 HTML 实体
    md = md.replace(/&nbsp;/g, ' ');
    md = md.replace(/&lt;/g, '<');
    md = md.replace(/&gt;/g, '>');
    md = md.replace(/&amp;/g, '&');
    md = md.replace(/&quot;/g, '"');
    
    // 清理多余空行
    md = md.replace(/\n{3,}/g, '\n\n');
    
    return md.trim();
  }

  /**
   * 注入脚本（保留作为降级方案）
   */
  static injectScript(articleData) {
    console.log('[CSDN适配器] 使用降级方案：DOM 注入');
    
    function waitForElement(selector, timeout) {
      timeout = timeout || 10000;
      return new Promise(function(resolve, reject) {
        var element = document.querySelector(selector);
        if (element) {
          resolve(element);
          return;
        }

        var observer = new MutationObserver(function() {
          var el = document.querySelector(selector);
          if (el) {
            resolve(el);
            observer.disconnect();
          }
        });

        observer.observe(document.body, {
          childList: true,
          subtree: true
        });

        setTimeout(function() {
          observer.disconnect();
          reject(new Error('Element "' + selector + '" not found'));
        }, timeout);
      });
    }

    async function main() {
      try {
        var titleInput = await waitForElement('input.article-bar__title, input[placeholder*="标题"]', 15000);
        titleInput.value = (articleData.title || '').slice(0, 100);
        titleInput.dispatchEvent(new Event('input', { bubbles: true }));
        
        var editor = await waitForElement('.editor__inner .ql-editor, .ql-editor, [contenteditable="true"]', 10000);
        editor.focus();
        
        var clipboardData = new DataTransfer();
        clipboardData.setData('text/html', articleData.htmlContent || '');
        
        var pasteEvent = new ClipboardEvent('paste', {
          bubbles: true,
          cancelable: true,
          clipboardData: clipboardData
        });
        
        editor.dispatchEvent(pasteEvent);
        console.log('[CSDN适配器] DOM 注入完成');
      } catch (error) {
        console.error('[CSDN适配器] DOM 注入失败:', error);
      }
    }
    
    setTimeout(main, 2000);
  }

  get injectScript() {
    return CsdnAdapter.injectScript;
  }
}
