// LoginChecker - 平台登录状态检测
// 通过检查 cookie 判断用户是否已登录各平台

/**
 * 平台登录检测配置
 */
const PLATFORM_COOKIES = {
  zhihu: {
    url: 'https://www.zhihu.com',
    name: 'z_c0',
    displayName: '知乎'
  },
  juejin: {
    url: 'https://juejin.cn',
    name: 'sessionid',
    displayName: '掘金'
  },
  csdn: {
    url: 'https://www.csdn.net',
    name: 'UserToken',
    displayName: 'CSDN'
  },
  weixin: {
    url: 'https://mp.weixin.qq.com',
    name: 'slave_user',
    displayName: '微信公众号'
  },
  jianshu: {
    url: 'https://www.jianshu.com',
    name: 'remember_user_token',
    displayName: '简书'
  }
};

/**
 * 登录状态检测器
 */
export class LoginChecker {
  /**
   * 检查单个平台的登录状态
   * @param {string} platform - 平台标识
   * @returns {Promise<Object>} 登录状态
   */
  async checkPlatform(platform) {
    const config = PLATFORM_COOKIES[platform];
    
    if (!config) {
      return {
        platform,
        isLoggedIn: false,
        error: '不支持的平台'
      };
    }

    try {
      const cookie = await chrome.cookies.get({
        url: config.url,
        name: config.name
      });

      return {
        platform,
        displayName: config.displayName,
        isLoggedIn: !!cookie,
        loginUrl: this.getLoginUrl(platform)
      };
    } catch (error) {
      console.error(`[LoginChecker] 检查 ${platform} 登录状态失败:`, error);
      return {
        platform,
        displayName: config.displayName,
        isLoggedIn: false,
        error: error.message
      };
    }
  }

  /**
   * 批量检查多个平台的登录状态
   * @param {string[]} platforms - 平台列表
   * @returns {Promise<Object[]>} 登录状态列表
   */
  async checkPlatforms(platforms) {
    const results = await Promise.all(
      platforms.map(platform => this.checkPlatform(platform))
    );
    return results;
  }

  /**
   * 获取平台登录页面 URL
   * @param {string} platform - 平台标识
   * @returns {string} 登录页面 URL
   */
  getLoginUrl(platform) {
    const urls = {
      zhihu: 'https://www.zhihu.com/signin',
      juejin: 'https://juejin.cn/login',
      csdn: 'https://passport.csdn.net/login',
      weixin: 'https://mp.weixin.qq.com/',
      jianshu: 'https://www.jianshu.com/sign_in'
    };
    return urls[platform] || '';
  }

  /**
   * 打开平台登录页面
   * @param {string} platform - 平台标识
   */
  async openLoginPage(platform) {
    const url = this.getLoginUrl(platform);
    if (url) {
      await chrome.tabs.create({ url, active: true });
    }
  }
}
