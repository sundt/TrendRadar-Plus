// Publish Module - 发布功能入口
// 管理多平台发布流程

import { PublishManager } from './manager.js';
import { LoginChecker } from './login-checker.js';

// 创建单例
const publishManager = new PublishManager();
const loginChecker = new LoginChecker();

/**
 * 设置发布相关的消息监听器
 */
export function setupPublishMessageListeners() {
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    // 检查插件是否安装
    if (message.type === 'PUBLISH_CHECK_INSTALLED') {
      sendResponse({
        success: true,
        data: {
          installed: true,
          version: chrome.runtime.getManifest().version,
          supportedPlatforms: publishManager.getSupportedPlatforms()
        }
      });
      return false;
    }

    // 检查平台登录状态
    if (message.type === 'PUBLISH_CHECK_LOGIN') {
      loginChecker.checkPlatforms(message.platforms)
        .then(results => sendResponse({ success: true, data: results }))
        .catch(error => sendResponse({ success: false, error: error.message }));
      return true;
    }

    // 发布文章
    if (message.type === 'PUBLISH_ARTICLE') {
      publishManager.publish(message.platforms, message.articleData)
        .then(results => sendResponse({ success: true, data: results }))
        .catch(error => sendResponse({ success: false, error: error.message }));
      return true;
    }

    // 获取发布状态
    if (message.type === 'PUBLISH_GET_STATUS') {
      const status = publishManager.getStatus(message.taskId);
      sendResponse({ success: true, data: status });
      return false;
    }

    // 取消发布
    if (message.type === 'PUBLISH_CANCEL') {
      publishManager.cancel(message.taskId);
      sendResponse({ success: true });
      return false;
    }
  });
}

export { publishManager, loginChecker };
