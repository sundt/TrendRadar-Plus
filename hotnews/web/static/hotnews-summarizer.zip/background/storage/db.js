// SummaryDB - IndexedDB Database using Dexie.js
// Core storage layer for the self-evolving summarizer

import Dexie from './dexie.min.mjs';

/**
 * Database schema for the summarizer extension
 * @type {Dexie}
 */
class SummaryDB extends Dexie {
    constructor() {
        super('SummarizerBrain');

        this.version(1).stores({
            // Main summaries table
            // Stores the actual summary content and metadata
            summaries: `
                ++id,
                url,
                title,
                type,
                createdAt,
                updatedAt,
                score,
                isFavorite,
                parentId,
                promptId
            `.replace(/\s+/g, ''),

            // Vector embeddings (separate for performance)
            // Stores Float32Array embeddings keyed by summary ID
            vectors: `
                summaryId,
                model
            `.replace(/\s+/g, ''),

            // Prompt version history
            // Tracks evolution of prompts over time
            promptVersions: `
                ++id,
                promptId,
                version,
                createdAt,
                parentVersionId
            `.replace(/\s+/g, ''),

            // Evolution logs
            // Records when and why the system improved itself
            evolutionLogs: `
                ++id,
                timestamp,
                type,
                oldPromptVersionId,
                newPromptVersionId
            `.replace(/\s+/g, ''),

            // User feedback
            // Explicit signals (thumbs up/down)
            feedback: `
                ++id,
                summaryId,
                type,
                timestamp
            `.replace(/\s+/g, ''),

            // Todos extracted from summaries
            todos: `
                ++id,
                summaryId,
                status,
                priority,
                createdAt
            `.replace(/\s+/g, '')
        });

        // Define table types
        this.summaries = this.table('summaries');
        this.vectors = this.table('vectors');
        this.promptVersions = this.table('promptVersions');
        this.evolutionLogs = this.table('evolutionLogs');
        this.feedback = this.table('feedback');
        this.todos = this.table('todos');
    }
}

// Singleton instance
let dbInstance = null;

/**
 * Get the database instance (singleton)
 * @returns {SummaryDB}
 */
export function getDB() {
    if (!dbInstance) {
        dbInstance = new SummaryDB();
    }
    return dbInstance;
}

/**
 * Summary record structure
 * @typedef {Object} SummaryRecord
 * @property {number} id - Auto-incremented ID
 * @property {string} url - Source URL
 * @property {string} title - Page title
 * @property {string} type - Article type (tech-tutorial, news, etc.)
 * @property {string} content - The actual summary (Markdown)
 * @property {string} originalContent - Original page content (truncated for storage)
 * @property {number} createdAt - Timestamp
 * @property {number} updatedAt - Timestamp
 * @property {number} score - Quality score (0-100)
 * @property {boolean} isFavorite - User favorited
 * @property {number|null} parentId - If this is a revision, points to original
 * @property {string} promptId - Which prompt template was used
 * @property {Object} metadata - Additional metadata (model, provider, etc.)
 */

/**
 * Save a new summary to the database
 * @param {Partial<SummaryRecord>} summary 
 * @returns {Promise<number>} The new summary ID
 */
export async function saveSummary(summary) {
    const db = getDB();
    const now = Date.now();

    const record = {
        url: summary.url || '',
        title: summary.title || 'Untitled',
        type: summary.type || 'other',
        content: summary.content || '',
        originalContent: (summary.originalContent || '').substring(0, 10000), // Limit storage
        createdAt: now,
        updatedAt: now,
        score: summary.score || 0,
        isFavorite: summary.isFavorite || false,
        parentId: summary.parentId || null,
        promptId: summary.promptId || 'unknown',
        metadata: summary.metadata || {}
    };

    const id = await db.summaries.add(record);
    console.log(`[SummaryDB] Saved summary #${id}: "${record.title}"`);
    return id;
}

/**
 * Get a summary by ID
 * @param {number} id 
 * @returns {Promise<SummaryRecord|undefined>}
 */
export async function getSummary(id) {
    const db = getDB();
    return db.summaries.get(id);
}

/**
 * Get all summaries, optionally filtered
 * @param {Object} options
 * @param {number} options.limit - Max results
 * @param {number} options.offset - Skip results
 * @param {boolean} options.favoritesOnly - Only favorites
 * @param {string} options.type - Filter by type
 * @returns {Promise<SummaryRecord[]>}
 */
export async function getSummaries(options = {}) {
    const db = getDB();
    let collection = db.summaries.orderBy('createdAt').reverse();

    if (options.favoritesOnly) {
        collection = db.summaries.where('isFavorite').equals(1);
    }

    if (options.type) {
        collection = collection.filter(s => s.type === options.type);
    }

    if (options.offset) {
        collection = collection.offset(options.offset);
    }

    if (options.limit) {
        collection = collection.limit(options.limit);
    }

    return collection.toArray();
}

/**
 * Update a summary's score or favorite status
 * @param {number} id 
 * @param {Partial<SummaryRecord>} updates 
 */
export async function updateSummary(id, updates) {
    const db = getDB();
    await db.summaries.update(id, {
        ...updates,
        updatedAt: Date.now()
    });
}

/**
 * Toggle favorite status
 * @param {number} id 
 * @returns {Promise<boolean>} New favorite status
 */
export async function toggleFavorite(id) {
    const db = getDB();
    const summary = await db.summaries.get(id);
    if (!summary) return false;

    const newStatus = !summary.isFavorite;
    await db.summaries.update(id, {
        isFavorite: newStatus,
        updatedAt: Date.now()
    });

    // Boost score for favorites
    if (newStatus) {
        const newScore = Math.min(100, (summary.score || 0) + 10);
        await db.summaries.update(id, { score: newScore });
    }

    return newStatus;
}

/**
 * Delete a summary
 * @param {number} id 
 */
export async function deleteSummary(id) {
    const db = getDB();
    await db.transaction('rw', [db.summaries, db.vectors, db.feedback, db.todos], async () => {
        await db.summaries.delete(id);
        await db.vectors.where('summaryId').equals(id).delete();
        await db.feedback.where('summaryId').equals(id).delete();
        await db.todos.where('summaryId').equals(id).delete();
    });
}

/**
 * Get top-rated summaries for learning
 * @param {number} limit 
 * @param {number} minScore 
 * @returns {Promise<SummaryRecord[]>}
 */
export async function getTopSummaries(limit = 20, minScore = 70) {
    const db = getDB();
    return db.summaries
        .where('score')
        .aboveOrEqual(minScore)
        .reverse()
        .sortBy('score')
        .then(results => results.slice(0, limit));
}

/**
 * Get summaries needing improvement
 * @param {number} limit 
 * @param {number} maxScore 
 * @returns {Promise<SummaryRecord[]>}
 */
export async function getLowScoreSummaries(limit = 20, maxScore = 50) {
    const db = getDB();
    return db.summaries
        .where('score')
        .belowOrEqual(maxScore)
        .limit(limit)
        .toArray();
}

/**
 * Get database statistics
 * @returns {Promise<Object>}
 */
export async function getStats() {
    const db = getDB();
    const [totalSummaries, favorites, avgScore] = await Promise.all([
        db.summaries.count(),
        db.summaries.where('isFavorite').equals(1).count(),
        db.summaries.toArray().then(summaries => {
            if (summaries.length === 0) return 0;
            const total = summaries.reduce((sum, s) => sum + (s.score || 0), 0);
            return Math.round(total / summaries.length);
        })
    ]);

    return {
        totalSummaries,
        favorites,
        avgScore
    };
}

export { SummaryDB };
