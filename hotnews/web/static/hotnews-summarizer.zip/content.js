// Custom Summarizer - Content Script
// 浮动按钮 + 提示词选择菜单，选择后打开侧边栏

// ============ 早期注入（document_start 时机）============
// 立即注入标记，确保在页面 JS 执行前完成
(function earlyInject() {
  try {
    document.documentElement.setAttribute('data-hotnews-summarizer', 'installed');
    document.documentElement.setAttribute('data-hotnews-summarizer-version', chrome.runtime.getManifest().version);
    
    // 检测是否需要自动打开侧边栏（从 hotnews 网站跳转过来）
    const url = new URL(window.location.href);
    if (url.searchParams.get('hotnews_auto_summarize') === '1') {
      // 移除 URL 参数（避免刷新时重复触发）
      url.searchParams.delete('hotnews_auto_summarize');
      window.history.replaceState({}, '', url.toString());
      
      // 标记需要自动总结
      document.documentElement.setAttribute('data-hotnews-auto-summarize', 'pending');
    }
  } catch (e) {
    // 忽略错误（可能在特殊页面）
  }
})();

// ============ 监听网站触发侧边栏事件 ============
window.addEventListener('hotnews-summarizer-open-sidepanel', (e) => {
  const { url, title, newsId } = e.detail || {};
  
  // 立即发送确认（在实际打开之前）
  window.dispatchEvent(new CustomEvent('hotnews-summarizer-sidepanel-ack'));
  
  // 发送消息给 background 打开侧边栏
  if (chrome?.runtime?.id) {
    chrome.runtime.sendMessage({ 
      type: 'OPEN_SIDEPANEL_DIRECT', 
      url: url,
      title: title,
      newsId: newsId
    });
  }
});

(function() {
  'use strict';
  
  // 避免重复注入
  if (window.__customSummarizerInjected) return;
  window.__customSummarizerInjected = true;

  // ============ Readability 简化实现 ============
  function extractContent() {
    // 尝试找到主要内容区域（直接从真实 DOM 查找）
    // WeChat MP articles have specific selectors
    const contentSelectors = [
      // WeChat MP article content (highest priority)
      '#js_content',
      '.rich_media_content',
      // Generic article selectors
      'article',
      '[role="main"]',
      'main',
      '.post-content',
      '.article-content',
      '.entry-content',
      '.content',
      '#content',
      '.post',
      '.article'
    ];
    
    let mainContent = null;
    for (const selector of contentSelectors) {
      const element = document.querySelector(selector);
      if (element && element.textContent.trim().length > 200) {
        mainContent = element;
        break;
      }
    }
    
    // 如果没找到，使用 body
    if (!mainContent) {
      mainContent = document.body;
    }
    
    // 克隆找到的内容区域（避免修改原始 DOM）
    const contentClone = mainContent.cloneNode(true);
    
    // 移除不需要的元素
    const removeSelectors = [
      'script', 'style', 'noscript', 'iframe', 'nav', 'header', 'footer',
      'aside', '.sidebar', '.nav', '.navigation', '.menu', '.ad', '.ads',
      '.advertisement', '.comment', '.comments', '#comments', '.social',
      '.share', '.related', '[role="navigation"]', '[role="banner"]',
      '[role="complementary"]', '.cookie', '.popup', '.modal',
      // WeChat specific: remove share/QR code prompts and tools
      '.qr_code_pc', '.qr_code_pc_outer', '#js_pc_qr_code', '.rich_media_tool',
      '.wx_qrcode', '.weui-desktop-qrcode', '#js_share_source',
      '.rich_media_meta_list', '.rich_media_meta', '#js_tags',
      '#js_profile_qrcode', '.profile_container', '.profile_inner',
      // Remove error/warning messages
      '.weui-msg', '.weui-desktop-msg', '.page_msg',
      // Remove more WeChat UI elements
      '#js_article_tag_name', '.rich_media_area_primary', '.rich_media_area_extra',
      '#js_toobar3', '#js_toobar_right', '.rich_media_tool_meta',
      // Remove any elements with "扫码" or "验证" in class/id
      '[class*="qrcode"]', '[id*="qrcode"]', '[class*="verify"]', '[id*="verify"]',
      '[class*="scan"]', '[id*="scan"]'
    ];
    
    removeSelectors.forEach(selector => {
      contentClone.querySelectorAll(selector).forEach(el => el.remove());
    });
    
    // 提取文本
    let text = '';
    const walker = document.createTreeWalker(
      contentClone,
      NodeFilter.SHOW_TEXT,
      null,
      false
    );
    
    let node;
    while (node = walker.nextNode()) {
      const trimmed = node.textContent.trim();
      if (trimmed.length > 0) {
        text += trimmed + '\n';
      }
    }
    
    // 清理多余空行
    text = text.replace(/\n{3,}/g, '\n\n').trim();
    
    // For WeChat articles: remove common UI text that might trigger anti-crawler detection
    if (window.location.hostname === 'mp.weixin.qq.com') {
      const cleanupPatterns = [
        /请使用微信扫[码描].*?$/gm,
        /微信扫[码描].*?$/gm,
        /长按识别二维码.*?$/gm,
        /关注公众号.*?$/gm,
        /点击.*?关注.*?$/gm,
        /^视频号$/gm,
        /^公众号$/gm,
        /^分享.*?$/gm,
        /^收藏$/gm,
        /^赞$/gm,
        /^在看$/gm
      ];
      
      cleanupPatterns.forEach(pattern => {
        text = text.replace(pattern, '');
      });
      
      // Clean up again after removal
      text = text.replace(/\n{3,}/g, '\n\n').trim();
      
      // Debug: log first 500 chars to console
      console.log('[Content Extractor] WeChat article extracted:', {
        length: text.length,
        preview: text.substring(0, 500)
      });
    }
    
    return {
      title: document.title,
      content: text,
      url: window.location.href
    };
  }

  // ============ 状态管理 ============
  let currentPrompts = [];
  let selectedPromptId = null;

  let selectionTodoBtn = null;

  // ============ UI 组件 ============
  
  function clampNumber(value, min, max) {
    const n = Number(value);
    if (!Number.isFinite(n)) return min;
    return Math.min(max, Math.max(min, n));
  }
  
  let cachedSafeAreaInsets = null;
  
  function getSafeAreaInsets() {
    if (cachedSafeAreaInsets) return cachedSafeAreaInsets;
    const probe = document.createElement('div');
    probe.style.cssText = 'position: fixed; top: 0; left: 0; width: 0; height: 0; padding: env(safe-area-inset-top) env(safe-area-inset-right) env(safe-area-inset-bottom) env(safe-area-inset-left); visibility: hidden; pointer-events: none;';
    document.documentElement.appendChild(probe);
    const style = getComputedStyle(probe);
    const insets = {
      top: parseFloat(style.paddingTop) || 0,
      right: parseFloat(style.paddingRight) || 0,
      bottom: parseFloat(style.paddingBottom) || 0,
      left: parseFloat(style.paddingLeft) || 0
    };
    probe.remove();
    cachedSafeAreaInsets = insets;
    return insets;
  }
  
  function getMinMargins() {
    const insets = getSafeAreaInsets();
    return {
      right: Math.max(0, insets.right),
      bottom: Math.max(8, insets.bottom + 4)
    };
  }
  
  function getBoundsForElement(element, margins) {
    const rect = element.getBoundingClientRect();
    const maxRight = Math.max(margins.right, window.innerWidth - rect.width - margins.right);
    const maxBottom = Math.max(margins.bottom, window.innerHeight - rect.height - margins.bottom);
    return { rightMin: margins.right, bottomMin: margins.bottom, maxRight, maxBottom };
  }
  
  function readRightBottomFromRect(element) {
    const rect = element.getBoundingClientRect();
    return {
      right: window.innerWidth - rect.right,
      bottom: window.innerHeight - rect.bottom
    };
  }
  
  function applyPosition(element, right, bottom) {
    element.style.right = `${right}px`;
    element.style.bottom = `${bottom}px`;
    element.style.left = 'auto';
    element.style.top = 'auto';
  }
  
  function normalizePosition(element, position, margins) {
    const bounds = getBoundsForElement(element, margins);
    const raw = {
      right: position?.right,
      bottom: position?.bottom
    };
    
    let right = clampNumber(raw.right, bounds.rightMin, bounds.maxRight);
    let bottom = clampNumber(raw.bottom, bounds.bottomMin, bounds.maxBottom);
    
    if (position?.dock === 'right') {
      right = bounds.rightMin;
    } else if (position?.dock === 'left') {
      right = bounds.maxRight;
    }
    
    applyPosition(element, right, bottom);
    return { right, bottom, dock: position?.dock };
  }
  
  // 创建浮动按钮容器
  function createFloatingButton() {
    const container = document.createElement('div');
    container.id = 'cs-floating-container';
    
    // 获取扩展的图标 URL
    const iconUrl = chrome.runtime.getURL('icons/icon48.png');
    
    container.innerHTML = `
      <div id="cs-floating-btn" title="AI 总结">
        <img src="${iconUrl}" alt="uihash" style="width: 100%; height: 100%; border-radius: 50%; object-fit: cover;">
      </div>
    `;
    document.body.appendChild(container);
    
    const button = document.getElementById('cs-floating-btn');
    
    // 点击按钮直接打开侧边栏
    button.addEventListener('click', (e) => {
      e.stopPropagation();
      openSidepanelDirectly();
    });
    
    // 拖拽功能
    makeDraggable(container);
    
    return container;
  }
  
  // 直接打开侧边栏（同一文章只总结一次）
  function openSidepanelDirectly() {
    const normalizedUrl = normalizeUrl(location.href);
    safeSendMessage({ type: 'OPEN_SIDEPANEL_DIRECT', url: normalizedUrl });
  }

  let extensionContextInvalidated = false;
  function safeSendMessage(message, callback) {
    if (extensionContextInvalidated) return;
    if (!chrome?.runtime?.id) {
      extensionContextInvalidated = true;
      return;
    }
    try {
      chrome.runtime.sendMessage(message, (response) => {
        const err = chrome.runtime?.lastError;
        const msg = err?.message || '';
        if (msg && msg.includes('Extension context invalidated')) {
          extensionContextInvalidated = true;
          return;
        }
        if (callback) callback(response);
      });
    } catch (e) {
      const msg = e?.message || String(e);
      if (msg.includes('Extension context invalidated')) {
        extensionContextInvalidated = true;
        return;
      }
      throw e;
    }
  }

  // 归一化 URL（去掉 hash）
  function normalizeUrl(href) {
    try {
      const u = new URL(href);
      u.hash = '';
      return u.toString();
    } catch {
      return href.split('#')[0];
    }
  }

  // 标记已总结过的页面（存储在 session），返回是否可以总结
  function markIfNotSummarized(url) {
    return new Promise((resolve) => {
      chrome.storage.session.get(['csSummarized'], (res) => {
        const map = res.csSummarized || {};
        if (map[url]) {
          resolve(false);
          return;
        }
        map[url] = Date.now();
        chrome.storage.session.set({ csSummarized: map }, () => resolve(true));
      });
    });
  }
  
  // 显示点击扩展图标的提示
  function showClickIconHint(error) {
    // 避免重复显示
    if (document.getElementById('cs-click-icon-hint')) return;
    
    const hint = document.createElement('div');
    hint.id = 'cs-click-icon-hint';
    hint.innerHTML = `
      <div style="
        position: fixed;
        top: 20px;
        right: 20px;
        background: #333;
        color: white;
        padding: 12px 16px;
        border-radius: 8px;
        z-index: 2147483647;
        font-size: 14px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        animation: slideIn 0.3s ease;
      ">
        <style>
          @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
          }
        </style>
        请点击右上角的扩展图标打开侧边栏 📌<br/>
        ${error ? `<div style="margin-top:6px;font-size:12px;color:#ffdd99;">原因：${error}</div>` : ''}
      </div>
    `;
    document.body.appendChild(hint);
    
    setTimeout(() => {
      hint.remove();
    }, 4000);
  }
  
  // 显示自动总结提示（从 hotnews 跳转过来时）
  function showAutoSummarizeHint() {
    // 避免重复显示
    if (document.getElementById('cs-auto-summarize-hint')) return;
    
    const hint = document.createElement('div');
    hint.id = 'cs-auto-summarize-hint';
    hint.innerHTML = `
      <div style="
        position: fixed;
        top: 20px;
        right: 20px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 16px 20px;
        border-radius: 12px;
        z-index: 2147483647;
        font-size: 14px;
        box-shadow: 0 8px 24px rgba(102, 126, 234, 0.4);
        animation: slideIn 0.3s ease;
        max-width: 280px;
      ">
        <style>
          @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
          }
          #cs-auto-summarize-hint .hint-btn {
            display: inline-block;
            margin-top: 12px;
            padding: 8px 16px;
            background: rgba(255,255,255,0.2);
            border: 1px solid rgba(255,255,255,0.3);
            border-radius: 20px;
            color: white;
            font-size: 13px;
            cursor: pointer;
            transition: all 0.2s;
          }
          #cs-auto-summarize-hint .hint-btn:hover {
            background: rgba(255,255,255,0.3);
          }
          #cs-auto-summarize-hint .hint-close {
            position: absolute;
            top: 8px;
            right: 8px;
            width: 20px;
            height: 20px;
            border: none;
            background: rgba(255,255,255,0.2);
            color: white;
            border-radius: 50%;
            cursor: pointer;
            font-size: 12px;
            line-height: 20px;
            text-align: center;
          }
        </style>
        <button class="hint-close" onclick="this.closest('#cs-auto-summarize-hint').remove()">✕</button>
        <div style="font-weight: 600; margin-bottom: 6px;">✨ 点击开始 AI 总结</div>
        <div style="font-size: 13px; opacity: 0.9;">点击下方按钮或右下角浮标开始总结这篇文章</div>
        <button class="hint-btn" id="cs-auto-summarize-btn">🚀 立即总结</button>
      </div>
    `;
    document.body.appendChild(hint);
    
    // 绑定点击事件
    const btn = document.getElementById('cs-auto-summarize-btn');
    if (btn) {
      btn.addEventListener('click', () => {
        hint.remove();
        openSidepanelDirectly();
      });
    }
    
    // 10秒后自动消失
    setTimeout(() => {
      if (hint.parentNode) {
        hint.remove();
      }
    }, 10000);
  }
  
  // 监听来自 background 的消息
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'SHOW_CLICK_ICON_HINT') {
      showClickIconHint(message.error);
      return false; // 不需要异步响应
    }
    return false;
  });
  
  // 拖拽功能
  function makeDraggable(element) {
    let isDragging = false;
    let hasMoved = false;
    let startX, startY, initialRight, initialBottom;
    let dragWidth = 0;
    let dragHeight = 0;
    let margins = getMinMargins();
    
    const button = element.querySelector('#cs-floating-btn');
    
    button.addEventListener('mousedown', (e) => {
      if (e.button !== 0) return;
      isDragging = true;
      hasMoved = false;
      margins = getMinMargins();
      startX = e.clientX;
      startY = e.clientY;
      const rect = element.getBoundingClientRect();
      dragWidth = rect.width;
      dragHeight = rect.height;
      // 计算相对于视口右下角的位置
      initialRight = window.innerWidth - rect.right;
      initialBottom = window.innerHeight - rect.bottom;
      e.preventDefault();
    });
    
    document.addEventListener('mousemove', (e) => {
      if (!isDragging) return;
      
      const dx = e.clientX - startX;
      const dy = e.clientY - startY;
      
      // 只有移动超过 5px 才认为是拖拽
      if (Math.abs(dx) > 5 || Math.abs(dy) > 5) {
        hasMoved = true;
      }
      
      // 使用 right 和 bottom 定位，这样视口变化时按钮不会被遮挡
      const maxRight = Math.max(margins.right, window.innerWidth - dragWidth - margins.right);
      const maxBottom = Math.max(margins.bottom, window.innerHeight - dragHeight - margins.bottom);
      const newRight = clampNumber(initialRight - dx, margins.right, maxRight);
      const newBottom = clampNumber(initialBottom - dy, margins.bottom, maxBottom);
      applyPosition(element, newRight, newBottom);
    });
    
    document.addEventListener('mouseup', () => {
      if (isDragging) {
        isDragging = false;
        if (hasMoved) {
          // 保存位置（使用 right 和 bottom）
          const { right: rawRight, bottom: rawBottom } = readRightBottomFromRect(element);
          const bounds = getBoundsForElement(element, margins);
          const right = clampNumber(rawRight, bounds.rightMin, bounds.maxRight);
          const bottom = clampNumber(rawBottom, bounds.bottomMin, bounds.maxBottom);
          const dock = right <= bounds.maxRight / 2 ? 'right' : 'left';
          const dockedRight = dock === 'right' ? bounds.rightMin : bounds.maxRight;
          applyPosition(element, dockedRight, bottom);
          safeSendMessage({
            type: 'SAVE_BUTTON_POSITION',
            position: { right: dockedRight, bottom, dock, userDragged: true }
          });
        }
      }
    });
  }
  
  // Toast 提示
  function showToast(message) {
    const existing = document.querySelector('.cs-toast');
    if (existing) existing.remove();
    
    const toast = document.createElement('div');
    toast.className = 'cs-toast';
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
      toast.classList.add('cs-toast-visible');
    }, 10);
    
    setTimeout(() => {
      toast.classList.remove('cs-toast-visible');
      setTimeout(() => toast.remove(), 300);
    }, 2000);
  }

  function addTodoFromSelection(text) {
    const trimmed = String(text || '').trim().replace(/\s+/g, ' ');
    if (!trimmed) return;

    const pageUrl = normalizeUrl(location.href);
    const todo = {
      id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
      createdAt: Date.now(),
      done: false,
      text: trimmed,
      source: {
        pageTitle: document.title || '未知页面',
        pageUrl
      }
    };

    chrome.storage.local.get(['todos'], (result) => {
      const list = Array.isArray(result.todos) ? result.todos : [];
      list.push(todo);
      chrome.storage.local.set({ todos: list }, () => {
        showToast('已添加到 Todo');
      });
    });
  }

  function initSelectionTodo() {
    // 创建选中文字工具栏（包含 +Todo 和 💬评论）
    const toolbar = document.createElement('div');
    toolbar.className = 'uihash-selection-toolbar';
    toolbar.style.display = 'none';
    toolbar.innerHTML = `
      <button class="uihash-toolbar-btn uihash-toolbar-todo" type="button">📋 +Todo</button>
      <button class="uihash-toolbar-btn uihash-toolbar-comment" type="button">💬 评论</button>
    `;
    document.body.appendChild(toolbar);

    // 保留旧引用兼容
    selectionTodoBtn = toolbar;

    const todoBtn = toolbar.querySelector('.uihash-toolbar-todo');
    const commentBtn = toolbar.querySelector('.uihash-toolbar-comment');

    const hide = () => {
      toolbar.style.display = 'none';
      toolbar.dataset.selectionText = '';
      toolbar._selectionRange = null;
    };

    const getSelectionData = () => {
      const sel = window.getSelection();
      if (!sel || sel.isCollapsed) return null;
      const text = sel.toString();
      if (!String(text || '').trim()) return null;

      const range = sel.rangeCount ? sel.getRangeAt(0) : null;
      if (!range) return null;

      const containerNode = range.commonAncestorContainer;
      const containerEl = containerNode?.nodeType === Node.ELEMENT_NODE ? containerNode : containerNode?.parentElement;
      if (!containerEl) return null;

      if (containerEl.closest && containerEl.closest('#cs-floating-container')) return null;
      if (containerEl.closest && containerEl.closest('.cs-toast')) return null;
      if (containerEl.closest && containerEl.closest('#cs-click-icon-hint')) return null;
      if (containerEl.closest && containerEl.closest('.uihash-selection-toolbar')) return null;
      if (containerEl.closest && containerEl.closest('.uihash-comment-input-popup')) return null;

      return { text, range };
    };

    const showForCurrentSelection = () => {
      const data = getSelectionData();
      if (!data) {
        hide();
        return;
      }

      const rect = data.range.getBoundingClientRect();
      if (!rect || (!rect.width && !rect.height)) {
        hide();
        return;
      }

      const toolbarWidth = 180;
      const toolbarHeight = 36;
      const margin = 8;
      const left = Math.min(window.innerWidth - toolbarWidth - margin, Math.max(margin, rect.left + (rect.width - toolbarWidth) / 2));
      const top = Math.min(window.innerHeight - toolbarHeight - margin, Math.max(margin, rect.bottom + margin));

      toolbar.style.left = `${left}px`;
      toolbar.style.top = `${top}px`;
      toolbar.style.display = 'flex';
      toolbar.dataset.selectionText = data.text;
      toolbar._selectionRange = data.range.cloneRange();
    };

    // +Todo 按钮
    todoBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      const text = toolbar.dataset.selectionText || '';
      addTodoFromSelection(text);
      try { window.getSelection()?.removeAllRanges(); } catch {}
      hide();
    });

    // 💬 评论按钮
    commentBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      const text = toolbar.dataset.selectionText || '';
      const range = toolbar._selectionRange;
      if (text && range) {
        showCommentInput(text, range);
      }
      hide();
    });

    document.addEventListener('mouseup', () => setTimeout(showForCurrentSelection, 0));
    document.addEventListener('keyup', () => setTimeout(showForCurrentSelection, 0));
    document.addEventListener('scroll', hide, true);
    window.addEventListener('resize', hide);
    document.addEventListener('mousedown', (e) => {
      if (toolbar.contains(e.target)) return;
      if (e.target.closest && e.target.closest('.uihash-comment-input-popup')) return;
      hide();
    });
  }

  // ============ 评论输入弹窗 ============

  function getXPath(node) {
    if (!node || node.nodeType !== Node.ELEMENT_NODE) {
      if (node && node.parentElement) return getXPath(node.parentElement);
      return '';
    }
    const parts = [];
    let el = node;
    while (el && el.nodeType === Node.ELEMENT_NODE) {
      let idx = 1;
      let sib = el.previousSibling;
      while (sib) {
        if (sib.nodeType === Node.ELEMENT_NODE && sib.nodeName === el.nodeName) idx++;
        sib = sib.previousSibling;
      }
      parts.unshift(`${el.nodeName.toLowerCase()}[${idx}]`);
      el = el.parentElement;
    }
    return '/' + parts.join('/');
  }

  function getTextContext(range, chars) {
    // 获取选区所在文本节点的上下文
    const startNode = range.startContainer;
    if (startNode.nodeType === Node.TEXT_NODE) {
      const fullText = startNode.textContent || '';
      const startIdx = Math.max(0, range.startOffset - chars);
      const endOffset = Math.min(fullText.length, range.endOffset);
      const endIdx = Math.min(fullText.length, endOffset + chars);
      return {
        before: fullText.slice(startIdx, range.startOffset),
        after: fullText.slice(endOffset, endIdx),
      };
    }
    // 降级：用选中文本前后的 body 文本
    return { before: '', after: '' };
  }

  function showCommentInput(selectedText, range) {
    // 移除已有弹窗
    const existing = document.querySelector('.uihash-comment-input-popup');
    if (existing) existing.remove();

    const rect = range.getBoundingClientRect();
    const context = getTextContext(range, 30);
    const xpath = getXPath(range.startContainer);

    const popup = document.createElement('div');
    popup.className = 'uihash-comment-input-popup';
    popup.innerHTML = `
      <div class="uihash-cip-quote">"${selectedText.length > 80 ? selectedText.slice(0, 80) + '...' : selectedText}"</div>
      <textarea class="uihash-cip-textarea" placeholder="写下你的想法..." rows="3"></textarea>
      <div class="uihash-cip-actions">
        <button class="uihash-cip-cancel" type="button">取消</button>
        <button class="uihash-cip-submit" type="button">发送</button>
      </div>
    `;

    // 定位
    const popupWidth = 320;
    const gap = 10;
    let left = Math.max(gap, Math.min(rect.left, window.innerWidth - popupWidth - gap));
    let top = rect.bottom + gap;
    if (top + 200 > window.innerHeight) {
      top = Math.max(gap, rect.top - 200 - gap);
    }
    popup.style.left = `${left}px`;
    popup.style.top = `${top}px`;

    document.body.appendChild(popup);

    const textarea = popup.querySelector('.uihash-cip-textarea');
    textarea.focus();

    // 存储定位信息
    popup._commentData = {
      selectedText,
      xpath,
      startOffset: range.startOffset,
      endOffset: range.endOffset,
      contextBefore: context.before,
      contextAfter: context.after,
    };

    popup.querySelector('.uihash-cip-cancel').addEventListener('click', () => popup.remove());

    popup.querySelector('.uihash-cip-submit').addEventListener('click', () => {
      const content = textarea.value.trim();
      if (!content) {
        textarea.focus();
        return;
      }
      submitComment(popup._commentData, content, popup);
    });

    // Escape 关闭
    textarea.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') popup.remove();
      if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        popup.querySelector('.uihash-cip-submit').click();
      }
    });
  }

  function submitComment(commentData, content, popup) {
    const submitBtn = popup.querySelector('.uihash-cip-submit');
    submitBtn.disabled = true;
    submitBtn.textContent = '发送中...';

    safeSendMessage({
      type: 'SUBMIT_COMMENT',
      data: {
        article_url: location.href,
        article_title: document.title || '',
        selected_text: commentData.selectedText,
        text_xpath: commentData.xpath,
        text_start_offset: commentData.startOffset,
        text_end_offset: commentData.endOffset,
        text_context_before: commentData.contextBefore,
        text_context_after: commentData.contextAfter,
        content: content,
      }
    }, (response) => {
      if (response && response.success) {
        showToast('评论发送成功');
        popup.remove();
        // 用 setTimeout 确保在当前消息回调结束后再发新消息
        setTimeout(() => loadAndRenderComments(), 50);
      } else {
        showToast(response?.error || '发送失败，请重试');
        submitBtn.disabled = false;
        submitBtn.textContent = '发送';
      }
    });
  }

  // ============ 高亮标注与悬停弹窗 ============

  let commentHighlights = []; // 当前页面的评论高亮数据
  let activePopup = null;     // 当前显示的弹窗
  let activePopupTrigger = null; // 触发弹窗的元素（用于焦点回退）
  let showTimer = null;
  let hideTimer = null;
  const SHOW_DELAY = 150;
  const HIDE_DELAY = 350;

  /**
   * 加载当前页面评论并渲染高亮
   */
  function loadAndRenderComments() {
    const url = normalizeUrl(location.href);
    console.log('[Comment] loadAndRenderComments for:', url);
    safeSendMessage({ type: 'GET_COMMENTS', url }, (response) => {
      console.log('[Comment] GET_COMMENTS response:', response?.success, 'data count:', Array.isArray(response?.data) ? response.data.length : 'not array');
      if (response && response.success && Array.isArray(response.data)) {
        commentHighlights = response.data;
        clearAllHighlights();
        renderAllHighlights(response.data);
      }
    });
  }

  /**
   * 刷新评论并重新打开指定 group 的弹窗
   */
  function refreshCommentsAndReopenPopup(groupId) {
    const url = normalizeUrl(location.href);
    safeSendMessage({ type: 'GET_COMMENTS', url }, (response) => {
      if (response && response.success && Array.isArray(response.data)) {
        commentHighlights = response.data;
        clearAllHighlights();
        renderAllHighlights(response.data);
        // 重新打开对应 group 的弹窗
        if (groupId) {
          const trigger = document.querySelector(`.uihash-commented[data-comment-group="${groupId}"]`);
          if (trigger) {
            const ids = (trigger.dataset.commentIds || '').split(',').map(Number);
            const groupComments = commentHighlights.filter(c => ids.includes(c.id));
            if (groupComments.length) {
              showCommentPopup(trigger, groupComments);
            }
          }
        }
      }
    });
  }

  function clearAllHighlights() {
    document.querySelectorAll('.uihash-comment-badge-inline').forEach(el => el.remove());
    document.querySelectorAll('.uihash-commented').forEach(el => {
      const parent = el.parentNode;
      if (!parent) return;
      while (el.firstChild) parent.insertBefore(el.firstChild, el);
      parent.removeChild(el);
      // 合并相邻文本节点，避免文本被拆分导致后续搜索失败
      parent.normalize();
    });
  }

  function renderAllHighlights(comments) {
    const groups = {};
    for (const c of comments) {
      if (!c.selected_text) continue;
      const key = (c.selected_text || '').trim();
      if (!key) continue;
      if (!groups[key]) groups[key] = [];
      groups[key].push(c);
    }
    console.log('[Comment Highlight] groups to render:', Object.keys(groups).length);
    for (const [text, groupComments] of Object.entries(groups)) {
      const firstComment = groupComments[0];
      const range = locateTextInPage(text, firstComment.text_position);
      if (!range) {
        console.warn('[Comment Highlight] text not found:', text.slice(0, 50));
        continue;
      }
      try {
        wrapRangeWithHighlight(range, groupComments);
      } catch (e) {
        console.warn('[Comment Highlight] surroundContents failed, trying fallback:', e.message);
        try {
          wrapRangeWithHighlightFallback(range, groupComments);
        } catch (e2) {
          console.warn('[Comment Highlight] fallback also failed:', e2.message);
        }
      }
    }
  }

  function locateTextInPage(selectedText, position) {
    if (!selectedText) return null;
    // 策略1: XPath + offset
    if (position && position.xpath) {
      try {
        const result = document.evaluate(position.xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
        const node = result.singleNodeValue;
        if (node) {
          const textNode = findTextNode(node, selectedText);
          if (textNode) {
            const range = document.createRange();
            const idx = textNode.textContent.indexOf(selectedText);
            if (idx >= 0) {
              range.setStart(textNode, idx);
              range.setEnd(textNode, idx + selectedText.length);
              console.log('[Comment Locate] found via XPath');
              return range;
            }
          }
        }
      } catch (e) { console.warn('[Comment Locate] XPath failed:', e.message); }
    }
    // 策略2: 上下文模糊匹配
    if (position && position.context_before) {
      const fullPattern = (position.context_before || '') + selectedText + (position.context_after || '');
      const range = searchTextInBody(fullPattern);
      if (range) {
        const offset = (position.context_before || '').length;
        try {
          const textRange = document.createRange();
          textRange.setStart(range.startContainer, range.startOffset + offset);
          textRange.setEnd(range.startContainer, range.startOffset + offset + selectedText.length);
          console.log('[Comment Locate] found via context match');
          return textRange;
        } catch (e) { console.warn('[Comment Locate] context range failed:', e.message); }
      }
    }
    // 策略3: 纯文本搜索
    const fallback = searchTextInBody(selectedText);
    if (fallback) {
      console.log('[Comment Locate] found via text search');
    } else {
      console.warn('[Comment Locate] text NOT found in page:', selectedText.slice(0, 60));
    }
    return fallback;
  }

  function findTextNode(root, text) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let node;
    while (node = walker.nextNode()) {
      if (node.textContent.includes(text)) return node;
    }
    return null;
  }

  function searchTextInBody(text) {
    if (!text) return null;
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let node;
    while (node = walker.nextNode()) {
      const idx = node.textContent.indexOf(text);
      if (idx >= 0) {
        const range = document.createRange();
        range.setStart(node, idx);
        range.setEnd(node, idx + text.length);
        return range;
      }
    }
    return null;
  }

  function wrapRangeWithHighlight(range, groupComments) {
    const groupId = 'cg-' + groupComments[0].id;
    const count = groupComments.length;
    const wrapper = document.createElement('span');
    wrapper.className = 'uihash-commented';
    wrapper.dataset.commentGroup = groupId;
    wrapper.dataset.commentIds = groupComments.map(c => c.id).join(',');
    wrapper.setAttribute('tabindex', '0');
    wrapper.setAttribute('role', 'button');
    wrapper.setAttribute('aria-label', `${count} 条评论`);
    range.surroundContents(wrapper);

    const badge = document.createElement('span');
    badge.className = 'uihash-comment-badge-inline';
    badge.textContent = count;
    wrapper.appendChild(badge);

    wrapper.addEventListener('mouseenter', () => onHighlightEnter(wrapper, groupComments));
    wrapper.addEventListener('mouseleave', () => onHighlightLeave());
    wrapper.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        showCommentPopup(wrapper, groupComments);
      }
    });
  }

  /**
   * 跨节点高亮降级方案：逐个文本节点包裹
   */
  function wrapRangeWithHighlightFallback(range, groupComments) {
    const groupId = 'cg-' + groupComments[0].id;
    const count = groupComments.length;

    // 收集 range 内的所有文本节点
    const textNodes = [];
    const walker = document.createTreeWalker(
      range.commonAncestorContainer,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode: (node) => {
          const nodeRange = document.createRange();
          nodeRange.selectNodeContents(node);
          // 检查是否与目标 range 有交集
          if (range.compareBoundaryPoints(Range.END_TO_START, nodeRange) < 0 &&
              range.compareBoundaryPoints(Range.START_TO_END, nodeRange) > 0) {
            return NodeFilter.FILTER_ACCEPT;
          }
          return NodeFilter.FILTER_REJECT;
        }
      }
    );

    let node;
    while (node = walker.nextNode()) {
      textNodes.push(node);
    }

    if (textNodes.length === 0) return;

    let firstWrapper = null;
    textNodes.forEach((textNode, i) => {
      const wrapper = document.createElement('span');
      wrapper.className = 'uihash-commented';
      wrapper.dataset.commentGroup = groupId;
      wrapper.dataset.commentIds = groupComments.map(c => c.id).join(',');

      // 确定包裹范围
      const nodeRange = document.createRange();
      if (textNode === range.startContainer) {
        nodeRange.setStart(textNode, range.startOffset);
      } else {
        nodeRange.setStart(textNode, 0);
      }
      if (textNode === range.endContainer) {
        nodeRange.setEnd(textNode, range.endOffset);
      } else {
        nodeRange.setEnd(textNode, textNode.length);
      }

      if (nodeRange.toString().trim().length === 0) return;

      nodeRange.surroundContents(wrapper);

      if (!firstWrapper) {
        firstWrapper = wrapper;
        wrapper.setAttribute('tabindex', '0');
        wrapper.setAttribute('role', 'button');
        wrapper.setAttribute('aria-label', `${count} 条评论`);
        // badge 只加在第一个片段
        const badge = document.createElement('span');
        badge.className = 'uihash-comment-badge-inline';
        badge.textContent = count;
        wrapper.appendChild(badge);
      }

      wrapper.addEventListener('mouseenter', () => onHighlightEnter(wrapper, groupComments));
      wrapper.addEventListener('mouseleave', () => onHighlightLeave());
    });

    if (firstWrapper) {
      firstWrapper.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          showCommentPopup(firstWrapper, groupComments);
        }
      });
    }
  }

  // 悬停延迟控制
  function onHighlightEnter(trigger, comments) {
    clearTimeout(hideTimer);
    showTimer = setTimeout(() => showCommentPopup(trigger, comments), SHOW_DELAY);
  }
  function onHighlightLeave() {
    clearTimeout(showTimer);
    hideTimer = setTimeout(() => hideCommentPopup(), HIDE_DELAY);
  }
  function onPopupEnter() {
    clearTimeout(hideTimer);
    clearTimeout(showTimer);
  }
  function onPopupLeave() {
    hideTimer = setTimeout(() => hideCommentPopup(), HIDE_DELAY);
  }

  function showCommentPopup(trigger, comments) {
    hideCommentPopup();
    const popup = document.createElement('div');
    popup.className = 'uihash-comment-popup';
    popup.setAttribute('role', 'dialog');
    popup.setAttribute('aria-label', '评论');

    // 记录 comment group 信息，用于刷新后重新打开
    const groupId = trigger.dataset?.commentGroup || '';
    popup.dataset.commentGroup = groupId;

    const header = `<div class="uihash-cp-header">${comments.length} 条评论</div>`;
    const list = comments.map(c => renderPopupComment(c)).join('');
    popup.innerHTML = `${header}<div class="uihash-cp-list">${list}</div>`;

    document.body.appendChild(popup);
    positionPopup(trigger, popup);

    popup.addEventListener('mouseenter', onPopupEnter);
    popup.addEventListener('mouseleave', onPopupLeave);

    popup.querySelectorAll('.uihash-cp-emoji-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const commentId = parseInt(btn.dataset.commentId);
        const emoji = btn.dataset.emoji;
        handleEmojiReaction(commentId, emoji, btn);
      });
    });

    // 回复按钮
    popup.querySelectorAll('.uihash-cp-reply-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const commentId = parseInt(btn.dataset.commentId);
        const userName = btn.dataset.userName;
        showPopupReplyInput(popup, commentId, userName);
      });
    });

    // 删除按钮
    popup.querySelectorAll('.uihash-cp-delete-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const commentId = parseInt(btn.dataset.commentId);
        handleDeleteComment(commentId, groupId);
      });
    });

    activePopup = popup;
    activePopupTrigger = trigger;
  }

  function hideCommentPopup() {
    if (activePopup) {
      activePopup.remove();
      activePopup = null;
    }
    if (activePopupTrigger) {
      activePopupTrigger.focus();
      activePopupTrigger = null;
    }
  }

  function renderPopupComment(comment) {
    const initial = (comment.user_name || '?')[0];
    const colors = ['#667eea', '#f56a00', '#7265e6', '#00a2ae', '#87d068'];
    const color = colors[Math.abs(hashStr(comment.user_name || '')) % colors.length];
    const timeStr = formatRelativeTime(comment.created_at);

    const emojis = ['👍', '🔥', '😂', '🤔', '❤️'];
    const reactions = comment.reactions || {};
    const myReactions = comment.my_reactions || [];
    const emojiHtml = emojis.map(e => {
      const cnt = reactions[e] || 0;
      const active = myReactions.includes(e) ? ' active' : '';
      return `<button class="uihash-cp-emoji-btn${active}" data-comment-id="${comment.id}" data-emoji="${e}">${e}${cnt ? `<span>${cnt}</span>` : ''}</button>`;
    }).join('');

    // 回复列表
    const repliesHtml = (comment.replies || []).map(r => {
      const prefix = r.reply_to_user_name ? `<span class="uihash-cp-reply-to">${escapeCommentHtml(r.user_name)} 回复 ${escapeCommentHtml(r.reply_to_user_name)}</span>` : `<span class="uihash-cp-reply-name">${escapeCommentHtml(r.user_name)}</span>`;
      return `<div class="uihash-cp-reply-item" data-id="${r.id}">${prefix}：${escapeCommentHtml(r.content)}</div>`;
    }).join('');

    return `
      <div class="uihash-cp-comment" data-id="${comment.id}">
        <div class="uihash-cp-avatar" style="background:${color}">${escapeCommentHtml(initial)}</div>
        <div class="uihash-cp-body">
          <div class="uihash-cp-meta">
            <span class="uihash-cp-name">${escapeCommentHtml(comment.user_name || '匿名')}</span>
            <span class="uihash-cp-time">${timeStr}</span>
          </div>
          <div class="uihash-cp-content">${escapeCommentHtml(comment.content)}</div>
          <div class="uihash-cp-reactions">${emojiHtml}<button class="uihash-cp-reply-btn" data-comment-id="${comment.id}" data-user-name="${escapeCommentHtml(comment.user_name || '')}">回复</button>${comment.is_mine ? `<button class="uihash-cp-delete-btn" data-comment-id="${comment.id}">删除</button>` : ''}</div>
          ${repliesHtml ? `<div class="uihash-cp-replies">${repliesHtml}</div>` : ''}
        </div>
      </div>`;
  }

  function escapeCommentHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  function hashStr(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = ((hash << 5) - hash) + str.charCodeAt(i);
      hash |= 0;
    }
    return hash;
  }

  function formatRelativeTime(ts) {
    if (!ts) return '';
    const now = Math.floor(Date.now() / 1000);
    const diff = now - ts;
    if (diff < 60) return '刚刚';
    if (diff < 3600) return Math.floor(diff / 60) + '分钟前';
    if (diff < 86400) return Math.floor(diff / 3600) + '小时前';
    if (diff < 2592000) return Math.floor(diff / 86400) + '天前';
    const d = new Date(ts * 1000);
    return `${d.getMonth() + 1}/${d.getDate()}`;
  }

  function positionPopup(triggerEl, popupEl) {
    const triggerRect = triggerEl.getBoundingClientRect();
    const popupHeight = 350;
    const popupWidth = 340;
    const gap = 10;

    const spaceBelow = window.innerHeight - triggerRect.bottom;
    const spaceAbove = triggerRect.top;
    let top, direction;

    if (spaceBelow >= popupHeight + gap) {
      top = triggerRect.bottom + gap;
      direction = 'below';
    } else if (spaceAbove >= popupHeight + gap) {
      top = triggerRect.top - popupHeight - gap;
      direction = 'above';
    } else {
      if (spaceBelow >= spaceAbove) {
        top = triggerRect.bottom + gap;
        direction = 'below';
      } else {
        top = Math.max(gap, triggerRect.top - popupHeight - gap);
        direction = 'above';
      }
    }

    let left = Math.max(gap, Math.min(triggerRect.left, window.innerWidth - popupWidth - gap));

    popupEl.style.position = 'fixed';
    popupEl.style.top = top + 'px';
    popupEl.style.left = left + 'px';
    popupEl.dataset.direction = direction;
  }

  function handleEmojiReaction(commentId, emoji, btn) {
    const isActive = btn.classList.contains('active');
    btn.classList.toggle('active');
    const countSpan = btn.querySelector('span');
    if (countSpan) {
      let cnt = parseInt(countSpan.textContent) || 0;
      cnt = isActive ? Math.max(0, cnt - 1) : cnt + 1;
      countSpan.textContent = cnt || '';
      if (!cnt) countSpan.remove();
    } else if (!isActive) {
      const s = document.createElement('span');
      s.textContent = '1';
      btn.appendChild(s);
    }

    safeSendMessage({ type: 'REACT_COMMENT', commentId, emoji }, (response) => {
      if (!response || !response.success) {
        btn.classList.toggle('active');
        showToast('操作失败，请重试');
      }
    });
  }

  function handleDeleteComment(commentId, groupId) {
    if (!confirm('确定删除这条评论吗？')) return;
    safeSendMessage({ type: 'DELETE_COMMENT', commentId }, (response) => {
      if (response && response.success) {
        showToast('已删除');
        hideCommentPopup();
        setTimeout(() => refreshCommentsAndReopenPopup(groupId), 50);
      } else {
        showToast(response?.error || '删除失败');
      }
    });
  }

  function showPopupReplyInput(popup, commentId, userName) {
    // 移除已有的回复输入框
    popup.querySelectorAll('.uihash-cp-reply-input-wrap').forEach(el => el.remove());

    const commentEl = popup.querySelector(`.uihash-cp-comment[data-id="${commentId}"]`);
    if (!commentEl) return;

    const wrap = document.createElement('div');
    wrap.className = 'uihash-cp-reply-input-wrap';
    wrap.innerHTML = `
      <input class="uihash-cp-reply-input" placeholder="回复 ${escapeCommentHtml(userName)}..." />
      <button class="uihash-cp-reply-send" type="button">发送</button>
    `;
    commentEl.querySelector('.uihash-cp-body').appendChild(wrap);

    const input = wrap.querySelector('.uihash-cp-reply-input');
    input.focus();

    const sendReply = () => {
      const text = input.value.trim();
      if (!text) return;
      const sendBtn = wrap.querySelector('.uihash-cp-reply-send');
      sendBtn.disabled = true;
      sendBtn.textContent = '...';
      safeSendMessage({ type: 'REPLY_COMMENT', commentId, content: text }, (response) => {
        if (response && response.success) {
          showToast('回复成功');
          wrap.remove();
          // 记住当前弹窗对应的 comment group，刷新后重新打开
          const groupId = popup.dataset?.commentGroup;
          hideCommentPopup();
          setTimeout(() => refreshCommentsAndReopenPopup(groupId), 50);
        } else {
          showToast(response?.error || '回复失败');
          sendBtn.disabled = false;
          sendBtn.textContent = '发送';
        }
      });
    };

    wrap.querySelector('.uihash-cp-reply-send').addEventListener('click', sendReply);
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { e.preventDefault(); sendReply(); }
      if (e.key === 'Escape') wrap.remove();
    });
  }

  // 全局关闭弹窗
  document.addEventListener('mousedown', (e) => {
    if (activePopup && !activePopup.contains(e.target) && !e.target.closest('.uihash-commented')) {
      hideCommentPopup();
    }
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && activePopup) hideCommentPopup();
  });

  // ============ 消息监听 ============
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    switch (message.type) {
      case 'EXTRACT_CONTENT':
        // 侧边栏请求提取页面内容（用于内容反哺）
        const extractedContent = extractContent();
        sendResponse(extractedContent);
        return true;

      case 'EXTRACT_AND_SUMMARIZE':
        // 侧边栏请求提取内容并总结
        const extracted = extractContent();
        if (extracted.content.length < 100) {
          showToast('页面内容不足，无法分析');
          sendResponse({ success: false, error: '页面内容不足' });
        } else {
          // 发送内容到 background 进行总结
          safeSendMessage({
            type: 'SUMMARIZE',
            content: extracted.content,
            pageTitle: extracted.title,
            pageUrl: extracted.url
          });
          sendResponse({ success: true });
        }
        return true;
        
      case 'TRIGGER_SUMMARIZE':
        // 从 popup 触发，直接打开侧边栏
        openSidepanelDirectly();
        sendResponse({ success: true });
        return true;

      case 'SHOW_TOAST':
        showToast(message.message || '');
        sendResponse({ success: true });
        return true;

      case 'REFRESH_COMMENTS':
        // 侧边栏发评论/回复后通知 content.js 刷新高亮
        setTimeout(() => loadAndRenderComments(), 50);
        sendResponse({ success: true });
        return true;
        
      case 'SHOW_CLICK_ICON_HINT':
        // 显示提示用户点击扩展图标
        showToast(message.message || '请点击扩展图标打开侧边栏');
        sendResponse({ success: true });
        return true;
        
      default:
        // 未知消息类型，不处理
        return false;
    }
  });

  // ============ 初始化 ============
  
  // 检查是否为不支持的页面类型
  function isUnsupportedPage(url) {
    if (!url) return true;
    if (url.startsWith('file://')) return true;
    if (url.startsWith('chrome://')) return true;
    if (url.startsWith('chrome-extension://')) return true;
    if (url.startsWith('edge://')) return true;
    if (url.startsWith('about:')) return true;
    return false;
  }
  
  function init() {
    // 不支持的页面不显示浮标
    if (isUnsupportedPage(location.href)) {
      console.log('[ContentScript] Unsupported page, skipping floating button');
      return;
    }
    
    createFloatingButton();
    initSelectionTodo();
    
    // 加载评论并渲染高亮
    setTimeout(() => loadAndRenderComments(), 1000);
    
    // 上报阅读行为
    setTimeout(() => {
      safeSendMessage({ type: 'RECORD_VIEW', data: { url: location.href, view_type: 'view' } });
    }, 2000);
    
    // 检查是否需要自动打开侧边栏（从 hotnews 网站跳转过来）
    const autoSummarize = document.documentElement.getAttribute('data-hotnews-auto-summarize');
    if (autoSummarize === 'pending') {
      document.documentElement.removeAttribute('data-hotnews-auto-summarize');
      console.log('[ContentScript] Auto-summarize triggered from hotnews');
      // 由于 Chrome 限制，sidePanel.open() 需要用户手势
      // 显示提示让用户点击浮动按钮
      setTimeout(() => {
        showAutoSummarizeHint();
      }, 800);
    }
    
    const handleViewportChange = () => {
      cachedSafeAreaInsets = null;
      const container = document.getElementById('cs-floating-container');
      if (!container) return;
      const margins = getMinMargins();
      
      safeSendMessage({ type: 'GET_CONFIG' }, (response) => {
        const pos = response?.config?.buttonPosition;
        if (pos?.userDragged) {
          normalizePosition(container, pos, margins);
        } else {
          const current = readRightBottomFromRect(container);
          normalizePosition(container, current, margins);
        }
      });
    };
    
    // 加载保存的按钮位置（只有用户拖拽过才应用）
    safeSendMessage({ type: 'GET_CONFIG' }, (response) => {
      if (response?.config?.buttonPosition?.userDragged) {
        const container = document.getElementById('cs-floating-container');
        const pos = response.config.buttonPosition;
        
        if (container) {
          // 检查是新格式(right/bottom)还是旧格式(x/y)
          if (pos.right !== undefined && pos.bottom !== undefined) {
            // 新格式：使用 right 和 bottom 定位
            normalizePosition(container, pos, getMinMargins());
          } else if (pos.x !== undefined && pos.y !== undefined) {
            // 旧格式：转换为 right/bottom 并保存
            const right = window.innerWidth - pos.x - 40; // 40 是按钮宽度
            const bottom = window.innerHeight - pos.y - 40; // 40 是按钮高度
            normalizePosition(container, { right: Math.max(20, right), bottom: Math.max(100, bottom) }, getMinMargins());
            
            // 保存为新格式
            const margins = getMinMargins();
            const bounds = getBoundsForElement(container, margins);
            const normalized = readRightBottomFromRect(container);
            const clampedRight = clampNumber(normalized.right, bounds.rightMin, bounds.maxRight);
            const clampedBottom = clampNumber(normalized.bottom, bounds.bottomMin, bounds.maxBottom);
            const dock = clampedRight <= bounds.maxRight / 2 ? 'right' : 'left';
            const dockedRight = dock === 'right' ? bounds.rightMin : bounds.maxRight;
            applyPosition(container, dockedRight, clampedBottom);
            safeSendMessage({
              type: 'SAVE_BUTTON_POSITION',
              position: { right: dockedRight, bottom: clampedBottom, dock, userDragged: true }
            });
          }
        }
      }
      // 否则使用 CSS 默认位置 (right: 20px, bottom: 100px)
    });
    
    // 监听视口大小变化，确保按钮不会超出可见区域
    window.addEventListener('resize', handleViewportChange);
    window.addEventListener('orientationchange', handleViewportChange);
  }
  
  // 等待 DOM 加载完成
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
  
})();
