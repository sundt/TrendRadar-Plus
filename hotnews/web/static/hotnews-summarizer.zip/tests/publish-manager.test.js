/**
 * PublishManager 单元测试
 * 
 * 由于依赖 Chrome API，这些测试需要在浏览器环境中运行
 * 或使用 mock 框架（如 jest + chrome-mock）
 * 
 * 运行方式：
 * 1. 在浏览器控制台中加载此文件
 * 2. 或配置 Jest + chrome-mock 后运行
 */

// Mock Chrome API
const chromeMock = {
  tabs: {
    create: async (options) => ({ id: 1, url: options.url }),
    remove: async () => {},
    onUpdated: {
      addListener: () => {},
      removeListener: () => {}
    }
  },
  scripting: {
    executeScript: async () => [{ result: { success: true, url: 'https://example.com/article/123' } }]
  }
};

// 如果在非浏览器环境，使用 mock
if (typeof chrome === 'undefined') {
  globalThis.chrome = chromeMock;
}

/**
 * 测试用例
 */
const tests = {
  /**
   * 测试 validateForPlatform - 空标题
   */
  'validateForPlatform should reject empty title': async (manager) => {
    const errors = manager.validateForPlatform('zhihu', {
      title: '',
      htmlContent: '<p>内容</p>'
    });
    
    if (!errors.includes('标题不能为空')) {
      throw new Error('应该检测到空标题错误');
    }
    return true;
  },

  /**
   * 测试 validateForPlatform - 空内容
   */
  'validateForPlatform should reject empty content': async (manager) => {
    const errors = manager.validateForPlatform('zhihu', {
      title: '测试标题',
      htmlContent: ''
    });
    
    if (!errors.includes('内容不能为空')) {
      throw new Error('应该检测到空内容错误');
    }
    return true;
  },

  /**
   * 测试 validateForPlatform - 有效数据
   */
  'validateForPlatform should pass valid data': async (manager) => {
    const errors = manager.validateForPlatform('zhihu', {
      title: '测试标题',
      htmlContent: '<p>测试内容</p>'
    });
    
    if (errors.length > 0) {
      throw new Error(`不应该有错误: ${errors.join(', ')}`);
    }
    return true;
  },

  /**
   * 测试 validateForPlatform - 不支持的平台
   */
  'validateForPlatform should reject unsupported platform': async (manager) => {
    const errors = manager.validateForPlatform('unknown_platform', {
      title: '测试',
      htmlContent: '<p>内容</p>'
    });
    
    if (!errors.includes('不支持的平台')) {
      throw new Error('应该检测到不支持的平台');
    }
    return true;
  },

  /**
   * 测试 getSupportedPlatforms
   */
  'getSupportedPlatforms should return all platforms': async (manager) => {
    const platforms = manager.getSupportedPlatforms();
    
    const expectedPlatforms = ['zhihu', 'juejin', 'csdn', 'weixin'];
    for (const expected of expectedPlatforms) {
      if (!platforms.find(p => p.id === expected)) {
        throw new Error(`缺少平台: ${expected}`);
      }
    }
    return true;
  },

  /**
   * 测试 generateTaskId
   */
  'generateTaskId should generate unique IDs': async (manager) => {
    const id1 = manager.generateTaskId();
    const id2 = manager.generateTaskId();
    
    if (id1 === id2) {
      throw new Error('任务 ID 应该唯一');
    }
    if (!id1.startsWith('pub_')) {
      throw new Error('任务 ID 应该以 pub_ 开头');
    }
    return true;
  },

  /**
   * 测试 getStatus - 不存在的任务
   */
  'getStatus should return null for non-existent task': async (manager) => {
    const status = manager.getStatus('non_existent_task');
    
    if (status !== null) {
      throw new Error('不存在的任务应该返回 null');
    }
    return true;
  },

  /**
   * 测试 cancel - 取消任务
   */
  'cancel should mark task as cancelled': async (manager) => {
    // 创建一个模拟任务
    const taskId = 'test_task_1';
    manager.tasks.set(taskId, {
      id: taskId,
      status: 'running',
      platforms: ['zhihu'],
      results: []
    });
    
    manager.cancel(taskId);
    
    const task = manager.tasks.get(taskId);
    if (task.status !== 'cancelled') {
      throw new Error('任务状态应该是 cancelled');
    }
    return true;
  }
};

/**
 * 运行所有测试
 */
async function runTests() {
  console.log('=== PublishManager 单元测试 ===\n');
  
  // 动态导入 PublishManager
  let PublishManager;
  try {
    const module = await import('../background/publish/manager.js');
    PublishManager = module.PublishManager;
  } catch (e) {
    console.error('无法导入 PublishManager:', e.message);
    console.log('请确保在支持 ES modules 的环境中运行');
    return;
  }
  
  const manager = new PublishManager();
  
  let passed = 0;
  let failed = 0;
  
  for (const [name, testFn] of Object.entries(tests)) {
    try {
      await testFn(manager);
      console.log(`✓ ${name}`);
      passed++;
    } catch (error) {
      console.log(`✗ ${name}`);
      console.log(`  错误: ${error.message}`);
      failed++;
    }
  }
  
  console.log(`\n=== 测试结果: ${passed} 通过, ${failed} 失败 ===`);
  return { passed, failed };
}

// 导出测试函数
export { runTests, tests };

// 如果直接运行此文件
if (typeof window !== 'undefined') {
  window.runPublishManagerTests = runTests;
  console.log('测试已加载，运行 runPublishManagerTests() 执行测试');
}
