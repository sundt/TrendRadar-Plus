// uihash 总结助手 - Background Service Worker
// 简化版：移除本地 AI 配置，仅保留核心功能

// Import storage modules
import { saveSummaryWithMetadata } from './background/storage/integration.js';
import { toggleFavorite, getSummaries, getStats } from './background/storage/db.js';

// Import WeChat integration module
import { setupWechatMessageListeners } from './background/wechat/index.js';

// Import Publish module
import { setupPublishMessageListeners } from './background/publish/index.js';

// Setup WeChat message listeners
setupWechatMessageListeners();

// Setup Publish message listeners
setupPublishMessageListeners();

// ============ 默认配置（简化版） ============
const DEFAULT_CONFIG = {
  buttonPosition: { right: 20, bottom: 100 },
  panelWidth: 450
};

// ============ 快捷键监听 ============
chrome.commands.onCommand.addListener(async (command) => {
  if (command === 'summarize-page') {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab) return;
      
      // 设置待处理任务
      await chrome.storage.local.set({ pendingTask: { type: 'summarize' } });
      
      // 通过模拟 action 点击来打开侧边栏（绕过 user gesture 限制）
      // 发送消息给 content script，让它触发浮标点击
      chrome.tabs.sendMessage(tab.id, { type: 'TRIGGER_SUMMARIZE' }).catch(() => {
        // 如果 content script 不可用，提示用户点击图标
        console.log('Content script not available, user needs to click icon');
      });
    } catch (error) {
      console.error('总结快捷键处理失败:', error);
    }
  }
});

// ============ 配置管理 ============

/**
 * 深度合并对象
 */
function deepMergeConfig(target, source) {
  const result = { ...source };

  if (!target || typeof target !== 'object') {
    return result;
  }

  for (const key of Object.keys(target)) {
    if (key in source) {
      if (
        typeof target[key] === 'object' &&
        target[key] !== null &&
        !Array.isArray(target[key]) &&
        typeof source[key] === 'object' &&
        source[key] !== null &&
        !Array.isArray(source[key])
      ) {
        result[key] = deepMergeConfig(target[key], source[key]);
      } else {
        result[key] = target[key];
      }
    } else {
      result[key] = target[key];
    }
  }

  return result;
}

/**
 * 初始化配置
 */
async function initConfig() {
  console.log('[initConfig] 开始初始化配置...');

  const result = await chrome.storage.local.get(['config', '_configVersion']);
  const currentVersion = chrome.runtime.getManifest().version;

  // 配置合并
  let mergedConfig;
  if (result.config) {
    mergedConfig = deepMergeConfig(result.config, DEFAULT_CONFIG);
    console.log('[initConfig] 配置已合并，保留用户设置');
  } else {
    mergedConfig = { ...DEFAULT_CONFIG };
    console.log('[initConfig] 使用默认配置');
  }

  // 保存合并后的配置
  await chrome.storage.local.set({
    config: mergedConfig,
    _configVersion: currentVersion
  });

  // 设置侧边栏行为：点击扩展图标时打开侧边栏
  try {
    await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  } catch (e) {
    console.log('setPanelBehavior 不可用:', e);
  }

  console.log('[initConfig] 初始化完成');
}

// ============ 生命周期监听 ============

chrome.runtime.onInstalled.addListener((details) => {
  console.log(`[onInstalled] 事件触发: ${details.reason}`);

  if (details.reason === 'install') {
    console.log('[onInstalled] 首次安装，初始化默认配置');
    initConfig();
  } else if (details.reason === 'update') {
    console.log(`[onInstalled] 版本更新: ${details.previousVersion} → ${chrome.runtime.getManifest().version}`);
    initConfig();
  }
});

// 获取配置
async function getConfig() {
  const result = await chrome.storage.local.get(['config']);
  return {
    config: result.config || DEFAULT_CONFIG
  };
}

// ============ 长连接保活 ============
const keepAlivePorts = new Map();

chrome.runtime.onConnect.addListener((port) => {
  if (port.name === 'SP_KEEP_ALIVE') {
    const portId = `${Date.now()}-${Math.random().toString(16).slice(2)}`;
    keepAlivePorts.set(portId, port);

    port.onMessage.addListener((message) => {
      if (message.type === 'PING') {
        port.postMessage({ type: 'PONG', t: Date.now() });
      }
      // 处理带 reqId 的请求
      if (message.__reqId) {
        const reqId = message.__reqId;
        const payload = message.payload || {};
        
        // 处理 TODO_ENRICH 请求
        if (payload.type === 'TODO_ENRICH') {
          handleTodoEnrich(payload.todo)
            .then((content) => {
              port.postMessage({ __reqId: reqId, payload: { success: true, content } });
            })
            .catch((e) => {
              port.postMessage({ __reqId: reqId, payload: { success: false, error: e?.message || String(e) } });
            });
        }
        // 处理 TODO_CHAT 请求
        else if (payload.type === 'TODO_CHAT') {
          handleTodoChat(payload.todo, payload.history, payload.question)
            .then((content) => {
              port.postMessage({ __reqId: reqId, payload: { success: true, content } });
            })
            .catch((e) => {
              port.postMessage({ __reqId: reqId, payload: { success: false, error: e?.message || String(e) } });
            });
        }
      }
    });

    port.onDisconnect.addListener(() => {
      keepAlivePorts.delete(portId);
    });
  }
});

// ============ Todo 相关功能（简化版） ============

/**
 * 处理 Todo 丰富请求（简化版：不调用本地 AI）
 */
async function handleTodoEnrich(todo) {
  const text = String(todo?.text || '').trim();
  const pageUrl = String(todo?.source?.pageUrl || '').trim();
  
  if (!text) throw new Error('Todo 内容为空');

  // 简化版：只返回原文链接
  const links = [];
  if (pageUrl) {
    links.push({ title: '原文', url: pageUrl });
  }

  if (links.length === 0) {
    return '暂无相关资源';
  }

  const bullets = links.map(l => `- [${l.title}](${l.url})`);
  return `### 🔗 相关链接\n${bullets.join('\n')}`;
}

/**
 * 处理 Todo 聊天请求（简化版：不调用本地 AI）
 */
async function handleTodoChat(todo, history, question) {
  // 简化版：提示用户使用网页版
  return '💡 提示：Todo 智能问答功能需要登录后使用。请访问 [HotNews 官网](https://hot.uihash.com) 获取更多帮助。';
}

// ============ 消息处理 ============
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // 获取配置
  if (message.type === 'GET_CONFIG') {
    getConfig().then(sendResponse);
    return true;
  }

  // 保存配置
  if (message.type === 'SAVE_CONFIG') {
    chrome.storage.local.set({ config: message.config }).then(() => {
      sendResponse({ success: true });
    });
    return true;
  }

  // 保存按钮位置
  if (message.type === 'SAVE_BUTTON_POSITION') {
    chrome.storage.local.get(['config']).then(result => {
      const config = result.config || DEFAULT_CONFIG;
      config.buttonPosition = message.position;
      chrome.storage.local.set({ config }).then(() => {
        sendResponse({ success: true });
      });
    });
    return true;
  }

  // ============ Storage System API ============

  // Toggle favorite status
  if (message.type === 'TOGGLE_FAVORITE') {
    toggleFavorite(message.summaryId)
      .then(newStatus => {
        sendResponse({ success: true, isFavorite: newStatus });
      })
      .catch(error => {
        sendResponse({ success: false, error: error.message });
      });
    return true;
  }

  // Get summaries
  if (message.type === 'GET_SUMMARIES') {
    getSummaries(message.options || {})
      .then(summaries => {
        sendResponse({ success: true, summaries });
      })
      .catch(error => {
        sendResponse({ success: false, error: error.message });
      });
    return true;
  }

  // Get storage stats
  if (message.type === 'GET_STORAGE_STATS') {
    getStats()
      .then(stats => {
        sendResponse({ success: true, stats });
      })
      .catch(error => {
        sendResponse({ success: false, error: error.message });
      });
    return true;
  }

  // ============ 侧边栏管理 ============

  // 直接打开侧边栏
  if (message.type === 'OPEN_SIDEPANEL_DIRECT') {
    const tabId = sender.tab?.id;
    const windowId = sender.tab?.windowId;

    const openErrorHandler = (error) => {
      const msg = error?.message || String(error);
      console.error('打开侧边栏失败:', msg);
      if (tabId) {
        chrome.tabs.sendMessage(tabId, { type: 'SHOW_TOAST', message: `打开侧边栏失败：${msg}` }).catch(() => { });
      }
    };

    try {
      if (tabId) {
        chrome.sidePanel.setOptions({ tabId, path: 'sidepanel.html', enabled: true });
        Promise.resolve(chrome.sidePanel.open({ tabId })).catch(openErrorHandler);
      } else if (windowId) {
        chrome.sidePanel.setOptions({ path: 'sidepanel.html', enabled: true });
        Promise.resolve(chrome.sidePanel.open({ windowId })).catch(openErrorHandler);
      } else {
        chrome.windows.getCurrent().then((win) => {
          chrome.sidePanel.setOptions({ path: 'sidepanel.html', enabled: true });
          Promise.resolve(chrome.sidePanel.open({ windowId: win.id })).catch(openErrorHandler);
        }).catch(openErrorHandler);
      }
    } catch (error) {
      openErrorHandler(error);
    }

    // 处理待总结任务
    (async () => {
      try {
        const normalizeUrlForLocate = (href) => {
          try {
            const u = new URL(href);
            u.hash = '';
            return u.toString();
          } catch {
            return String(href || '').split('#')[0];
          }
        };

        const url = message.url;
        if (url) {
          const normalizedUrl = normalizeUrlForLocate(url);

          // 检查是否已总结过（只检查 chatHistory，不检查 session）
          // 因为 chatHistory 每次总结后会被清空，session 标记会导致误判
          const local = await chrome.storage.local.get(['chatHistory', 'favorites']);
          const history = Array.isArray(local.chatHistory) ? local.chatHistory : [];
          const favorites = Array.isArray(local.favorites) ? local.favorites : [];
          
          // 先检查 chatHistory
          const historyMatch = history.find((m) => normalizeUrlForLocate(m?.pageUrl || '') === normalizedUrl);
          if (historyMatch) {
            if (tabId) {
              chrome.tabs.sendMessage(tabId, { type: 'SHOW_TOAST', message: '这篇文章已总结过，已定位到历史记录' }).catch(() => { });
            }
            await chrome.storage.local.set({ pendingTask: { type: 'locate_summary', url: normalizedUrl } });
            chrome.runtime.sendMessage({ type: 'LOCATE_SUMMARY', url: normalizedUrl }).catch(() => { });
            return;
          }
          
          // 再检查 favorites（因为 chatHistory 可能被清空，但 favorites 保留）
          const favoriteMatch = favorites.find((f) => normalizeUrlForLocate(f?.pageUrl || '') === normalizedUrl);
          if (favoriteMatch) {
            if (tabId) {
              chrome.tabs.sendMessage(tabId, { type: 'SHOW_TOAST', message: '这篇文章已收藏过，可在收藏夹查看' }).catch(() => { });
            }
            // 不阻止重新总结，只是提示用户
          }
          
          // 清除该 URL 的 session 标记（允许重新总结）
          const result = await chrome.storage.session.get(['csSummarized']);
          const map = result.csSummarized || {};
          // 不再检查 session 标记来阻止总结，只用于防止短时间内重复点击
          const lastSummarizeTime = map[normalizedUrl] || 0;
          const now = Date.now();
          if (lastSummarizeTime && (now - lastSummarizeTime) < 3000) {
            // 3秒内重复点击，忽略
            console.log('[Background] Ignoring duplicate click within 3s');
            return;
          }
          
          map[normalizedUrl] = now;
          await chrome.storage.session.set({ csSummarized: map });
        }

        // 标记待处理任务
        await chrome.storage.local.set({ pendingTask: { type: 'summarize' } });
      } catch (e) {
        const msg = e?.message || String(e);
        console.error('准备总结任务失败:', msg);
        if (tabId) {
          chrome.tabs.sendMessage(tabId, { type: 'SHOW_TOAST', message: `无法触发总结：${msg}` }).catch(() => { });
        }
      }
    })();

    return false;
  }

  // 打开侧边栏并跳转到指定标签页
  if (message.type === 'OPEN_SIDEPANEL_WITH_TARGET') {
    (async () => {
      try {
        await chrome.storage.local.set({
          pendingTask: {
            type: 'navigate',
            targetTab: message.targetTab || 'settings',
            targetSection: message.targetSection || null
          }
        });

        const tabId = sender.tab?.id;
        const windowId = sender.tab?.windowId;
        
        try {
          if (tabId) {
            await chrome.sidePanel.setOptions({ tabId, path: 'sidepanel.html', enabled: true });
            await chrome.sidePanel.open({ tabId });
            return;
          }
          if (windowId) {
            await chrome.sidePanel.setOptions({ path: 'sidepanel.html', enabled: true });
            await chrome.sidePanel.open({ windowId });
            return;
          }
          const currentWindow = await chrome.windows.getCurrent();
          await chrome.sidePanel.setOptions({ path: 'sidepanel.html', enabled: true });
          await chrome.sidePanel.open({ windowId: currentWindow.id });
        } catch (openError) {
          console.error('sidePanel.open failed:', openError.message);
          if (tabId) {
            chrome.tabs.sendMessage(tabId, { type: 'SHOW_CLICK_ICON_HINT', error: openError.message }).catch(() => { });
          }
        }
      } catch (error) {
        console.error('打开侧边栏失败:', error.message);
        if (sender.tab?.id) {
          chrome.tabs.sendMessage(sender.tab.id, { type: 'SHOW_CLICK_ICON_HINT', error: error.message }).catch(() => { });
        }
      }
    })();
    return false;
  }

  // Todo 相关
  if (message.type === 'TODO_ENRICH') {
    handleTodoEnrich(message.todo)
      .then((content) => sendResponse({ success: true, content }))
      .catch((e) => {
        console.error('[TODO_ENRICH] error', e);
        sendResponse({ success: false, error: e?.message || String(e) });
      });
    return true;
  }

  if (message.type === 'TODO_CHAT') {
    handleTodoChat(message.todo, message.history, message.question)
      .then((content) => sendResponse({ success: true, content }))
      .catch((e) => {
        console.error('[TODO_CHAT] error', e);
        sendResponse({ success: false, error: e?.message || String(e) });
      });
    return true;
  }

  // ============ 评论相关 ============
  if (message.type === 'SUBMIT_COMMENT') {
    (async () => {
      try {
        const { config } = await getConfig();
        const apiBase = (config.apiBase || 'https://hot.uihash.com').replace(/\/$/, '');
        const resp = await fetch(`${apiBase}/api/comments`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify(message.data),
        });
        const result = await resp.json();
        if (resp.ok && result.success) {
          sendResponse({ success: true, data: result.data });
        } else {
          sendResponse({ success: false, error: result.detail || result.error || '发送失败' });
        }
      } catch (e) {
        console.error('[SUBMIT_COMMENT] error', e);
        sendResponse({ success: false, error: e?.message || '网络错误' });
      }
    })();
    return true;
  }

  if (message.type === 'GET_COMMENTS') {
    (async () => {
      try {
        const { config } = await getConfig();
        const apiBase = (config.apiBase || 'https://hot.uihash.com').replace(/\/$/, '');
        const params = new URLSearchParams();
        if (message.url) params.set('url', message.url);
        if (message.url_hash) params.set('url_hash', message.url_hash);
        if (message.summary) params.set('summary', '1');
        const resp = await fetch(`${apiBase}/api/comments?${params}`, {
          credentials: 'include',
        });
        const result = await resp.json();
        sendResponse({ success: true, data: result.data });
      } catch (e) {
        console.error('[GET_COMMENTS] error', e);
        sendResponse({ success: false, error: e?.message || '网络错误' });
      }
    })();
    return true;
  }

  if (message.type === 'REACT_COMMENT') {
    (async () => {
      try {
        const { config } = await getConfig();
        const apiBase = (config.apiBase || 'https://hot.uihash.com').replace(/\/$/, '');
        const resp = await fetch(`${apiBase}/api/comments/${message.commentId}/react`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify({ emoji: message.emoji }),
        });
        const result = await resp.json();
        sendResponse({ success: true, data: result });
      } catch (e) {
        sendResponse({ success: false, error: e?.message || '网络错误' });
      }
    })();
    return true;
  }

  if (message.type === 'REPLY_COMMENT') {
    (async () => {
      try {
        const { config } = await getConfig();
        const apiBase = (config.apiBase || 'https://hot.uihash.com').replace(/\/$/, '');
        const resp = await fetch(`${apiBase}/api/comments/${message.commentId}/reply`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify({ content: message.content }),
        });
        const result = await resp.json();
        if (resp.ok && result.success) {
          sendResponse({ success: true, data: result.data });
        } else {
          sendResponse({ success: false, error: result.detail || result.error || '回复失败' });
        }
      } catch (e) {
        sendResponse({ success: false, error: e?.message || '网络错误' });
      }
    })();
    return true;
  }

  if (message.type === 'DELETE_COMMENT') {
    (async () => {
      try {
        const { config } = await getConfig();
        const apiBase = (config.apiBase || 'https://hot.uihash.com').replace(/\/$/, '');
        const resp = await fetch(`${apiBase}/api/comments/${message.commentId}`, {
          method: 'DELETE',
          credentials: 'include',
        });
        const result = await resp.json();
        if (resp.ok && result.success) {
          sendResponse({ success: true });
        } else {
          sendResponse({ success: false, error: result.detail || result.error || '删除失败' });
        }
      } catch (e) {
        sendResponse({ success: false, error: e?.message || '网络错误' });
      }
    })();
    return true;
  }

  // 阅读统计上报
  if (message.type === 'RECORD_VIEW') {
    (async () => {
      try {
        const { config } = await getConfig();
        const apiBase = (config.apiBase || 'https://hot.uihash.com').replace(/\/$/, '');
        await fetch(`${apiBase}/api/articles/view`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify(message.data),
        });
        sendResponse({ success: true });
      } catch (e) {
        sendResponse({ success: false });
      }
    })();
    return true;
  }

  // 获取文章统计
  if (message.type === 'GET_ARTICLE_STATS') {
    (async () => {
      try {
        const { config } = await getConfig();
        const apiBase = (config.apiBase || 'https://hot.uihash.com').replace(/\/$/, '');
        const params = new URLSearchParams();
        if (message.url) params.set('url', message.url);
        if (message.url_hash) params.set('url_hash', message.url_hash);
        const resp = await fetch(`${apiBase}/api/articles/stats?${params}`, {
          credentials: 'include',
        });
        const result = await resp.json();
        sendResponse({ success: true, data: result.data });
      } catch (e) {
        sendResponse({ success: false, error: e?.message || '网络错误' });
      }
    })();
    return true;
  }
});

// ============ 启动初始化 ============
initConfig().catch(e => {
  console.error('[启动] 初始化失败:', e);
});


