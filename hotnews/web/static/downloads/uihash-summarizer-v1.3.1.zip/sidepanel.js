// Custom Summarizer - Side Panel Script (Chat Interface)

// ============ 配置常量 ============
const API_BASE_URL = 'https://hot.uihash.com';

// ============ 认证状态管理 ============
let authState = {
  isLoggedIn: false,
  user: null,
  sessionToken: null
};

// ============ 状态管理 ============
let currentPrompts = [];
let selectedPromptId = null;
let chatHistory = [];
let isProcessing = false;
let currentGeneratingContent = '';
let requestAborted = false;
let streamRenderScheduled = false;
let streamPreEl = null;

let pendingLocateSummaryUrl = null;

let todos = [];
let selectionTodoBtn = null;
let todoShowAll = false;

let todoEnriching = new Set();
let todoModalEl = null;
let todoModalTodoId = null;
let todoModalAiLoading = false;
let todoModalSaveTimer = null;
let todoInputComposing = false;
let keepAlivePort = null;
let keepAliveTimer = null;
let keepAlivePending = new Map();
let keepAliveReqSeq = 0;

// ============ 视图切换函数 ============

/**
 * 切换到登录视图
 */
function showLoginView() {
  const loadingView = document.getElementById('sp-loading-view');
  const loginView = document.getElementById('sp-login-view');
  const mainView = document.getElementById('sp-main-view');
  
  if (loadingView) {
    loadingView.style.display = 'none';
  }
  if (loginView) {
    loginView.style.display = 'flex';
  }
  if (mainView) {
    mainView.style.display = 'none';
  }
  
  authState.isLoggedIn = false;
  authState.user = null;
  
  // 启动定时检查登录状态
  startLoginCheck();
}

/**
 * 切换到主视图
 */
function showMainView() {
  const loadingView = document.getElementById('sp-loading-view');
  const loginView = document.getElementById('sp-login-view');
  const mainView = document.getElementById('sp-main-view');
  
  if (loadingView) {
    loadingView.style.display = 'none';
  }
  if (loginView) {
    loginView.style.display = 'none';
  }
  if (mainView) {
    mainView.style.display = 'flex';
  }
  
  // 停止定时检查登录状态
  stopLoginCheck();
  
  // 更新用户信息显示
  updateUserInfoDisplay();
}

/**
 * 更新用户信息显示
 */
function updateUserInfoDisplay() {
  // 用户信息已移到设置页面，这里不再需要显示
}

/**
 * 检查登录状态
 */
async function checkLoginStatus() {
  try {
    const response = await fetch(`${API_BASE_URL}/api/auth/me`, {
      method: 'GET',
      credentials: 'include',
      headers: {
        'Accept': 'application/json'
      }
    });
    
    if (response.status === 401) {
      // 未登录
      showLoginView();
      return false;
    }
    
    if (!response.ok) {
      throw new Error('Failed to check login status');
    }
    
    const data = await response.json();
    
    if (data.ok && data.user) {
      authState.isLoggedIn = true;
      authState.user = data.user;
      showMainView();
      return true;
    } else {
      showLoginView();
      return false;
    }
  } catch (error) {
    console.error('[Auth] Check login status error:', error);
    // 网络错误时显示登录视图
    showLoginView();
    return false;
  }
}

// 定时检查登录状态（用于检测用户在网站登录后自动刷新）
let loginCheckInterval = null;

function startLoginCheck() {
  if (loginCheckInterval) return;
  
  // 每 3 秒检查一次登录状态（仅在未登录时）
  loginCheckInterval = setInterval(async () => {
    if (!authState.isLoggedIn) {
      const isLoggedIn = await checkLoginStatus();
      if (isLoggedIn) {
        // 登录成功，停止检查并加载数据
        stopLoginCheck();
        loadFavorites();
        loadTodos();
        showToast('登录成功！');
      }
    }
  }, 3000);
}

function stopLoginCheck() {
  if (loginCheckInterval) {
    clearInterval(loginCheckInterval);
    loginCheckInterval = null;
  }
}

/**
 * 退出登录
 */
async function handleLogout() {
  try {
    // 调用后端退出接口
    await fetch(`${API_BASE_URL}/api/auth/logout`, {
      method: 'POST',
      credentials: 'include'
    });
  } catch (error) {
    console.error('[Auth] Logout error:', error);
  }
  
  // 清除本地状态
  authState.isLoggedIn = false;
  authState.user = null;
  authState.sessionToken = null;
  
  // 切换到登录视图
  showLoginView();
  showToast('已退出登录');
}

// ============ 二维码登录相关 ============

let qrLoginState = null;

/**
 * 打开二维码登录弹窗
 */
async function openQRCodeModal() {
  const modal = document.getElementById('sp-qrcode-modal');
  if (!modal) return;
  
  modal.style.display = 'flex';
  
  // 开始获取二维码
  await fetchQRCode();
}

/**
 * 关闭二维码登录弹窗
 */
function closeQRCodeModal() {
  const modal = document.getElementById('sp-qrcode-modal');
  if (modal) {
    modal.style.display = 'none';
  }
  
  // 停止轮询
  stopQRCodePolling();
}

/**
 * 获取登录二维码
 */
async function fetchQRCode() {
  const container = document.getElementById('sp-qrcode-container');
  const countdownEl = document.getElementById('sp-qrcode-countdown');
  
  if (!container) return;
  
  // 显示加载状态
  container.innerHTML = `
    <div class="sp-qrcode-loading">
      <div class="sp-qrcode-spinner"></div>
      <span>正在获取二维码...</span>
    </div>
  `;
  
  if (countdownEl) {
    countdownEl.textContent = '';
    countdownEl.className = 'sp-qrcode-countdown';
  }
  
  try {
    const response = await fetch(`${API_BASE_URL}/api/auth/wechat/qrcode`, {
      method: 'GET',
      credentials: 'include',
      headers: {
        'Accept': 'application/json'
      }
    });
    
    if (!response.ok) {
      throw new Error('Failed to get QR code');
    }
    
    const data = await response.json();
    
    if (data.ok && data.qrcode_url) {
      // 显示二维码
      container.innerHTML = `
        <img src="${escapeHtml(data.qrcode_url)}" alt="登录二维码" class="sp-qrcode-image" />
      `;
      
      // 保存场景 ID 用于轮询
      qrLoginState = {
        sceneId: data.scene_id,
        expiresAt: Date.now() + (data.expires_in || 300) * 1000,
        polling: true
      };
      
      // 开始轮询
      startQRCodePolling();
      
      // 开始倒计时
      startQRCodeCountdown();
    } else {
      throw new Error(data.message || 'Failed to get QR code');
    }
  } catch (error) {
    console.error('[Auth] Fetch QR code error:', error);
    container.innerHTML = `
      <div class="sp-qrcode-error">
        <span>❌</span>
        <span>获取二维码失败</span>
        <button class="sp-qrcode-refresh-btn" onclick="fetchQRCode()">重试</button>
      </div>
    `;
  }
}

/**
 * 开始二维码轮询
 */
function startQRCodePolling() {
  if (!qrLoginState || !qrLoginState.polling) return;
  
  const poll = async () => {
    if (!qrLoginState || !qrLoginState.polling) return;
    
    // 检查是否过期
    if (Date.now() > qrLoginState.expiresAt) {
      showQRCodeExpired();
      return;
    }
    
    try {
      const response = await fetch(`${API_BASE_URL}/api/auth/wechat/check?scene_id=${qrLoginState.sceneId}`, {
        method: 'GET',
        credentials: 'include',
        headers: {
          'Accept': 'application/json'
        }
      });
      
      if (!response.ok) {
        throw new Error('Failed to check login status');
      }
      
      const data = await response.json();
      
      if (data.ok) {
        if (data.status === 'success') {
          // 登录成功
          handleQRLoginSuccess(data.user);
          return;
        } else if (data.status === 'scanned') {
          // 已扫码，等待确认
          showQRCodeScanned();
        } else if (data.status === 'expired') {
          // 二维码过期
          showQRCodeExpired();
          return;
        }
        // status === 'waiting' 继续轮询
      }
      
      // 继续轮询（每 2 秒）
      if (qrLoginState && qrLoginState.polling) {
        qrLoginState.pollTimer = setTimeout(poll, 2000);
      }
    } catch (error) {
      console.error('[Auth] QR polling error:', error);
      // 出错后继续轮询
      if (qrLoginState && qrLoginState.polling) {
        qrLoginState.pollTimer = setTimeout(poll, 3000);
      }
    }
  };
  
  // 开始轮询
  poll();
}

/**
 * 停止二维码轮询
 */
function stopQRCodePolling() {
  if (qrLoginState) {
    qrLoginState.polling = false;
    if (qrLoginState.pollTimer) {
      clearTimeout(qrLoginState.pollTimer);
    }
    if (qrLoginState.countdownTimer) {
      clearInterval(qrLoginState.countdownTimer);
    }
  }
  qrLoginState = null;
}

/**
 * 开始二维码倒计时
 */
function startQRCodeCountdown() {
  const countdownEl = document.getElementById('sp-qrcode-countdown');
  if (!countdownEl || !qrLoginState) return;
  
  const updateCountdown = () => {
    if (!qrLoginState) return;
    
    const remaining = Math.max(0, Math.floor((qrLoginState.expiresAt - Date.now()) / 1000));
    
    if (remaining <= 0) {
      countdownEl.textContent = '二维码已过期';
      countdownEl.className = 'sp-qrcode-countdown warning';
      return;
    }
    
    const minutes = Math.floor(remaining / 60);
    const seconds = remaining % 60;
    countdownEl.textContent = `${minutes}:${seconds.toString().padStart(2, '0')} 后过期`;
    
    if (remaining <= 60) {
      countdownEl.className = 'sp-qrcode-countdown warning';
    }
  };
  
  updateCountdown();
  qrLoginState.countdownTimer = setInterval(updateCountdown, 1000);
}

/**
 * 显示二维码已扫描状态
 */
function showQRCodeScanned() {
  const container = document.getElementById('sp-qrcode-container');
  if (!container) return;
  
  // 保留二维码图片，添加遮罩
  const img = container.querySelector('.sp-qrcode-image');
  if (img) {
    container.innerHTML = `
      <img src="${img.src}" alt="登录二维码" class="sp-qrcode-image" style="opacity: 0.3;" />
      <div class="sp-qrcode-scanned" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);">
        <span>✅</span>
        <span>已扫码，请在手机上确认</span>
      </div>
    `;
  }
}

/**
 * 显示二维码过期状态
 */
function showQRCodeExpired() {
  stopQRCodePolling();
  
  const container = document.getElementById('sp-qrcode-container');
  if (!container) return;
  
  container.innerHTML = `
    <div class="sp-qrcode-expired">
      <span>⏰</span>
      <span>二维码已过期</span>
      <button class="sp-qrcode-refresh-btn" onclick="fetchQRCode()">刷新二维码</button>
    </div>
  `;
}

/**
 * 处理二维码登录成功
 */
function handleQRLoginSuccess(user) {
  stopQRCodePolling();
  
  // 更新认证状态
  authState.isLoggedIn = true;
  authState.user = user;
  
  // 关闭弹窗
  closeQRCodeModal();
  
  // 切换到主视图
  showMainView();
  
  showToast('登录成功！');
  
  // 登录成功后重新加载数据（会触发本地数据同步到服务器）
  loadFavorites();
  loadTodos();
}

function startKeepAlive() {
  try {
    if (keepAlivePort) return;
    keepAlivePort = chrome.runtime.connect({ name: 'SP_KEEP_ALIVE' });
    keepAlivePort.onMessage.addListener((message) => {
      const reqId = message?.__reqId;
      if (!reqId) return;
      const pending = keepAlivePending.get(reqId);
      if (!pending) return;
      keepAlivePending.delete(reqId);
      if (pending.timeoutId) clearTimeout(pending.timeoutId);
      pending.resolve(message.payload);
    });
    keepAlivePort.onDisconnect.addListener(() => {
      for (const pending of keepAlivePending.values()) {
        if (pending.timeoutId) clearTimeout(pending.timeoutId);
        pending.resolve({ success: false, error: '连接已断开' });
      }
      keepAlivePending = new Map();
      keepAlivePort = null;
      if (keepAliveTimer) clearInterval(keepAliveTimer);
      keepAliveTimer = null;
      setTimeout(startKeepAlive, 1000);
    });
    keepAliveTimer = setInterval(() => {
      try {
        if (keepAlivePort) keepAlivePort.postMessage({ type: 'PING', t: Date.now() });
      } catch {
      }
    }, 20000);
    keepAlivePort.postMessage({ type: 'PING', t: Date.now() });
  } catch {
    setTimeout(startKeepAlive, 1000);
  }
}

function normalizeUrlForLocate(href) {
  try {
    const u = new URL(href);
    u.hash = '';
    return u.toString();
  } catch {
    return String(href || '').split('#')[0];
  }
}

function locateSummaryByUrl(url, options) {
  const opts = options || {};
  const normalized = normalizeUrlForLocate(url);
  if (!normalized) return;

  if (!Array.isArray(chatHistory) || chatHistory.length === 0) {
    pendingLocateSummaryUrl = normalized;
    return;
  }

  let found = null;
  for (let i = chatHistory.length - 1; i >= 0; i--) {
    const msg = chatHistory[i];
    const msgUrl = normalizeUrlForLocate(msg?.pageUrl || '');
    if (msgUrl && msgUrl === normalized) {
      found = msg;
      break;
    }
  }

  if (!found) {
    if (opts.showToast) showToast('未找到该文章的历史总结');
    return;
  }

  renderHistory();
  const msgEl = document.querySelector(`.sp-message[data-id="${found.id}"]`);
  if (!msgEl) {
    if (opts.showToast) showToast('未找到该文章的历史总结');
    return;
  }

  const titleEl = msgEl.querySelector('.sp-message-title');
  (titleEl || msgEl).scrollIntoView({ behavior: 'smooth', block: 'start' });
  msgEl.style.transition = 'box-shadow 0.3s ease';
  msgEl.style.boxShadow = '0 0 0 3px #60a5fa, 0 6px 16px rgba(96, 165, 250, 0.35)';
  setTimeout(() => {
    msgEl.style.boxShadow = '';
  }, 2000);

  if (opts.showToast) showToast('这篇文章已总结过，已为你定位到历史记录');
}

// ============ DOM 元素 ============
const elements = {};

// ============ 初始化 ============
document.addEventListener('DOMContentLoaded', () => {
  // 获取 DOM 元素
  elements.loginView = document.getElementById('sp-login-view');
  elements.mainView = document.getElementById('sp-main-view');
  elements.loginBtn = document.getElementById('sp-login-btn');
  elements.qrcodeModal = document.getElementById('sp-qrcode-modal');
  elements.qrcodeClose = document.getElementById('sp-qrcode-close');
  elements.promptSelect = document.getElementById('sp-prompt-select');
  elements.summarizeBtn = document.getElementById('sp-summarize-btn');
  elements.settingsBtn = document.getElementById('sp-settings-btn');
  elements.clearHistoryBtn = document.getElementById('sp-clear-history');
  elements.chatContainer = document.getElementById('sp-chat-container');
  elements.messages = document.getElementById('sp-messages');
  elements.welcome = document.getElementById('sp-welcome');
  elements.generating = document.getElementById('sp-generating');
  elements.genTitle = document.getElementById('sp-gen-title');
  elements.genPrompt = document.getElementById('sp-gen-prompt');
  elements.genContent = document.getElementById('sp-gen-content');
  elements.cancelBtn = document.getElementById('sp-cancel-btn');
  elements.genFavoriteBtn = document.getElementById('sp-gen-favorite');
  elements.todoList = document.getElementById('sp-todo-list');
  elements.todoFilterBtn = document.getElementById('sp-todo-filter');
  elements.todoToggleBtn = document.getElementById('sp-todo-toggle');
  elements.todoDrawer = document.getElementById('sp-todo-drawer');
  elements.todoOverlay = document.getElementById('sp-todo-overlay');
  elements.todoCloseBtn = document.getElementById('sp-todo-close');

  startKeepAlive();

  // ============ 登录相关事件绑定 ============
  if (elements.loginBtn) {
    elements.loginBtn.addEventListener('click', () => {
      // 跳转到网站登录页面
      chrome.tabs.create({ url: `${API_BASE_URL}/?login=1` });
    });
  }
  
  // OAuth 按钮事件绑定
  document.querySelectorAll('.sp-btn-oauth').forEach(btn => {
    btn.addEventListener('click', () => {
      const provider = btn.dataset.provider;
      if (provider) {
        if (provider === 'wechat' || provider === 'email') {
          // 微信和邮箱登录：跳转到网站登录页面
          chrome.tabs.create({ url: `${API_BASE_URL}/?login=1&method=${provider}` });
        } else {
          // GitHub/Google 直接跳转 OAuth
          chrome.tabs.create({ url: `${API_BASE_URL}/api/auth/oauth/${provider}` });
        }
      }
    });
  });
  
  if (elements.qrcodeClose) {
    elements.qrcodeClose.addEventListener('click', closeQRCodeModal);
  }
  // 点击弹窗背景关闭
  if (elements.qrcodeModal) {
    elements.qrcodeModal.addEventListener('click', (e) => {
      if (e.target.classList.contains('sp-modal-backdrop')) {
        closeQRCodeModal();
      }
    });
  }

  // 绑定事件
  elements.summarizeBtn.addEventListener('click', handleSummarize);
  elements.cancelBtn.addEventListener('click', handleCancel);
  if (elements.genFavoriteBtn) elements.genFavoriteBtn.addEventListener('click', handleGenFavorite);
  if (elements.settingsBtn) elements.settingsBtn.addEventListener('click', () => chrome.runtime.openOptionsPage());
  if (elements.clearHistoryBtn) elements.clearHistoryBtn.addEventListener('click', handleClearHistory);
  if (elements.promptSelect) elements.promptSelect.addEventListener('change', handlePromptChange);
  if (elements.todoFilterBtn) elements.todoFilterBtn.addEventListener('click', toggleTodoFilter);
  if (elements.todoToggleBtn) elements.todoToggleBtn.addEventListener('click', toggleTodoDrawer);
  if (elements.todoCloseBtn) elements.todoCloseBtn.addEventListener('click', closeTodoDrawer);
  if (elements.todoOverlay) elements.todoOverlay.addEventListener('click', closeTodoDrawer);
  
  // 新建标题按钮
  const todoNewGroupBtn = document.getElementById('sp-todo-new-group-btn');
  if (todoNewGroupBtn) todoNewGroupBtn.addEventListener('click', showNewGroupInput);

  // 收藏面板事件
  const favoritesToggle = document.getElementById('sp-favorites-toggle');
  const favoritesClose = document.getElementById('sp-favorites-close');
  const favoritesClear = document.getElementById('sp-favorites-clear');
  const favoritesOverlay = document.getElementById('sp-favorites-overlay');

  if (favoritesToggle) favoritesToggle.addEventListener('click', toggleFavoritesDrawer);
  if (favoritesClose) favoritesClose.addEventListener('click', closeFavoritesDrawer);
  if (favoritesClear) favoritesClear.addEventListener('click', clearFavorites);
  if (favoritesOverlay) favoritesOverlay.addEventListener('click', closeFavoritesDrawer);

  // 初始化 Resizer
  const favoritesResizer = document.getElementById('sp-favorites-resizer');
  const favoritesDrawer = document.getElementById('sp-favorites-drawer');
  if (favoritesResizer && favoritesDrawer) {
    initDrawerResizer(favoritesResizer, favoritesDrawer);
  }

  const todoResizer = document.getElementById('sp-todo-resizer');
  const todoDrawer = document.getElementById('sp-todo-drawer');
  if (todoResizer && todoDrawer) {
    initDrawerResizer(todoResizer, todoDrawer);
  }

  // WeChat 面板事件
  const wechatToggle = document.getElementById('sp-wechat-toggle');
  const wechatClose = document.getElementById('sp-wechat-close');
  const wechatRefresh = document.getElementById('sp-wechat-refresh');
  const wechatOverlay = document.getElementById('sp-wechat-overlay');

  if (wechatToggle) wechatToggle.addEventListener('click', toggleWechatDrawer);
  if (wechatClose) wechatClose.addEventListener('click', closeWechatDrawer);
  if (wechatRefresh) wechatRefresh.addEventListener('click', refreshWechatStatus);
  if (wechatOverlay) wechatOverlay.addEventListener('click', closeWechatDrawer);

  // 初始化 WeChat Resizer
  const wechatResizer = document.getElementById('sp-wechat-resizer');
  const wechatDrawer = document.getElementById('sp-wechat-drawer');
  if (wechatResizer && wechatDrawer) {
    initDrawerResizer(wechatResizer, wechatDrawer);
  }

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeTodoDrawer();
      closeFavoritesDrawer();
      closeWechatDrawer();
    }
  });

  // 加载本地数据（不依赖登录状态）
  loadPrompts();
  loadHistory();
  loadTodoPrefs();

  initSelectionTodo();

  // 检查登录状态（这会决定显示哪个视图，并在登录成功后加载服务器数据）
  checkLoginStatus().then((isLoggedIn) => {
    // 登录状态确定后再加载收藏和 Todo
    loadTodos();
    loadFavorites();
    
    // 初始检查当前页面是否支持总结
    updateSummarizeButtonState();
    
    // 检查是否有待处理的任务（必须在登录状态确定后执行）
    chrome.storage.local.get(['pendingTask'], (result) => {
      if (result.pendingTask) {
        const task = result.pendingTask;
        chrome.storage.local.remove(['pendingTask']);

        // 根据任务类型执行不同操作
        if (task.type === 'summarize') {
          // 延迟执行总结，确保 UI 已加载
          setTimeout(() => handleSummarize(), 300);
        } else if (task.type === 'navigate') {
          // 导航到指定标签页
          if (task.targetTab === 'settings') {
            // 打开设置页面
            chrome.runtime.openOptionsPage();
          }
        } else if (task.type === 'locate_summary') {
          pendingLocateSummaryUrl = task.url || null;
          setTimeout(() => locateSummaryByUrl(task.url, { showToast: true }), 0);
        }
      }
    });
  });

  // 监听标签页切换，更新按钮状态
  chrome.tabs.onActivated.addListener(() => {
    updateSummarizeButtonState();
  });
  
  // 监听标签页 URL 变化
  chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.url) {
      updateSummarizeButtonState();
    }
  });

  // 监听来自 background 的消息
  chrome.runtime.onMessage.addListener(handleMessage);

  // 监听 storage 变化（网页端添加 Todo 后需要实时同步）
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes.todos) {
      const next = changes.todos.newValue;
      todos = Array.isArray(next) ? next : [];
      renderTodos();
      syncTodoModalFromStorage();
    }
    if (changes.todoShowAll) {
      todoShowAll = Boolean(changes.todoShowAll.newValue);
      updateTodoFilterButton();
      renderTodos();
    }
    if (changes.favorites) {
      const next = changes.favorites.newValue;
      favorites = Array.isArray(next) ? next : [];
      updateFavoritesButton();
      renderFavorites();
      renderHistory(); // 更新消息上的收藏图标
    }
  });

  function openTodoDrawer() {
    if (!elements.todoDrawer) return;
    elements.todoDrawer.classList.add('is-open');
    elements.todoDrawer.setAttribute('aria-hidden', 'false');
    if (elements.todoOverlay) elements.todoOverlay.style.display = 'block';
  }

  function closeTodoDrawer() {
    if (!elements.todoDrawer) return;
    elements.todoDrawer.classList.remove('is-open');
    elements.todoDrawer.setAttribute('aria-hidden', 'true');
    if (elements.todoOverlay) elements.todoOverlay.style.display = 'none';
  }

  function toggleTodoDrawer() {
    if (!elements.todoDrawer) return;
    if (elements.todoDrawer.classList.contains('is-open')) {
      closeTodoDrawer();
    } else {
      openTodoDrawer();
    }
  }

  function loadTodos() {
    loadTodosAsync();
  }
  
  async function loadTodosAsync() {
    console.log('[Todo] Loading todos, isLoggedIn:', authState.isLoggedIn);
    
    if (authState.isLoggedIn) {
      // 已登录：从后端 API 加载
      const result = await fetchTodosFromAPI();
      console.log('[Todo] API result:', result);
      
      if (result.needsAuth) {
        // 登录已过期，降级到本地存储
        console.log('[Todo] Auth required, using local storage');
        const localTodos = await getLocalTodos();
        todos = localTodos;
      } else if (result.error) {
        // API 错误，降级到本地存储
        console.warn('[Todo] API error, using local storage:', result.error);
        const localTodos = await getLocalTodos();
        todos = localTodos;
      } else {
        // 转换后端数据格式到本地格式
        // 后端返回 camelCase: createdAt, source.groupId, source.groupTitle, source.groupUrl, source.isCustom
        console.log('[Todo] Got', (result.todos || []).length, 'todos from API');
        todos = (result.todos || []).map(t => ({
          id: String(t.id),
          createdAt: t.createdAt ? t.createdAt * 1000 : (t.created_at ? t.created_at * 1000 : Date.now()),
          done: Boolean(t.done),
          text: t.text,
          source: t.source ? {
            pageTitle: t.source.groupTitle || t.source.group_title || '',
            pageUrl: t.source.groupUrl || t.source.group_url || '',
            groupId: t.source.groupId || t.source.group_id || '',
            isCustom: t.source.isCustom || t.source.is_custom_group || false
          } : null,
          enrich: t.enrich || null
        }));
        
        // 同步到本地存储作为缓存
        saveLocalTodos(todos);
        
        // 检查是否有待同步的本地数据
        syncLocalTodosToServer();
      }
    } else {
      // 未登录：从本地存储加载
      console.log('[Todo] Not logged in, using local storage');
      const localTodos = await getLocalTodos();
      todos = localTodos;
    }
    
    console.log('[Todo] Final todos count:', todos.length);
    renderTodos();
    updateTodoCount();
  }

  function saveTodos() {
    saveLocalTodos(todos);
  }

  async function addTodoFromSelection(text, source) {
    const trimmed = String(text || '').trim().replace(/\s+/g, ' ');
    if (!trimmed) return;

    // 确保source有正确的groupId
    const normalizedSource = source ? {
      groupId: source.summaryId || source.groupId || `page_${Date.now()}`,
      pageTitle: source.pageTitle || '未知页面',
      pageUrl: source.pageUrl || '',
      isCustom: false
    } : null;

    const newTodo = {
      id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
      createdAt: Date.now(),
      done: false,
      text: trimmed,
      source: normalizedSource
    };

    todos.push(newTodo);
    saveTodos();
    renderTodos();
    updateTodoFilterButton();
    showToast('已添加到 Todo');
    
    // 如果已登录，同步到服务器
    if (authState.isLoggedIn) {
      const result = await addTodoToAPI(newTodo);
      if (result.ok && result.todo) {
        // 更新本地 ID 为服务器返回的 ID
        const idx = todos.findIndex(t => t.id === newTodo.id);
        if (idx >= 0) {
          todos[idx].id = String(result.todo.id);
          saveTodos();
        }
      } else if (!result.needsAuth) {
        console.warn('[Todo] Failed to add to server:', result.error);
      }
    } else {
      // 未登录，添加到待同步列表
      const pending = await getPendingSyncTodos();
      pending.push(newTodo);
      savePendingSyncTodos(pending);
    }
  }

  async function addTodoManual(text) {
    const trimmed = String(text || '').trim().replace(/\s+/g, ' ');
    if (!trimmed) {
      showToast('请输入 Todo 内容');
      return;
    }

    const newTodo = {
      id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
      createdAt: Date.now(),
      done: false,
      text: trimmed,
      source: null
    };

    todos.push(newTodo);
    saveTodos();
    renderTodos();
    updateTodoFilterButton();

    if (elements.todoInput) {
      elements.todoInput.value = '';
      elements.todoInput.focus();
    }
    showToast('已添加到 Todo');
    
    // 如果已登录，同步到服务器
    if (authState.isLoggedIn) {
      const result = await addTodoToAPI(newTodo);
      if (result.ok && result.todo) {
        // 更新本地 ID 为服务器返回的 ID
        const idx = todos.findIndex(t => t.id === newTodo.id);
        if (idx >= 0) {
          todos[idx].id = String(result.todo.id);
          saveTodos();
        }
      } else if (!result.needsAuth) {
        console.warn('[Todo] Failed to add to server:', result.error);
      }
    } else {
      // 未登录，添加到待同步列表
      const pending = await getPendingSyncTodos();
      pending.push(newTodo);
      savePendingSyncTodos(pending);
    }
  }

  function formatTodoTime(ts) {
    const d = new Date(ts);
    if (Number.isNaN(d.getTime())) return '';
    const pad = (n) => String(n).padStart(2, '0');
    const y = d.getFullYear();
    const m = pad(d.getMonth() + 1);
    const day = pad(d.getDate());
    const hh = pad(d.getHours());
    const mm = pad(d.getMinutes());
    return `${y}-${m}-${day} ${hh}:${mm}`;
  }

  function normalizeUrl(href) {
    try {
      const u = new URL(href);
      u.hash = '';
      return u.toString();
    } catch {
      return String(href || '').split('#')[0];
    }
  }

  function loadTodoPrefs() {
    chrome.storage.local.get(['todoShowAll'], (result) => {
      todoShowAll = Boolean(result.todoShowAll);
      updateTodoFilterButton();
      renderTodos();
    });
  }

  function saveTodoPrefs() {
    chrome.storage.local.set({ todoShowAll });
  }

  function updateTodoFilterButton() {
    if (!elements.todoFilterBtn) return;
    if (todoShowAll) {
      elements.todoFilterBtn.textContent = '只看未完成';
      elements.todoFilterBtn.title = '只看未完成';
    } else {
      elements.todoFilterBtn.textContent = '显示全部';
      elements.todoFilterBtn.title = '显示全部';
    }
  }

  function toggleTodoFilter() {
    todoShowAll = !todoShowAll;
    saveTodoPrefs();
    updateTodoFilterButton();
    renderTodos();
  }

  function renderTodos() {
    if (!elements.todoList) return;
    const visible = todoShowAll ? todos : todos.filter(t => !t.done);
    
    // 按分组整理
    const groups = {};
    for (const todo of visible) {
      const groupId = todo.source?.groupId || 'manual';
      if (!groups[groupId]) {
        groups[groupId] = {
          groupId: groupId,
          title: todo.source?.pageTitle || '手动添加',
          url: todo.source?.pageUrl || '',
          isCustom: todo.source?.isCustom || false,
          todos: []
        };
      }
      groups[groupId].todos.push(todo);
    }

    // 按最新 Todo 时间排序分组
    const sortedGroups = Object.values(groups).sort((a, b) => {
      const aMax = Math.max(...a.todos.map(t => t.createdAt || 0));
      const bMax = Math.max(...b.todos.map(t => t.createdAt || 0));
      return bMax - aMax;
    });

    if (!sortedGroups.length) {
      elements.todoList.innerHTML = `
        <div class="sp-todo-empty">
          <div class="sp-todo-empty-icon">📋</div>
          <div class="sp-todo-empty-title">暂无待办事项</div>
          <div class="sp-todo-empty-desc">点击「+ 新建标题」创建分组</div>
        </div>
      `;
      updateTodoCount();
      return;
    }

    elements.todoList.innerHTML = sortedGroups.map(group => {
      const unfinishedCount = group.todos.filter(t => !t.done).length;
      const totalCount = group.todos.length;
      const isCollapsed = isTodoGroupCollapsed(group.groupId);
      
      // 组内按完成状态和时间排序
      const sortedTodos = [...group.todos].sort((a, b) => {
        if (Boolean(a.done) !== Boolean(b.done)) return a.done ? 1 : -1;
        return (b.createdAt || 0) - (a.createdAt || 0);
      });

      // 链接按钮 - 有 URL 时显示
      const linkBtn = group.url 
        ? `<a href="${escapeHtml(group.url)}" target="_blank" rel="noopener noreferrer" class="sp-todo-group-link-btn" title="查看原文" onclick="event.stopPropagation()">🔗</a>`
        : '';
      
      // 总结按钮 - 非自定义分组显示
      const summaryBtn = !group.isCustom && group.groupId !== 'manual'
        ? `<button class="sp-todo-group-summary-btn" data-group-id="${escapeHtml(group.groupId)}" data-group-title="${escapeHtml(group.title)}" data-group-url="${escapeHtml(group.url || '')}" title="查看总结">✨</button>`
        : '';

      return `
        <div class="sp-todo-group ${isCollapsed ? 'collapsed' : ''}" data-group-id="${escapeHtml(group.groupId)}">
          <div class="sp-todo-group-header">
            <span class="sp-todo-group-toggle">▼</span>
            <span class="sp-todo-group-title" title="${escapeHtml(group.title)}">${escapeHtml(group.title)}</span>
            <span class="sp-todo-group-count">${unfinishedCount}/${totalCount}</span>
            <div class="sp-todo-group-actions">
              ${linkBtn}
              ${summaryBtn}
              <button class="sp-todo-group-add-btn" title="添加 Todo">+</button>
            </div>
          </div>
          <div class="sp-todo-group-items">
            <div class="sp-todo-group-items-inner">
              ${sortedTodos.map(t => `
                <div class="sp-todo-item ${t.done ? 'done' : ''}" data-id="${escapeHtml(t.id)}">
                  <input type="checkbox" class="sp-todo-checkbox" ${t.done ? 'checked' : ''}>
                  <span class="sp-todo-text">${escapeHtml(t.text || '')}</span>
                  <button class="sp-todo-delete-btn" title="删除">×</button>
                </div>
              `).join('')}
            </div>
          </div>
        </div>
      `;
    }).join('');

    bindTodoEvents();
    updateTodoCount();
  }

  // Todo 分组折叠状态管理
  const TODO_COLLAPSED_KEY = 'todo_collapsed_groups';
  
  function getTodoCollapsedGroups() {
    try {
      const data = localStorage.getItem(TODO_COLLAPSED_KEY);
      return data ? JSON.parse(data) : {};
    } catch {
      return {};
    }
  }
  
  function saveTodoCollapsedGroups(collapsed) {
    try {
      localStorage.setItem(TODO_COLLAPSED_KEY, JSON.stringify(collapsed));
    } catch { /* ignore */ }
  }
  
  function isTodoGroupCollapsed(groupId) {
    const collapsed = getTodoCollapsedGroups();
    // 默认折叠（跟hotnews一样）
    return collapsed[groupId] !== false;
  }
  
  function toggleTodoGroupCollapse(groupId) {
    const collapsed = getTodoCollapsedGroups();
    collapsed[groupId] = !collapsed[groupId];
    saveTodoCollapsedGroups(collapsed);
    
    const groupEl = elements.todoList?.querySelector(`.sp-todo-group[data-group-id="${groupId}"]`);
    if (groupEl) {
      groupEl.classList.toggle('collapsed', collapsed[groupId]);
    }
  }

  function bindTodoEvents() {
    if (!elements.todoList) return;
    
    // 分组折叠事件
    elements.todoList.querySelectorAll('.sp-todo-group').forEach(groupEl => {
      const groupId = groupEl.dataset.groupId;
      const header = groupEl.querySelector('.sp-todo-group-header');
      
      header?.addEventListener('click', (e) => {
        if (e.target.closest('.sp-todo-group-add-btn')) return;
        if (e.target.closest('.sp-todo-group-summary-btn')) return;
        if (e.target.closest('.sp-todo-group-link-btn')) return;
        toggleTodoGroupCollapse(groupId);
      });
      
      // 添加 Todo 按钮
      const addBtn = groupEl.querySelector('.sp-todo-group-add-btn');
      addBtn?.addEventListener('click', (e) => {
        e.stopPropagation();
        const group = todos.find(t => (t.source?.groupId || 'manual') === groupId);
        showTodoAddInput(groupId, group?.source?.pageTitle || '手动添加', group?.source?.pageUrl || '', group?.source?.isCustom || false);
      });
      
      // 总结按钮
      const summaryBtn = groupEl.querySelector('.sp-todo-group-summary-btn');
      summaryBtn?.addEventListener('click', (e) => {
        e.stopPropagation();
        const gid = summaryBtn.dataset.groupId;
        const title = summaryBtn.dataset.groupTitle;
        const url = summaryBtn.dataset.groupUrl;
        // 打开总结 - 可以跳转到 hotnews 或显示总结
        if (url) {
          chrome.tabs.create({ url });
        }
      });
    });
    
    // Todo 项事件
    elements.todoList.querySelectorAll('.sp-todo-item').forEach(item => {
      const id = item.dataset.id;
      const checkbox = item.querySelector('.sp-todo-checkbox');
      const deleteBtn = item.querySelector('.sp-todo-delete-btn');
      
      checkbox?.addEventListener('change', () => toggleTodo(id, checkbox.checked));
      deleteBtn?.addEventListener('click', (e) => {
        e.stopPropagation();
        deleteTodo(id);
      });
    });
  }

  function showTodoAddInput(groupId, groupTitle, groupUrl, isCustom) {
    const groupEl = elements.todoList?.querySelector(`.sp-todo-group[data-group-id="${groupId}"]`);
    if (!groupEl) return;
    
    // 展开分组
    groupEl.classList.remove('collapsed');
    const collapsed = getTodoCollapsedGroups();
    collapsed[groupId] = false;
    saveTodoCollapsedGroups(collapsed);
    
    const itemsInner = groupEl.querySelector('.sp-todo-group-items-inner');
    if (!itemsInner) return;
    
    // 检查是否已有输入框
    if (itemsInner.querySelector('.sp-todo-add-input')) return;
    
    const inputHtml = `
      <div class="sp-todo-add-input">
        <input type="text" class="sp-todo-text-input" placeholder="输入 Todo 内容..." autofocus>
        <button class="sp-todo-add-confirm-btn">添加</button>
      </div>
    `;
    itemsInner.insertAdjacentHTML('afterbegin', inputHtml);
    
    const inputEl = itemsInner.querySelector('.sp-todo-text-input');
    const confirmBtn = itemsInner.querySelector('.sp-todo-add-confirm-btn');
    
    inputEl?.focus();
    
    const doAdd = async () => {
      const text = inputEl?.value?.trim();
      if (!text) {
        showToast('请输入 Todo 内容');
        return;
      }
      await addTodoToGroup(text, groupId, groupTitle, groupUrl, isCustom);
      inputEl.value = '';
      renderTodos();
    };
    
    confirmBtn?.addEventListener('click', doAdd);
    inputEl?.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.isComposing) {
        e.preventDefault();
        doAdd();
      }
      if (e.key === 'Escape') {
        itemsInner.querySelector('.sp-todo-add-input')?.remove();
      }
    });
  }

  async function addTodoToGroup(text, groupId, groupTitle, groupUrl, isCustom) {
    const newTodo = {
      id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
      createdAt: Date.now(),
      done: false,
      text: text,
      source: {
        groupId: groupId,
        pageTitle: groupTitle,
        pageUrl: groupUrl,
        isCustom: isCustom
      }
    };

    todos.push(newTodo);
    saveTodos();
    showToast('已添加到 Todo');
    
    // 如果已登录，同步到服务器
    if (authState.isLoggedIn) {
      const result = await addTodoToAPI(newTodo);
      if (result.ok && result.todo) {
        const idx = todos.findIndex(t => t.id === newTodo.id);
        if (idx >= 0) {
          todos[idx].id = String(result.todo.id);
          saveTodos();
        }
      }
    }
  }

  function showNewGroupInput() {
    if (!elements.todoList) return;
    
    // 检查是否已有输入框
    if (elements.todoList.querySelector('.sp-todo-new-group-input')) return;
    
    const inputHtml = `
      <div class="sp-todo-new-group-input">
        <input type="text" class="sp-todo-group-name-input" placeholder="输入新标题名称..." autofocus>
        <button class="sp-todo-group-create-btn">创建</button>
        <button class="sp-todo-group-cancel-btn">取消</button>
      </div>
    `;
    elements.todoList.insertAdjacentHTML('afterbegin', inputHtml);
    
    const inputEl = elements.todoList.querySelector('.sp-todo-group-name-input');
    const createBtn = elements.todoList.querySelector('.sp-todo-group-create-btn');
    const cancelBtn = elements.todoList.querySelector('.sp-todo-group-cancel-btn');
    
    inputEl?.focus();
    
    const createGroup = () => {
      const title = inputEl?.value?.trim();
      if (!title) {
        showToast('请输入标题名称');
        return;
      }
      // 创建自定义分组
      const groupId = `custom_${Date.now()}`;
      elements.todoList.querySelector('.sp-todo-new-group-input')?.remove();
      
      // 创建一个空的分组并显示添加输入框
      createEmptyGroup(groupId, title);
    };
    
    createBtn?.addEventListener('click', createGroup);
    cancelBtn?.addEventListener('click', () => {
      elements.todoList.querySelector('.sp-todo-new-group-input')?.remove();
    });
    inputEl?.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.isComposing) {
        e.preventDefault();
        createGroup();
      }
      if (e.key === 'Escape') {
        elements.todoList.querySelector('.sp-todo-new-group-input')?.remove();
      }
    });
  }

  function createEmptyGroup(groupId, title) {
    // 先渲染一个空分组
    const groupHtml = `
      <div class="sp-todo-group" data-group-id="${escapeHtml(groupId)}">
        <div class="sp-todo-group-header">
          <span class="sp-todo-group-toggle">▼</span>
          <span class="sp-todo-group-title" title="${escapeHtml(title)}">${escapeHtml(title)}</span>
          <span class="sp-todo-group-count">0/0</span>
          <div class="sp-todo-group-actions">
            <button class="sp-todo-group-add-btn" title="添加 Todo">+</button>
          </div>
        </div>
        <div class="sp-todo-group-items">
          <div class="sp-todo-group-items-inner"></div>
        </div>
      </div>
    `;
    
    // 移除空状态
    const emptyEl = elements.todoList.querySelector('.sp-todo-empty');
    if (emptyEl) emptyEl.remove();
    
    elements.todoList.insertAdjacentHTML('afterbegin', groupHtml);
    
    const groupEl = elements.todoList.querySelector(`.sp-todo-group[data-group-id="${groupId}"]`);
    
    // 绑定事件
    const header = groupEl?.querySelector('.sp-todo-group-header');
    header?.addEventListener('click', (e) => {
      if (e.target.closest('.sp-todo-group-add-btn')) return;
      toggleTodoGroupCollapse(groupId);
    });
    
    const addBtn = groupEl?.querySelector('.sp-todo-group-add-btn');
    addBtn?.addEventListener('click', (e) => {
      e.stopPropagation();
      showTodoAddInput(groupId, title, '', true);
    });
    
    // 自动显示添加输入框
    showTodoAddInput(groupId, title, '', true);
  }

    function updateTodoCount() {
    const countEl = document.getElementById('sp-todo-count');
    if (!countEl) return;

    const pendingCount = todos.filter(t => !t.done).length;
    if (pendingCount > 0) {
      countEl.textContent = pendingCount > 99 ? '99+' : pendingCount;
      countEl.classList.add('show');
    } else {
      countEl.classList.remove('show');
    }
  }

  async function toggleTodo(id, done) {
    const idx = todos.findIndex(t => t.id === id);
    if (idx < 0) return;
    todos[idx] = { ...todos[idx], done: Boolean(done) };
    saveTodos();
    renderTodos();
    
    // 如果已登录，同步到服务器
    if (authState.isLoggedIn) {
      const result = await updateTodoToAPI(id, { done: Boolean(done) });
      if (!result.ok && !result.needsAuth) {
        console.warn('[Todo] Failed to update on server:', result.error);
      }
    }
  }

  async function deleteTodo(id) {
    todos = todos.filter(t => t.id !== id);
    saveTodos();
    renderTodos();
    syncTodoModalFromStorage();
    
    // 如果已登录，同步到服务器
    if (authState.isLoggedIn) {
      const result = await deleteTodoFromAPI(id);
      if (!result.ok && !result.needsAuth) {
        console.warn('[Todo] Failed to delete from server:', result.error);
      }
    }
  }

  function handleClearTodos() {
    if (!todos.length) {
      showToast('没有 Todo');
      return;
    }

    showConfirm('清空 Todo', '确定要删除所有 Todo 吗？', async () => {
      const todosToRemove = [...todos];
      todos = [];
      saveTodos();
      renderTodos();
      syncTodoModalFromStorage();
      showToast('Todo 已清空');
      
      // 如果已登录，同步删除到服务器
      if (authState.isLoggedIn) {
        for (const todo of todosToRemove) {
          await deleteTodoFromAPI(todo.id);
        }
      }
      
      // 清空待同步列表
      clearPendingSyncTodos();
    });
  }

  function openTodoSource(id) {
    const t = todos.find(x => x.id === id);
    const url = t?.source?.pageUrl;
    if (!url) {
      showToast('没有原文链接');
      return;
    }

    const normalized = normalizeUrl(url);
    chrome.tabs.query({}, (tabs) => {
      const match = (tabs || []).find(tab => normalizeUrl(tab?.url || '') === normalized);
      if (match?.id) {
        chrome.tabs.update(match.id, { active: true });
        if (match.windowId) chrome.windows.update(match.windowId, { focused: true });
        return;
      }
      chrome.tabs.create({ url: normalized });
    });
  }

  function ensureTodoModal() {
    if (todoModalEl) return todoModalEl;

    const overlay = document.createElement('div');
    overlay.className = 'sp-todo-modal-overlay';
    overlay.innerHTML = `
      <div class="sp-todo-modal is-maximized" role="dialog" aria-modal="true">
        <div class="sp-todo-modal-header">
          <div class="sp-todo-modal-title">Todo</div>
          <div class="sp-todo-modal-header-actions">
            <button class="sp-todo-modal-close" type="button">关闭</button>
          </div>
        </div>
        <div class="sp-todo-modal-body">
          <textarea class="sp-todo-modal-input" rows="4"></textarea>
          <div class="sp-todo-modal-meta"></div>
          <div class="sp-todo-chat">
            <div class="sp-todo-chat-history"></div>
            <div class="sp-todo-chat-input-row">
              <input class="sp-todo-chat-input" type="text" placeholder="继续提问..." autocomplete="off" />
              <button class="sp-todo-chat-send" type="button">发送</button>
            </div>
          </div>
        </div>
      </div>
    `;

    document.body.appendChild(overlay);
    todoModalEl = overlay;

    const closeBtn = overlay.querySelector('.sp-todo-modal-close');
    if (closeBtn) closeBtn.addEventListener('click', closeTodoModal);
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) closeTodoModal();
    });

    const inputEl = overlay.querySelector('.sp-todo-modal-input');
    const chatInputEl = overlay.querySelector('.sp-todo-chat-input');
    const chatSendBtn = overlay.querySelector('.sp-todo-chat-send');
    if (chatSendBtn) chatSendBtn.addEventListener('click', handleTodoChatSend);
    if (chatInputEl) {
      chatInputEl.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.isComposing && e.keyCode !== 229) {
          e.preventDefault();
          handleTodoChatSend();
        }
      });
    }
    if (inputEl) {
      inputEl.addEventListener('input', () => {
        if (todoModalSaveTimer) clearTimeout(todoModalSaveTimer);
        todoModalSaveTimer = setTimeout(() => {
          todoModalSaveTimer = null;
          saveTodoModalText({ silent: true });
        }, 400);
      });
      inputEl.addEventListener('blur', () => {
        if (todoModalSaveTimer) {
          clearTimeout(todoModalSaveTimer);
          todoModalSaveTimer = null;
        }
        saveTodoModalText({ silent: true });
      });
    }

    return overlay;
  }

  function saveTodoModalText(options) {
    const opts = options || {};
    if (!todoModalEl || !todoModalTodoId) return;
    const idx = todos.findIndex(t => t.id === todoModalTodoId);
    if (idx < 0) return;
    const inputEl = todoModalEl.querySelector('.sp-todo-modal-input');
    const nextText = String(inputEl?.value || '').trim().replace(/\s+/g, ' ');
    if (!nextText) return;
    if (todos[idx]?.text === nextText) return;
    todos[idx] = { ...todos[idx], text: nextText };
    saveTodos();
    renderTodos();
    if (!opts.silent) showToast('已保存');
  }

  function closeTodoModal() {
    if (!todoModalEl) return;
    if (todoModalSaveTimer) {
      clearTimeout(todoModalSaveTimer);
      todoModalSaveTimer = null;
    }
    saveTodoModalText({ silent: true });
    todoModalEl.style.display = 'none';
    todoModalTodoId = null;
    todoModalAiLoading = false;
  }

  function openTodoModal(id) {
    const modal = ensureTodoModal();
    const t = todos.find(x => x.id === id);
    if (!t) return;

    todoModalTodoId = id;
    todoModalAiLoading = false;
    modal.style.display = 'flex';

    const inputEl = modal.querySelector('.sp-todo-modal-input');
    const metaEl = modal.querySelector('.sp-todo-modal-meta');
    const chatHistoryEl = modal.querySelector('.sp-todo-chat-history');
    const chatInputEl = modal.querySelector('.sp-todo-chat-input');
    if (inputEl) inputEl.value = t.text || '';

    const pageTitle = t?.source?.pageTitle || '当前页面';
    const url = t?.source?.pageUrl || '';
    const createdAt = t?.createdAt ? formatTodoTime(t.createdAt) : '';
    const urlPart = url ? ` · ${escapeHtml(url)}` : '';
    const timePart = createdAt ? ` · 添加于 ${escapeHtml(createdAt)}` : '';
    if (metaEl) metaEl.innerHTML = `${escapeHtml(pageTitle)}${urlPart}${timePart}`;

    if (chatHistoryEl) {
      renderTodoChatHistory(chatHistoryEl, t?.enrich?.chat);
    }
    if (chatInputEl) chatInputEl.value = '';

    if (inputEl) setTimeout(() => inputEl.focus(), 0);
  }

  function syncTodoModalFromStorage() {
    if (!todoModalEl || !todoModalTodoId) return;
    const idx = todos.findIndex(t => t.id === todoModalTodoId);
    if (idx < 0) {
      closeTodoModal();
      return;
    }
    const t = todos[idx];
    const chatHistoryEl = todoModalEl.querySelector('.sp-todo-chat-history');
    const enrich = t?.enrich;

    if (chatHistoryEl) {
      renderTodoChatHistory(chatHistoryEl, enrich?.chat);
    }
  }

  function getTodoChatHistory(todo) {
    const arr = todo?.enrich?.chat;
    return Array.isArray(arr) ? arr : [];
  }

  function renderTodoChatHistory(container, chat) {
    const items = Array.isArray(chat) ? chat : [];
    if (!items.length) {
      container.innerHTML = '<div class="sp-todo-chat-empty">你可以在这里继续提问。</div>';
      return;
    }
    container.innerHTML = items.map((m) => {
      const role = m?.role === 'assistant' ? 'assistant' : 'user';
      const cls = role === 'assistant' ? 'sp-todo-chat-msg is-assistant' : 'sp-todo-chat-msg is-user';
      const content = String(m?.content || '');
      return `<div class="${cls}">${role === 'assistant' ? renderMarkdown(content) : escapeHtml(content)}</div>`;
    }).join('');
    container.scrollTop = container.scrollHeight;
  }

  async function handleTodoChatSend() {
    if (!todoModalEl || !todoModalTodoId) return;
    const idx = todos.findIndex(t => t.id === todoModalTodoId);
    if (idx < 0) return;

    const chatInputEl = todoModalEl.querySelector('.sp-todo-chat-input');
    const chatHistoryEl = todoModalEl.querySelector('.sp-todo-chat-history');
    const question = String(chatInputEl?.value || '').trim();
    if (!question) {
      showToast('请输入提问内容');
      return;
    }

    const hist = getTodoChatHistory(todos[idx]);
    const nextHist = [...hist, { role: 'user', content: question, createdAt: Date.now() }];
    todos[idx] = {
      ...todos[idx],
      enrich: {
        ...(todos[idx].enrich || {}),
        chat: nextHist,
        updatedAt: Date.now()
      }
    };
    saveTodos();
    renderTodos();
    if (chatHistoryEl) renderTodoChatHistory(chatHistoryEl, nextHist);

    if (chatInputEl) {
      chatInputEl.value = '';
      chatInputEl.focus();
    }

    if (chatHistoryEl) {
      chatHistoryEl.innerHTML += '<div class="sp-todo-chat-msg is-assistant"><div class="sp-todo-modal-loading">AI 思考中...</div></div>';
      chatHistoryEl.scrollTop = chatHistoryEl.scrollHeight;
    }

    const resp = await sendMessageSafe({
      type: 'TODO_CHAT',
      todo: {
        id: todos[idx].id,
        text: todos[idx].text,
        source: todos[idx].source
      },
      history: nextHist.map(({ role, content }) => ({ role, content })),
      question
    });

    if (!resp?.success) {
      const errMsg = resp?.error || '查询失败';
      const failHist = [...nextHist, { role: 'assistant', content: `查询失败：${errMsg}`, createdAt: Date.now(), error: true }];
      todos[idx] = {
        ...todos[idx],
        enrich: {
          ...(todos[idx].enrich || {}),
          chat: failHist,
          updatedAt: Date.now()
        }
      };
      saveTodos();
      renderTodos();
      if (chatHistoryEl) renderTodoChatHistory(chatHistoryEl, failHist);
      return;
    }

    const answer = String(resp.content || '').trim();
    const finalHist = [...nextHist, { role: 'assistant', content: answer, createdAt: Date.now() }];
    todos[idx] = {
      ...todos[idx],
      enrich: {
        ...(todos[idx].enrich || {}),
        chat: finalHist,
        updatedAt: Date.now()
      }
    };
    saveTodos();
    renderTodos();
    if (chatHistoryEl) renderTodoChatHistory(chatHistoryEl, finalHist);
  }

  function handleTodoModalSave() {
    if (!todoModalEl || !todoModalTodoId) return;
    const idx = todos.findIndex(t => t.id === todoModalTodoId);
    if (idx < 0) return;
    const inputEl = todoModalEl.querySelector('.sp-todo-modal-input');
    const nextText = String(inputEl?.value || '').trim().replace(/\s+/g, ' ');
    if (!nextText) {
      showToast('请输入 Todo 内容');
      return;
    }

    const prevText = String(todos[idx].text || '');
    const next = { ...todos[idx], text: nextText };
    if (prevText.trim().replace(/\s+/g, ' ') !== nextText) {
      if (next.enrich) delete next.enrich;
    }
    todos[idx] = next;
    saveTodos();
    renderTodos();
    showToast('已保存');
  }

  function sendMessageSafe(message) {
    const shouldUsePort = (message?.type === 'TODO_ENRICH' || message?.type === 'TODO_CHAT');
    if (shouldUsePort && keepAlivePort) {
      return new Promise((resolve) => {
        const reqId = `${Date.now()}-${(keepAliveReqSeq += 1)}-${Math.random().toString(16).slice(2)}`;
        const timeoutMs = 90000;
        const timeoutId = setTimeout(() => {
          keepAlivePending.delete(reqId);
          resolve({ success: false, error: `请求超时（${Math.round(timeoutMs / 1000)}s）` });
        }, timeoutMs);
        keepAlivePending.set(reqId, { resolve, timeoutId });

        try {
          keepAlivePort.postMessage({ ...message, __reqId: reqId });
        } catch (e) {
          keepAlivePending.delete(reqId);
          clearTimeout(timeoutId);
          resolve({ success: false, error: e?.message || String(e) });
        }
      });
    }

    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(message, (resp) => {
          const err = chrome.runtime.lastError;
          if (err) resolve({ success: false, error: err.message || String(err) });
          else resolve(resp);
        });
      } catch (e) {
        resolve({ success: false, error: e?.message || String(e) });
      }
    });
  }

  function initSelectionTodo() {
    selectionTodoBtn = document.createElement('button');
    selectionTodoBtn.className = 'sp-selection-todo-btn';
    selectionTodoBtn.type = 'button';
    selectionTodoBtn.textContent = '+Todo';
    selectionTodoBtn.style.display = 'none';
    document.body.appendChild(selectionTodoBtn);

    const hide = () => {
      selectionTodoBtn.style.display = 'none';
      selectionTodoBtn.dataset.selectionText = '';
      selectionTodoBtn.dataset.sourceSummaryId = '';
    };

    const getSelectionData = () => {
      const sel = window.getSelection();
      if (!sel || sel.isCollapsed) return null;
      const text = sel.toString();
      if (!String(text || '').trim()) return null;

      const range = sel.rangeCount ? sel.getRangeAt(0) : null;
      if (!range) return null;
      const containerNode = range.commonAncestorContainer;
      const containerEl = containerNode?.nodeType === Node.ELEMENT_NODE ? containerNode : containerNode?.parentElement;
      if (!containerEl) return null;

      if (!elements.chatContainer || !elements.chatContainer.contains(containerEl)) return null;
      if (containerEl.closest && containerEl.closest('.sp-todo')) return null;

      const msgEl = containerEl.closest('.sp-message');
      let summaryId = '';
      let source = null;
      if (msgEl && msgEl.hasAttribute('data-index')) {
        const idx = parseInt(msgEl.getAttribute('data-index'), 10);
        const msg = Number.isFinite(idx) ? chatHistory[idx] : null;
        summaryId = msg?.id || '';
        if (msg) {
          source = {
            pageTitle: msg.pageTitle || '未知页面',
            pageUrl: msg.pageUrl || '',
            promptName: msg.promptName || '',
            promptId: msg.promptId || '',
            summaryId
          };
        }
      }

      if (!source) {
        const pageInfo = window._currentPageInfo || {};
        source = {
          pageTitle: pageInfo.title || '未知页面',
          pageUrl: pageInfo.url || '',
          promptName: pageInfo.promptName || '',
          promptId: pageInfo.promptId || '',
          summaryId
        };
      }

      return { text, source, range };
    };

    const showForCurrentSelection = () => {
      const data = getSelectionData();
      if (!data) {
        hide();
        return;
      }

      const rect = data.range.getBoundingClientRect();
      if (!rect || (!rect.width && !rect.height)) {
        hide();
        return;
      }

      const btnWidth = 64;
      const btnHeight = 34;
      const margin = 8;
      const left = Math.min(window.innerWidth - btnWidth - margin, Math.max(margin, rect.right - btnWidth));
      const top = Math.min(window.innerHeight - btnHeight - margin, Math.max(margin, rect.bottom + margin));

      selectionTodoBtn.style.left = `${left}px`;
      selectionTodoBtn.style.top = `${top}px`;
      selectionTodoBtn.style.display = 'block';
      selectionTodoBtn.dataset.selectionText = data.text;
      selectionTodoBtn.dataset.sourceSummaryId = data.source.summaryId || '';
      selectionTodoBtn._source = data.source;
    };

    selectionTodoBtn.addEventListener('click', () => {
      const text = selectionTodoBtn.dataset.selectionText || '';
      const source = selectionTodoBtn._source || null;
      addTodoFromSelection(text, source);
      try {
        window.getSelection()?.removeAllRanges();
      } catch { }
      hide();
    });

    document.addEventListener('mouseup', () => setTimeout(showForCurrentSelection, 0));
    document.addEventListener('keyup', () => setTimeout(showForCurrentSelection, 0));
    document.addEventListener('scroll', hide, true);
    window.addEventListener('resize', hide);
    document.addEventListener('mousedown', (e) => {
      if (selectionTodoBtn.contains(e.target)) return;
      if (e.target.closest && e.target.closest('.sp-selection-todo-btn')) return;
      if (e.target.closest && e.target.closest('.sp-todo')) return;
      hide();
    });
  }
});

// ============ 数据加载 ============

// 加载提示词列表
function loadPrompts() {
  chrome.runtime.sendMessage({ type: 'GET_PROMPTS' }, (response) => {
    if (response?.prompts) {
      currentPrompts = response.prompts;
      selectedPromptId = response.selectedId;
      renderPromptOptions();
    }
  });
}

// 渲染提示词选项
function renderPromptOptions() {
  if (!elements.promptSelect) return;
  elements.promptSelect.innerHTML = currentPrompts.map(p =>
    `<option value="${p.id}" ${p.id === selectedPromptId ? 'selected' : ''}>${p.name}</option>`
  ).join('');
}

// 处理提示词切换
function handlePromptChange() {
  if (!elements.promptSelect) return;
  selectedPromptId = elements.promptSelect.value;
  chrome.runtime.sendMessage({
    type: 'SELECT_PROMPT',
    promptId: selectedPromptId
  });
}

// 加载聊天历史
function loadHistory() {
  chrome.storage.local.get(['chatHistory'], (result) => {
    chatHistory = result.chatHistory || [];
    renderHistory();

    if (pendingLocateSummaryUrl) {
      const url = pendingLocateSummaryUrl;
      pendingLocateSummaryUrl = null;
      locateSummaryByUrl(url, { showToast: true });
    }
  });
}

// ============ 收藏功能 ============
let favorites = [];
let favoritesSyncing = false;

// 本地存储 key
const FAVORITES_LOCAL_KEY = 'favorites';
const FAVORITES_PENDING_SYNC_KEY = 'favorites_pending_sync';

/**
 * 从后端 API 获取收藏列表
 */
async function fetchFavoritesFromAPI() {
  try {
    const response = await fetch(`${API_BASE_URL}/api/user/favorites`, {
      method: 'GET',
      credentials: 'include',
      headers: {
        'Accept': 'application/json'
      }
    });
    
    if (response.status === 401) {
      return { needsAuth: true };
    }
    
    if (!response.ok) {
      throw new Error('Failed to fetch favorites');
    }
    
    const data = await response.json();
    if (data.ok) {
      return { favorites: data.favorites || [] };
    }
    return { error: data.message || 'Unknown error' };
  } catch (e) {
    console.error('[Favorites] Fetch error:', e);
    return { error: e.message };
  }
}

/**
 * 添加收藏到后端 API
 */
async function addFavoriteToAPI(favoriteItem) {
  try {
    const response = await fetch(`${API_BASE_URL}/api/user/favorites`, {
      method: 'POST',
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify({
        news_id: favoriteItem.summaryId || favoriteItem.news_id,
        title: favoriteItem.pageTitle || favoriteItem.title,
        url: favoriteItem.pageUrl || favoriteItem.url,
        source_name: favoriteItem.promptName || favoriteItem.source_name || ''
      })
    });
    
    if (response.status === 401) {
      handle401Error();
      return { ok: false, needsAuth: true };
    }
    
    const data = await response.json();
    return data;
  } catch (e) {
    console.error('[Favorites] Add error:', e);
    return { ok: false, error: e.message };
  }
}

/**
 * 从后端 API 删除收藏
 */
async function removeFavoriteFromAPI(newsId) {
  try {
    const response = await fetch(`${API_BASE_URL}/api/user/favorites/${encodeURIComponent(newsId)}`, {
      method: 'DELETE',
      credentials: 'include',
      headers: {
        'Accept': 'application/json'
      }
    });
    
    if (response.status === 401) {
      handle401Error();
      return { ok: false, needsAuth: true };
    }
    
    const data = await response.json();
    return data;
  } catch (e) {
    console.error('[Favorites] Remove error:', e);
    return { ok: false, error: e.message };
  }
}

/**
 * 获取本地存储的收藏
 */
function getLocalFavorites() {
  return new Promise((resolve) => {
    chrome.storage.local.get([FAVORITES_LOCAL_KEY], (result) => {
      resolve(result[FAVORITES_LOCAL_KEY] || []);
    });
  });
}

/**
 * 保存收藏到本地存储
 */
function saveLocalFavorites(favs) {
  chrome.storage.local.set({ [FAVORITES_LOCAL_KEY]: favs });
}

/**
 * 获取待同步的本地收藏
 */
function getPendingSyncFavorites() {
  return new Promise((resolve) => {
    chrome.storage.local.get([FAVORITES_PENDING_SYNC_KEY], (result) => {
      resolve(result[FAVORITES_PENDING_SYNC_KEY] || []);
    });
  });
}

/**
 * 保存待同步的收藏
 */
function savePendingSyncFavorites(favs) {
  chrome.storage.local.set({ [FAVORITES_PENDING_SYNC_KEY]: favs });
}

/**
 * 清空待同步的收藏
 */
function clearPendingSyncFavorites() {
  chrome.storage.local.remove([FAVORITES_PENDING_SYNC_KEY]);
}

/**
 * 登录后同步本地收藏到服务器
 */
async function syncLocalFavoritesToServer() {
  if (favoritesSyncing) return;
  if (!authState.isLoggedIn) return;
  
  favoritesSyncing = true;
  
  try {
    const pendingFavorites = await getPendingSyncFavorites();
    
    if (pendingFavorites.length === 0) {
      favoritesSyncing = false;
      return;
    }
    
    console.log('[Favorites] Syncing', pendingFavorites.length, 'local favorites to server');
    
    let syncedCount = 0;
    for (const fav of pendingFavorites) {
      const result = await addFavoriteToAPI(fav);
      if (result.ok || result.error?.includes('已存在')) {
        syncedCount++;
      }
    }
    
    // 清空待同步列表
    clearPendingSyncFavorites();
    
    if (syncedCount > 0) {
      console.log('[Favorites] Synced', syncedCount, 'favorites to server');
      // 重新从服务器加载以获取最新数据
      await loadFavorites();
    }
  } catch (e) {
    console.error('[Favorites] Sync error:', e);
  } finally {
    favoritesSyncing = false;
  }
}

// ============ Todo API 同步功能 ============
const TODOS_LOCAL_KEY = 'todos';
const TODOS_PENDING_SYNC_KEY = 'todos_pending_sync';
let todosSyncing = false;

/**
 * 从后端 API 获取 Todo 列表
 */
async function fetchTodosFromAPI() {
  try {
    const response = await fetch(`${API_BASE_URL}/api/user/todos`, {
      method: 'GET',
      credentials: 'include',
      headers: {
        'Accept': 'application/json'
      }
    });
    
    if (response.status === 401) {
      return { needsAuth: true };
    }
    
    if (!response.ok) {
      throw new Error('Failed to fetch todos');
    }
    
    const data = await response.json();
    if (data.ok) {
      return { todos: data.todos || [] };
    }
    return { error: data.message || 'Unknown error' };
  } catch (e) {
    console.error('[Todo] Fetch error:', e);
    return { error: e.message };
  }
}

/**
 * 添加 Todo 到后端 API
 */
async function addTodoToAPI(todoItem) {
  try {
    const response = await fetch(`${API_BASE_URL}/api/user/todos`, {
      method: 'POST',
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify({
        text: todoItem.text,
        group_id: todoItem.source?.groupId || todoItem.source?.summaryId || '',
        group_title: todoItem.source?.pageTitle || '',
        group_url: todoItem.source?.pageUrl || ''
      })
    });
    
    if (response.status === 401) {
      handle401Error();
      return { ok: false, needsAuth: true };
    }
    
    const data = await response.json();
    return data;
  } catch (e) {
    console.error('[Todo] Add error:', e);
    return { ok: false, error: e.message };
  }
}

/**
 * 更新 Todo 状态到后端 API
 */
async function updateTodoToAPI(todoId, updates) {
  try {
    const response = await fetch(`${API_BASE_URL}/api/user/todos/${encodeURIComponent(todoId)}`, {
      method: 'PUT',
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify(updates)
    });
    
    if (response.status === 401) {
      handle401Error();
      return { ok: false, needsAuth: true };
    }
    
    const data = await response.json();
    return data;
  } catch (e) {
    console.error('[Todo] Update error:', e);
    return { ok: false, error: e.message };
  }
}

/**
 * 从后端 API 删除 Todo
 */
async function deleteTodoFromAPI(todoId) {
  try {
    const response = await fetch(`${API_BASE_URL}/api/user/todos/${encodeURIComponent(todoId)}`, {
      method: 'DELETE',
      credentials: 'include',
      headers: {
        'Accept': 'application/json'
      }
    });
    
    if (response.status === 401) {
      handle401Error();
      return { ok: false, needsAuth: true };
    }
    
    const data = await response.json();
    return data;
  } catch (e) {
    console.error('[Todo] Delete error:', e);
    return { ok: false, error: e.message };
  }
}

/**
 * 获取本地存储的 Todo
 */
function getLocalTodos() {
  return new Promise((resolve) => {
    chrome.storage.local.get([TODOS_LOCAL_KEY], (result) => {
      resolve(Array.isArray(result[TODOS_LOCAL_KEY]) ? result[TODOS_LOCAL_KEY] : []);
    });
  });
}

/**
 * 保存 Todo 到本地存储
 */
function saveLocalTodos(todoList) {
  chrome.storage.local.set({ [TODOS_LOCAL_KEY]: todoList });
}

/**
 * 获取待同步的本地 Todo
 */
function getPendingSyncTodos() {
  return new Promise((resolve) => {
    chrome.storage.local.get([TODOS_PENDING_SYNC_KEY], (result) => {
      resolve(result[TODOS_PENDING_SYNC_KEY] || []);
    });
  });
}

/**
 * 保存待同步的 Todo
 */
function savePendingSyncTodos(todoList) {
  chrome.storage.local.set({ [TODOS_PENDING_SYNC_KEY]: todoList });
}

/**
 * 清空待同步的 Todo
 */
function clearPendingSyncTodos() {
  chrome.storage.local.remove([TODOS_PENDING_SYNC_KEY]);
}

/**
 * 登录后同步本地 Todo 到服务器
 */
async function syncLocalTodosToServer() {
  if (todosSyncing) return;
  if (!authState.isLoggedIn) return;
  
  todosSyncing = true;
  
  try {
    const pendingTodos = await getPendingSyncTodos();
    
    if (pendingTodos.length === 0) {
      todosSyncing = false;
      return;
    }
    
    console.log('[Todo] Syncing', pendingTodos.length, 'local todos to server');
    
    let syncedCount = 0;
    for (const todo of pendingTodos) {
      const result = await addTodoToAPI(todo);
      if (result.ok || result.error?.includes('已存在')) {
        syncedCount++;
      }
    }
    
    // 清空待同步列表
    clearPendingSyncTodos();
    
    if (syncedCount > 0) {
      console.log('[Todo] Synced', syncedCount, 'todos to server');
    }
  } catch (e) {
    console.error('[Todo] Sync error:', e);
  } finally {
    todosSyncing = false;
  }
}

// 加载收藏
async function loadFavorites() {
  console.log('[Favorites] Loading favorites, isLoggedIn:', authState.isLoggedIn);
  
  if (authState.isLoggedIn) {
    // 已登录：从后端 API 加载
    const result = await fetchFavoritesFromAPI();
    console.log('[Favorites] API result:', result);
    
    if (result.needsAuth) {
      // 登录已过期，降级到本地存储
      console.log('[Favorites] Auth required, using local storage');
      favorites = await getLocalFavorites();
    } else if (result.error) {
      // API 错误，降级到本地存储
      console.warn('[Favorites] API error, using local storage:', result.error);
      favorites = await getLocalFavorites();
    } else {
      // 转换后端数据格式到本地格式 - 保存完整的 summary 内容
      console.log('[Favorites] Got', (result.favorites || []).length, 'favorites from API');
      favorites = (result.favorites || []).map(f => ({
        id: f.id || `fav-${f.news_id}`,
        summaryId: f.news_id,
        pageTitle: f.title,
        pageUrl: f.url,
        promptName: f.source_name || '',
        content: f.summary || '',  // 保存完整的总结内容
        createdAt: f.created_at ? f.created_at * 1000 : Date.now()
      }));
      
      // 同步到本地存储作为缓存
      saveLocalFavorites(favorites);
      
      // 检查是否有待同步的本地数据
      syncLocalFavoritesToServer();
    }
  } else {
    // 未登录：从本地存储加载
    console.log('[Favorites] Not logged in, using local storage');
    favorites = await getLocalFavorites();
  }
  
  console.log('[Favorites] Final favorites count:', favorites.length);
  updateFavoritesButton();
  renderFavorites();
}

// 保存收藏（内部使用，同步到本地和服务器）
function saveFavorites() {
  saveLocalFavorites(favorites);
  updateFavoritesButton();
}

// 更新收藏按钮状态
function updateFavoritesButton() {
  const favBtn = document.getElementById('sp-favorites-toggle');
  if (favBtn) {
    if (favorites.length > 0) {
      favBtn.classList.add('has-favorites');
      favBtn.textContent = `⭐`;
    } else {
      favBtn.classList.remove('has-favorites');
      favBtn.textContent = `⭐`;
    }
  }
}

// 切换收藏状态
async function toggleFavorite(msg, index) {
  const existingIndex = favorites.findIndex(f => f.summaryId === msg.id);
  const msgEl = document.querySelector(`.sp-message[data-id="${msg.id}"]`);
  const btn = msgEl ? msgEl.querySelector(`.sp-msg-favorite`) : null;

  if (existingIndex >= 0) {
    // 已收藏，取消收藏
    const favToRemove = favorites[existingIndex];
    favorites.splice(existingIndex, 1);
    
    // 更新 UI (不重绘)
    if (btn) {
      btn.classList.remove('is-favorited');
      btn.title = '收藏';
      btn.textContent = '☆';
    }
    
    saveFavorites();
    showToast('已取消收藏');
    
    // 如果已登录，同步到服务器
    if (authState.isLoggedIn) {
      const result = await removeFavoriteFromAPI(favToRemove.summaryId);
      if (!result.ok && !result.needsAuth) {
        console.warn('[Favorites] Failed to remove from server:', result.error);
      }
    }
  } else {
    // 未收藏，添加收藏 - 保存完整总结内容
    const newFavorite = {
      id: `fav-${Date.now()}-${Math.random().toString(36).slice(2)}`,
      summaryId: msg.id,
      pageTitle: msg.pageTitle,
      pageUrl: msg.pageUrl,
      promptName: msg.promptName,
      content: msg.content,  // 保存完整总结内容
      createdAt: Date.now()
    };
    
    favorites.push(newFavorite);
    
    // 更新 UI (不重绘)
    if (btn) {
      btn.classList.add('is-favorited');
      btn.title = '取消收藏';
      btn.textContent = '⭐';
    }
    
    saveFavorites();
    showToast('已收藏');
    
    // 如果已登录，同步到服务器
    if (authState.isLoggedIn) {
      const result = await addFavoriteToAPI(newFavorite);
      if (!result.ok && !result.needsAuth) {
        console.warn('[Favorites] Failed to add to server:', result.error);
      }
    } else {
      // 未登录，添加到待同步列表
      const pending = await getPendingSyncFavorites();
      pending.push(newFavorite);
      savePendingSyncFavorites(pending);
    }
  }
  
  // 不再调用 renderHistory() 避免闪烁
}

// 跳转到收藏对应的消息
function scrollToFavorite(summaryId) {
  // 关闭收藏面板
  closeFavoritesDrawer();

  // 找到对应的消息
  const msgEl = document.querySelector(`.sp-message[data-id="${summaryId}"]`);
  if (msgEl) {
    const titleEl = msgEl.querySelector('.sp-message-title');
    (titleEl || msgEl).scrollIntoView({ behavior: 'smooth', block: 'start' });
    // 添加高亮效果
    msgEl.style.transition = 'box-shadow 0.3s ease';
    msgEl.style.boxShadow = '0 0 0 3px #fbbf24, 0 4px 12px rgba(251, 191, 36, 0.3)';
    setTimeout(() => {
      msgEl.style.boxShadow = '';
    }, 2000);
    return;
  }

  showToast('该总结已被删除');
}

// 移除收藏
async function removeFavorite(favId) {
  const favToRemove = favorites.find(f => f.id === favId);
  favorites = favorites.filter(f => f.id !== favId);
  saveFavorites();
  renderFavorites();
  showToast('已取消收藏');
  
  // 如果已登录，同步到服务器
  if (authState.isLoggedIn && favToRemove) {
    const result = await removeFavoriteFromAPI(favToRemove.summaryId);
    if (!result.ok && !result.needsAuth) {
      console.warn('[Favorites] Failed to remove from server:', result.error);
    }
  }
}

// 清空所有收藏
async function clearFavorites() {
  if (favorites.length === 0) {
    showToast('没有收藏');
    return;
  }

  showConfirm('清空收藏', '确定要删除所有收藏吗？', async () => {
    const favsToRemove = [...favorites];
    favorites = [];
    saveFavorites();
    renderFavorites();
    showToast('收藏已清空');
    
    // 如果已登录，同步删除到服务器
    if (authState.isLoggedIn) {
      for (const fav of favsToRemove) {
        await removeFavoriteFromAPI(fav.summaryId);
      }
    }
    
    // 清空待同步列表
    clearPendingSyncFavorites();
  });
}

// 渲染收藏列表 - 完全照抄 hotnews 实现
function renderFavorites() {
  const listEl = document.getElementById('sp-favorites-list');
  if (!listEl) return;

  if (favorites.length === 0) {
    listEl.innerHTML = `
      <div class="favorites-empty">
        <div class="favorites-empty-icon">⭐</div>
        <div>暂无收藏</div>
        <div style="font-size:12px;margin-top:8px;color:#64748b;">
          点击消息上的 ☆ 收藏重要内容
        </div>
      </div>
    `;
    return;
  }

  // 按时间倒序
  const sorted = [...favorites].sort((a, b) => b.createdAt - a.createdAt);

  listEl.innerHTML = `
    <div class="favorites-list">
      ${sorted.map(f => {
        const dateStr = f.createdAt ? formatFavoriteDate(f.createdAt) : '';
        // 兼容旧数据：优先使用 content，其次使用 preview
        const summaryText = f.content || f.preview || '';
        const hasSummary = Boolean(summaryText);
        const summaryHtml = hasSummary ? renderMarkdownSimple(summaryText) : '';
        // 从 pageUrl 提取域名作为来源
        let sourceName = '';
        try {
          if (f.pageUrl) {
            const url = new URL(f.pageUrl);
            sourceName = url.hostname.replace(/^www\./, '');
          }
        } catch (e) {}
        
        // 完全照抄 hotnews 的 HTML 结构
        return `
          <div class="favorite-item" data-id="${f.id}">
            <a class="favorite-item-title" href="${escapeHtml(f.pageUrl || '#')}" target="_blank" rel="noopener noreferrer">
              ${escapeHtml(f.pageTitle || '无标题')}
            </a>
            <div class="favorite-item-meta">
              <span class="favorite-item-source">
                ${sourceName ? `<span>${escapeHtml(sourceName)}</span>` : ''}
                ${dateStr ? `<span>收藏于 ${dateStr}</span>` : ''}
              </span>
              <div class="favorite-item-actions">
                ${hasSummary ? `<button class="favorite-toggle-btn" data-id="${f.id}" title="收起/展开">收起</button>` : ''}
                <button class="favorite-remove-btn" data-id="${f.id}" title="取消收藏">删除</button>
              </div>
            </div>
            ${hasSummary ? `
              <div class="favorite-item-summary" id="summary-${f.id}">
                <div class="summary-content">${summaryHtml}</div>
              </div>
            ` : ''}
          </div>
        `;
      }).join('')}
    </div>
  `;

  // 绑定事件 - 删除按钮
  listEl.querySelectorAll('.favorite-remove-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      removeFavorite(btn.dataset.id);
    });
  });

  // 绑定事件 - 收起/展开按钮
  listEl.querySelectorAll('.favorite-toggle-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      toggleSummaryDisplay(btn.dataset.id, btn);
    });
  });
}

// 切换总结显示（收起/展开）
function toggleSummaryDisplay(favId, btn) {
  const summaryDiv = document.getElementById(`summary-${favId}`);
  if (!summaryDiv) return;
  
  const isCollapsed = summaryDiv.classList.contains('collapsed');
  summaryDiv.classList.toggle('collapsed');
  
  // 更新按钮文字
  if (btn) {
    btn.textContent = isCollapsed ? '收起' : '展开';
  }
}

// 格式化收藏日期
function formatFavoriteDate(ts) {
  if (!ts) return '';
  const d = new Date(ts);
  const MM = String(d.getMonth() + 1).padStart(2, '0');
  const DD = String(d.getDate()).padStart(2, '0');
  return `${MM}-${DD}`;
}

// 打开收藏面板
function openFavoritesDrawer() {
  const drawer = document.getElementById('sp-favorites-drawer');
  const overlay = document.getElementById('sp-favorites-overlay');
  if (drawer) {
    drawer.classList.add('is-open');
    drawer.setAttribute('aria-hidden', 'false');
  }
  if (overlay) overlay.style.display = 'block';
}

// 关闭收藏面板
function closeFavoritesDrawer() {
  const drawer = document.getElementById('sp-favorites-drawer');
  const overlay = document.getElementById('sp-favorites-overlay');
  if (drawer) {
    drawer.classList.remove('is-open');
    drawer.setAttribute('aria-hidden', 'true');
  }
  if (overlay) overlay.style.display = 'none';
}

// 切换收藏面板
function toggleFavoritesDrawer() {
  const drawer = document.getElementById('sp-favorites-drawer');
  if (drawer && drawer.classList.contains('is-open')) {
    closeFavoritesDrawer();
  } else {
    renderFavorites();
    openFavoritesDrawer();
  }
}

// 保存聊天历史
function saveHistory() {
  // 只保留最近 50 条
  const toSave = chatHistory.slice(-50);
  chrome.storage.local.set({ chatHistory: toSave });
}

// 渲染历史消息
function renderHistory() {
  if (chatHistory.length === 0 && !isProcessing) {
    elements.welcome.style.display = 'block';
    elements.messages.innerHTML = '';
    return;
  }

  elements.welcome.style.display = 'none';

  // 倒序显示，最新的在最上面
  const reversedHistory = [...chatHistory].reverse();
  elements.messages.innerHTML = reversedHistory.map((msg, index) => {
    // 使用原始索引（用于删除）
    const originalIndex = chatHistory.length - 1 - index;
    return createMessageHTML(msg, originalIndex);
  }).join('');

  // 绑定消息操作事件
  bindMessageActions();
}

// 创建消息 HTML
function createMessageHTML(msg, index) {
  const time = formatTime(msg.timestamp);
  const content = renderMarkdown(msg.content);
  const isFavorited = favorites.some(f => f.summaryId === msg.id);

  // 只在有页面URL时显示打开链接按钮
  const openLinkBtn = msg.pageUrl
    ? `<button class="sp-msg-open-link" title="打开原页面" data-url="${escapeHtml(msg.pageUrl)}">↗</button>`
    : '';

  return `
    <div class="sp-message" data-index="${index}" data-id="${msg.id}" data-url="${escapeHtml(msg.pageUrl || '')}">
      <div class="sp-message-header">
        <div class="sp-message-meta">
          <span class="sp-message-title" title="${escapeHtml(msg.pageTitle)}">${escapeHtml(msg.pageTitle)}</span>
          <span class="sp-message-prompt">${escapeHtml(msg.promptName)}</span>
        </div>
        <div class="sp-message-header-actions">
          <span class="sp-message-time">${time}</span>
          ${openLinkBtn}
        </div>
      </div>
      <div class="sp-message-content">${content}</div>
      <div class="sp-message-footer">
        <div class="sp-message-actions">
          <button class="sp-msg-action sp-msg-copy" title="复制" data-index="${index}">
            <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2">
              <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
              <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
            </svg>
          </button>
          <button class="sp-msg-action sp-msg-regenerate" title="重新生成" data-index="${index}">
            <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M23 4v6h-6"></path>
              <path d="M1 20v-6h6"></path>
              <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path>
            </svg>
          </button>
          <button class="sp-msg-action sp-msg-like" title="有帮助" data-index="${index}">
            <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"></path>
            </svg>
          </button>
          <button class="sp-msg-action sp-msg-dislike" title="没帮助" data-index="${index}">
            <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M10 15v4a3 3 0 0 0 3 3l4-9V2H5.72a2 2 0 0 0-2 1.7l-1.38 9a2 2 0 0 0 2 2.3zm7-13h2.67A2.31 2.31 0 0 1 22 4v7a2.31 2.31 0 0 1-2.33 2H17"></path>
            </svg>
          </button>
          <button class="sp-msg-action sp-msg-favorite ${isFavorited ? 'is-active' : ''}" title="${isFavorited ? '取消收藏' : '收藏'}" data-index="${index}">
            <svg viewBox="0 0 24 24" width="18" height="18" fill="${isFavorited ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2">
              <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
            </svg>
          </button>
          <button class="sp-msg-action sp-msg-share-link" title="复制分享链接" data-index="${index}">
            <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path>
              <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path>
            </svg>
          </button>
          <div class="sp-share-image-wrapper">
            <button class="sp-msg-action sp-msg-share-image" title="分享图片" data-index="${index}">
              <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                <circle cx="8.5" cy="8.5" r="1.5"></circle>
                <polyline points="21 15 16 10 5 21"></polyline>
              </svg>
            </button>
            <div class="sp-share-image-menu" data-index="${index}">
              <button class="sp-share-image-item sp-copy-image" data-index="${index}">
                <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2">
                  <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                  <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                </svg>
                <span>复制图片</span>
              </button>
              <button class="sp-share-image-item sp-download-image" data-index="${index}">
                <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                  <polyline points="7 10 12 15 17 10"></polyline>
                  <line x1="12" y1="15" x2="12" y2="3"></line>
                </svg>
                <span>下载图片</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  `;
}

// 绑定消息操作事件（使用 data-bound 标记防止重复绑定）
function bindMessageActions() {
  // 打开链接按钮
  document.querySelectorAll('.sp-msg-open-link:not([data-bound])').forEach(btn => {
    btn.dataset.bound = '1';
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const url = btn.dataset.url;
      if (url) {
        chrome.tabs.create({ url: url });
      }
    });
  });

  // 收藏按钮（新版 SVG 图标）
  document.querySelectorAll('.sp-msg-favorite:not([data-bound])').forEach(btn => {
    btn.dataset.bound = '1';
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const msgEl = btn.closest('.sp-message');
      const index = parseInt(btn.dataset.index || msgEl?.dataset.index);
      const msg = chatHistory[index];
      if (msg) {
        toggleFavorite(msg, index);
        // 更新按钮状态
        const isFavorited = favorites.some(f => f.summaryId === msg.id);
        btn.classList.toggle('is-active', isFavorited);
        btn.title = isFavorited ? '取消收藏' : '收藏';
        const svg = btn.querySelector('svg');
        if (svg) svg.setAttribute('fill', isFavorited ? 'currentColor' : 'none');
      }
    });
  });

  // 复制按钮
  document.querySelectorAll('.sp-msg-copy:not([data-bound])').forEach(btn => {
    btn.dataset.bound = '1';
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const msgEl = btn.closest('.sp-message');
      const index = parseInt(btn.dataset.index || msgEl?.dataset.index);
      const msg = chatHistory[index];
      if (msg) {
        navigator.clipboard.writeText(msg.content).then(() => {
          showToast('已复制到剪贴板');
          // 短暂高亮按钮
          btn.classList.add('is-active');
          setTimeout(() => btn.classList.remove('is-active'), 500);
        });
      }
    });
  });

  // 重新生成按钮
  document.querySelectorAll('.sp-msg-regenerate:not([data-bound])').forEach(btn => {
    btn.dataset.bound = '1';
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const msgEl = btn.closest('.sp-message');
      const url = msgEl?.dataset.url;
      console.log('[Regenerate] clicked, url:', url, 'isProcessing:', isProcessing);
      if (url && !isProcessing) {
        // 先跳转到该页面，再触发总结
        chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
          console.log('[Regenerate] current tab url:', tab?.url);
          if (tab?.url === url) {
            // 已经在该页面，直接重新总结
            console.log('[Regenerate] same page, calling handleSummarize');
            handleSummarize();
          } else {
            // 需要先跳转
            showToast('请先打开原页面再重新生成');
          }
        });
      }
    });
  });

  // 点赞按钮
  document.querySelectorAll('.sp-msg-like:not([data-bound])').forEach(btn => {
    btn.dataset.bound = '1';
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const msgEl = btn.closest('.sp-message');
      const dislikeBtn = msgEl?.querySelector('.sp-msg-dislike');
      
      btn.classList.toggle('is-active');
      if (dislikeBtn) dislikeBtn.classList.remove('is-active');
      
      if (btn.classList.contains('is-active')) {
        showToast('感谢反馈！');
        // TODO: 发送反馈到后端
      }
    });
  });

  // 点踩按钮
  document.querySelectorAll('.sp-msg-dislike:not([data-bound])').forEach(btn => {
    btn.dataset.bound = '1';
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const msgEl = btn.closest('.sp-message');
      const likeBtn = msgEl?.querySelector('.sp-msg-like');
      
      btn.classList.toggle('is-active');
      if (likeBtn) likeBtn.classList.remove('is-active');
      
      if (btn.classList.contains('is-active')) {
        showToast('感谢反馈，我们会继续改进');
        // TODO: 发送反馈到后端
      }
    });
  });

  // 分享链接按钮
  document.querySelectorAll('.sp-msg-share-link:not([data-bound])').forEach(btn => {
    btn.dataset.bound = '1';
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      const msgEl = btn.closest('.sp-message');
      const index = parseInt(btn.dataset.index || msgEl?.dataset.index);
      const msg = chatHistory[index];
      if (msg) {
        showToast('正在生成分享链接...');
        try {
          const resp = await fetch(`${API_BASE_URL}/api/share/create`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({
              title: msg.pageTitle,
              url: msg.pageUrl,
              summary: msg.content,
              article_type: msg.articleType || 'other'
            })
          });
          
          if (!resp.ok) {
            const errData = await resp.json().catch(() => ({}));
            throw new Error(errData.detail || `HTTP ${resp.status}`);
          }
          
          const data = await resp.json();
          if (data.ok && data.share_url) {
            await navigator.clipboard.writeText(data.share_url);
            showToast('分享链接已复制');
            btn.classList.add('is-active');
            setTimeout(() => btn.classList.remove('is-active'), 500);
          } else {
            showToast(data.detail || '创建分享失败');
          }
        } catch (err) {
          console.error('Share link error:', err);
          showToast(err.message || '创建分享失败');
        }
      }
    });
  });

  // 分享图片按钮 - 显示下拉菜单
  document.querySelectorAll('.sp-msg-share-image:not([data-bound])').forEach(btn => {
    btn.dataset.bound = '1';
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const wrapper = btn.closest('.sp-share-image-wrapper');
      const menu = wrapper?.querySelector('.sp-share-image-menu');
      if (menu) {
        // 关闭其他打开的菜单
        document.querySelectorAll('.sp-share-image-menu.is-open').forEach(m => {
          if (m !== menu) m.classList.remove('is-open');
        });
        menu.classList.toggle('is-open');
      }
    });
  });

  // 复制图片
  document.querySelectorAll('.sp-copy-image:not([data-bound])').forEach(btn => {
    btn.dataset.bound = '1';
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      const msgEl = btn.closest('.sp-message');
      const index = parseInt(btn.dataset.index || msgEl?.dataset.index);
      const msg = chatHistory[index];
      if (msg) {
        const canvas = await generateShareCanvas(msg);
        if (canvas) {
          try {
            const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/png'));
            await navigator.clipboard.write([
              new ClipboardItem({ 'image/png': blob })
            ]);
            showToast('图片已复制到剪贴板');
          } catch (err) {
            console.error('复制失败:', err);
            showToast('复制失败，请尝试下载');
          }
        }
      }
      btn.closest('.sp-share-image-menu')?.classList.remove('is-open');
    });
  });

  // 下载图片
  document.querySelectorAll('.sp-download-image:not([data-bound])').forEach(btn => {
    btn.dataset.bound = '1';
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      const msgEl = btn.closest('.sp-message');
      const index = parseInt(btn.dataset.index || msgEl?.dataset.index);
      const msg = chatHistory[index];
      if (msg) {
        const canvas = await generateShareCanvas(msg);
        if (canvas) {
          canvas.toBlob((blob) => {
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `uihash-${Date.now()}.png`;
            a.click();
            URL.revokeObjectURL(url);
            showToast('图片已保存');
          }, 'image/png');
        }
      }
      btn.closest('.sp-share-image-menu')?.classList.remove('is-open');
    });
  });

  // 点击其他地方关闭分享图片菜单
  document.addEventListener('click', (e) => {
    if (!e.target.closest('.sp-share-image-wrapper')) {
      document.querySelectorAll('.sp-share-image-menu.is-open').forEach(m => {
        m.classList.remove('is-open');
      });
    }
  });
}

// 删除单条消息
function deleteMessage(index) {
  chatHistory.splice(index, 1);
  saveHistory();
  renderHistory();
}

// 清空历史
function handleClearHistory() {
  if (chatHistory.length === 0) {
    showToast('没有历史记录');
    return;
  }

  showConfirm('清空历史', '确定要删除所有历史记录吗？', () => {
    chatHistory = [];
    saveHistory();
    renderHistory();
    showToast('历史已清空');
  });
}

// ============ 总结功能 ============

// 开始总结
// 取消当前任务
function handleCancel() {
  if (!isProcessing) return;

  requestAborted = true;
  chrome.runtime.sendMessage({ type: 'CANCEL_SUMMARIZE' });

  // 重置状态
  isProcessing = false;
  elements.summarizeBtn.disabled = false;
  elements.generating.style.display = 'none';
  elements.messages.style.display = '';  // 恢复历史消息显示

  // 如果有已生成的内容，保存到历史
  if (currentGeneratingContent && currentGeneratingContent.length > 50) {
    const pageInfo = window._currentPageInfo || {};
    // 移除临时的"正在生成总结"提示
    let cancelledContent = currentGeneratingContent.replace(/🤖 正在生成总结\.\.\.\n\n/g, '');
    const newMessage = {
      id: Date.now().toString(),
      timestamp: Date.now(),
      pageTitle: pageInfo.title || '未知页面',
      pageUrl: pageInfo.url || '',
      promptName: pageInfo.promptName + ' (已中断)',
      promptId: pageInfo.promptId || '',
      content: cancelledContent + '\n\n---\n*（用户已中断生成）*'
    };
    chatHistory.push(newMessage);
    saveHistory();
    renderHistory();
  }

  showToast('已停止生成');
}

// ============ 后端 API 总结相关 ============

// 文章类型图标映射
const ARTICLE_TYPE_ICONS = {
  'news': '📰',
  'policy': '⚠️',
  'business': '📊',
  'tutorial': '✅',
  'research': '📚',
  'product': '🚀',
  'opinion': '💭',
  'interview': '💬',
  'listicle': '📑',
  'lifestyle': '✅',
  'general': '📝',
  'tech-tutorial': '✅',
  'trend': '📊',
  'other': '📝'
};

// 当前总结状态
let currentSummaryState = {
  articleType: null,
  articleTypeName: null,
  usageRemaining: null,
  usageQuota: null,
  newsId: null
};

/**
 * 从页面提取内容（通过 content script）
 */
async function extractPageContent(tabId) {
  return new Promise((resolve) => {
    chrome.tabs.sendMessage(tabId, { type: 'EXTRACT_CONTENT' }, (response) => {
      const err = chrome.runtime.lastError;
      if (err) {
        console.warn('[Summary] Content extraction failed:', err.message);
        resolve({ content: '', title: '', error: err.message });
        return;
      }
      resolve(response || { content: '', title: '' });
    });
  });
}

/**
 * 检查是否为敏感页面（不应上传内容）
 */
function isSensitivePage(url) {
  const SENSITIVE_PATTERNS = [
    /mail\./i,
    /bank\./i,
    /pay\./i,
    /login\./i,
    /account\./i,
    /password/i,
    /alipay\.com/i,
    /weixin\.qq\.com\/cgi-bin/i,
    /console\./i,
    /admin\./i
  ];
  return SENSITIVE_PATTERNS.some(pattern => pattern.test(url));
}

/**
 * 检查是否为不支持的页面类型（本地文件、浏览器内部页面等）
 */
function isUnsupportedPage(url) {
  if (!url) return true;
  // 本地文件
  if (url.startsWith('file://')) return true;
  // 浏览器内部页面
  if (url.startsWith('chrome://')) return true;
  if (url.startsWith('chrome-extension://')) return true;
  if (url.startsWith('edge://')) return true;
  if (url.startsWith('about:')) return true;
  // 新标签页
  if (url === 'chrome://newtab/' || url === 'edge://newtab/') return true;
  return false;
}

/**
 * 更新深度分析按钮状态（根据当前页面是否支持）
 */
async function updateSummarizeButtonState() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const unsupported = !tab || isUnsupportedPage(tab.url);
    
    if (elements.summarizeBtn) {
      elements.summarizeBtn.disabled = unsupported;
      if (unsupported) {
        elements.summarizeBtn.title = '暂不支持此类型页面';
        elements.summarizeBtn.classList.add('sp-btn-disabled');
      } else {
        elements.summarizeBtn.title = '深度分析当前页面';
        elements.summarizeBtn.classList.remove('sp-btn-disabled');
      }
    }
  } catch (e) {
    console.warn('[Summary] Failed to update button state:', e);
  }
}

/**
 * 从 URL 提取来源名称
 */
function extractSourceName(url) {
  try {
    const hostname = new URL(url).hostname;
    const domain = hostname.replace(/^www\./, '');
    const sourceMap = {
      '36kr.com': '36氪',
      'zhihu.com': '知乎',
      'weixin.qq.com': '微信公众号',
      'mp.weixin.qq.com': '微信公众号',
      'juejin.cn': '掘金',
      'github.com': 'GitHub',
      'medium.com': 'Medium',
      'twitter.com': 'Twitter',
      'x.com': 'X',
      'weibo.com': '微博',
      'bilibili.com': 'B站',
      'youtube.com': 'YouTube',
      'news.ycombinator.com': 'Hacker News',
      'reddit.com': 'Reddit'
    };
    return sourceMap[domain] || domain;
  } catch {
    return '';
  }
}

/**
 * 格式化次数显示
 */
function formatUsageDisplay(remaining, quota) {
  if (remaining === null || remaining === undefined) return '';
  return `${remaining}/${quota || 50}`;
}

/**
 * 处理 401 未授权错误
 */
function handle401Error() {
  authState.isLoggedIn = false;
  authState.user = null;
  showLoginView();
  showToast('登录已过期，请重新登录');
}

/**
 * 处理 403 配额不足错误
 */
function handle403Error() {
  elements.genContent.innerHTML = `
    <div class="sp-summary-error">
      <div class="sp-summary-error-icon">📊</div>
      <div class="sp-summary-error-title">本月次数已用完</div>
      <div class="sp-summary-error-text">免费用户每月可使用 50 次，订阅会员可获得更多次数</div>
      <div class="sp-summary-error-actions">
        <a href="${API_BASE_URL}/user/payment" target="_blank" class="sp-summary-recharge-btn">
          💳 去充值
        </a>
      </div>
    </div>
  `;
}

// 开始总结 - 调用后端 API
async function handleSummarize() {
  // 调试：在页面上显示日志
  const debugLog = (msg) => {
    console.log(msg);
    const statusEl = document.querySelector('.sp-status-text');
    if (statusEl) statusEl.textContent = msg;
  };
  
  debugLog('[Summary] handleSummarize called');
  console.log('[Summary] handleSummarize called, isProcessing:', isProcessing, 'isLoggedIn:', authState.isLoggedIn);
  
  if (isProcessing) {
    console.log('[Summary] Already processing, skipping');
    return;
  }

  // 检查登录状态
  if (!authState.isLoggedIn) {
    console.log('[Summary] Not logged in, showing login view');
    showLoginView();
    showToast('请先登录后再使用总结功能');
    return;
  }

  isProcessing = true;
  requestAborted = false;
  elements.summarizeBtn.disabled = true;
  currentGeneratingContent = '';
  currentSummaryState = {
    articleType: null,
    articleTypeName: null,
    usageRemaining: null,
    usageQuota: null,
    newsId: null
  };

  // 清空历史记录（每次总结只显示当前结果，历史已进入收藏）
  chatHistory = [];
  elements.messages.innerHTML = '';

  try {
    // 获取当前标签页信息
    console.log('[Summary] Getting current tab...');
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (!tab) {
      throw new Error('无法获取当前标签页');
    }
    console.log('[Summary] Got tab:', tab.url, tab.title);

    // 检测不支持的页面类型
    if (isUnsupportedPage(tab.url)) {
      isProcessing = false;
      elements.summarizeBtn.disabled = false;
      showToast('暂不支持此类型页面');
      return;
    }

    // 显示生成中的消息
    elements.welcome.style.display = 'none';
    elements.messages.style.display = 'none';
    elements.generating.style.display = 'block';
    elements.genTitle.textContent = tab.title || '当前页面';
    elements.genPrompt.textContent = '智能分析';
    streamPreEl = null;
    streamRenderScheduled = false;

    // 默认自动收藏（跟 hotnews 一样）
    isGeneratingFavorited = true;

    // 直接在消息列表中创建新消息（流式输出直接在最终位置）
    elements.welcome.style.display = 'none';
    elements.generating.style.display = 'none';
    elements.messages.style.display = '';
    
    // 创建流式消息容器
    const streamMsgId = `stream-${Date.now()}`;
    const streamMsgHtml = `
      <div class="sp-message sp-message-streaming" data-id="${streamMsgId}" data-url="${escapeHtml(tab.url || '')}">
        <div class="sp-message-header">
          <div class="sp-message-meta">
            <span class="sp-message-title" title="${escapeHtml(tab.title || '当前页面')}">${escapeHtml(tab.title || '当前页面')}</span>
            <span class="sp-message-prompt">智能分析</span>
          </div>
          <div class="sp-message-header-actions">
            <span class="sp-message-time">刚刚</span>
            <button class="sp-cancel-btn" title="停止">■ 停止</button>
          </div>
        </div>
        <div class="sp-message-content">
          <div class="sp-loading-hint">
            <span class="sp-loading-icon">✨</span>
            <span class="sp-loading-text">正在分析内容</span>
            <span class="sp-loading-dots"><span>.</span><span>.</span><span>.</span></span>
          </div>
        </div>
        <div class="sp-message-footer" style="display: none;">
          <div class="sp-message-actions">
            <button class="sp-msg-action sp-msg-copy" title="复制">
              <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
              </svg>
            </button>
            <button class="sp-msg-action sp-msg-regenerate" title="重新生成">
              <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M23 4v6h-6"></path>
                <path d="M1 20v-6h6"></path>
                <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path>
              </svg>
            </button>
            <button class="sp-msg-action sp-msg-like" title="有帮助">
              <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"></path>
              </svg>
            </button>
            <button class="sp-msg-action sp-msg-dislike" title="没帮助">
              <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M10 15v4a3 3 0 0 0 3 3l4-9V2H5.72a2 2 0 0 0-2 1.7l-1.38 9a2 2 0 0 0 2 2.3zm7-13h2.67A2.31 2.31 0 0 1 22 4v7a2.31 2.31 0 0 1-2.33 2H17"></path>
              </svg>
            </button>
            <button class="sp-msg-action sp-msg-favorite is-active" title="取消收藏" data-index="0">
              <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor" stroke="currentColor" stroke-width="2">
                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
              </svg>
            </button>
            <button class="sp-msg-action sp-msg-share-link" title="复制分享链接" data-index="0">
              <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path>
                <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path>
              </svg>
            </button>
            <div class="sp-share-image-wrapper">
              <button class="sp-msg-action sp-msg-share-image" title="分享图片" data-index="0">
                <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2">
                  <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                  <circle cx="8.5" cy="8.5" r="1.5"></circle>
                  <polyline points="21 15 16 10 5 21"></polyline>
                </svg>
              </button>
              <div class="sp-share-image-menu" data-index="0">
                <button class="sp-share-image-item sp-copy-image" data-index="0">
                  <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2">
                    <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                    <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                  </svg>
                  <span>复制图片</span>
                </button>
                <button class="sp-share-image-item sp-download-image" data-index="0">
                  <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                    <polyline points="7 10 12 15 17 10"></polyline>
                    <line x1="12" y1="15" x2="12" y2="3"></line>
                  </svg>
                  <span>下载图片</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
    
    // 插入到消息列表最前面
    elements.messages.insertAdjacentHTML('afterbegin', streamMsgHtml);
    
    // 获取内容容器
    const streamMsg = elements.messages.querySelector(`[data-id="${streamMsgId}"]`);
    const streamContent = streamMsg?.querySelector('.sp-message-content');
    streamPreEl = streamContent;
    currentGeneratingContent = '';
    
    // 绑定停止按钮
    const cancelBtn = streamMsg?.querySelector('.sp-cancel-btn');
    if (cancelBtn) {
      cancelBtn.addEventListener('click', handleCancel);
    }
    
    // 绑定收藏按钮
    const favBtn = streamMsg?.querySelector('.sp-msg-favorite');
    if (favBtn) {
      favBtn.addEventListener('click', () => {
        isGeneratingFavorited = !isGeneratingFavorited;
        favBtn.textContent = isGeneratingFavorited ? '⭐' : '☆';
        favBtn.classList.toggle('is-favorited', isGeneratingFavorited);
      });
    }

    requestAnimationFrame(() => {
      streamMsg?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });

    // 存储当前页面信息
    window._currentPageInfo = {
      title: tab.title,
      url: tab.url,
      promptName: '智能分析',
      promptId: 'backend-api'
    };

    // 提取页面内容（用于内容反哺）
    let pageContent = '';
    if (!isSensitivePage(tab.url)) {
      try {
        console.log('[Summary] Extracting page content...');
        const extracted = await extractPageContent(tab.id);
        pageContent = extracted.content || '';
        console.log('[Summary] Extracted content length:', pageContent.length);
        
        // 检测是否为列表页/首页（内容碎片化，没有连贯段落）
        if (pageContent && pageContent.length > 100 && pageContent.length < 2000) {
          const lines = pageContent.split('\n').filter(l => l.trim());
          const avgLineLength = lines.reduce((sum, l) => sum + l.length, 0) / Math.max(lines.length, 1);
          const longParagraphs = lines.filter(l => l.length > 100).length;
          
          // 列表页特征：行数多但平均长度短，且没有长段落
          const isListPage = lines.length > 20 && avgLineLength < 50 && longParagraphs < 3;
          
          if (isListPage) {
            console.log('[Summary] Detected list page, showing warning');
            isProcessing = false;
            elements.summarizeBtn.disabled = false;
            
            // 更新消息显示为提示
            const contentEl = streamMsg?.querySelector('.sp-message-content');
            if (contentEl) {
              contentEl.innerHTML = `
                <div class="sp-summary-error">
                  <div class="sp-summary-error-icon">📋</div>
                  <div class="sp-summary-error-text">当前页面似乎是列表页或首页，内容较为分散</div>
                  <div class="sp-summary-error-hint">建议打开具体文章后再进行总结，效果更好</div>
                </div>
              `;
            }
            // 隐藏停止按钮和底部操作
            const cancelBtn = streamMsg?.querySelector('.sp-cancel-btn');
            if (cancelBtn) cancelBtn.style.display = 'none';
            streamMsg?.classList.remove('sp-message-streaming');
            return;
          }
        }
      } catch (e) {
        console.warn('[Summary] Content extraction failed:', e);
      }
    } else {
      console.log('[Summary] Skipping content extraction for sensitive page');
    }

    // 构建请求体
    const requestBody = {
      url: tab.url,
      title: tab.title || '',
      source_name: extractSourceName(tab.url),
      contribute: true
    };

    // 如果有提取到内容，添加到请求中（降低阈值，确保内容被发送）
    if (pageContent && pageContent.length > 50) {
      requestBody.content = pageContent;
      console.log('[Summary] Including page content in request');
    }

    console.log('[Summary] Calling API with:', requestBody.url);
    console.log('[Summary] Request body:', JSON.stringify(requestBody).substring(0, 500));

    // 调用后端 SSE 流式接口
    const apiUrl = `${API_BASE_URL}/api/summary/stream`;
    console.log('[Summary] Starting fetch to:', apiUrl);
    
    // 检查是否跨域
    const isCrossOrigin = !apiUrl.startsWith(window.location.origin);
    console.log('[Summary] Is cross-origin:', isCrossOrigin, 'origin:', window.location.origin);
    
    const response = await fetch(apiUrl, {
      method: 'POST',
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'text/event-stream',
        'Cache-Control': 'no-cache, no-store',
        'X-Accel-Buffering': 'no'  // 告诉代理不要缓冲
      },
      body: JSON.stringify(requestBody),
      cache: 'no-store'
    });

    console.log('[Summary] Fetch completed, response status:', response.status);
    console.log('[Summary] Response headers:', [...response.headers.entries()]);
    console.log('[Summary] Response body type:', response.body ? 'ReadableStream' : 'null');
    console.log('[Summary] Content-Type:', response.headers.get('content-type'));
    
    // 检查 Content-Type 是否正确
    const contentType = response.headers.get('content-type') || '';
    if (!contentType.includes('text/event-stream')) {
      console.warn('[Summary] Warning: Content-Type is not text/event-stream:', contentType);
    }

    // 处理错误响应
    if (!response.ok) {
      if (response.status === 401) {
        handle401Error();
        throw new Error('登录已过期');
      }
      if (response.status === 403) {
        handle403Error();
        throw new Error('Token 配额不足');
      }
      const errData = await response.json().catch(() => ({}));
      throw new Error(errData.detail || errData.message || `请求失败 (${response.status})`);
    }

    // 处理 SSE 流
    await processSSEStream(response, tab);

  } catch (error) {
    console.error('[Summary] Error:', error);
    
    // 如果不是已处理的错误，显示通用错误
    if (error.message !== '登录已过期' && error.message !== 'Token 配额不足') {
      elements.genContent.innerHTML = `
        <div class="sp-summary-error">
          <div class="sp-summary-error-icon">❌</div>
          <div class="sp-summary-error-title">总结失败</div>
          <div class="sp-summary-error-text">${escapeHtml(error.message)}</div>
          <div class="sp-summary-error-actions">
            <button class="sp-summary-retry-btn" onclick="handleSummarize()">🔄 重试</button>
          </div>
        </div>
      `;
    }
    
    isProcessing = false;
    elements.summarizeBtn.disabled = false;
  }
}

/**
 * 处理 SSE 流式响应
 */
async function processSSEStream(response, tab) {
  console.log('[SSE] processSSEStream called');
  console.log('[SSE] Response body:', response.body);
  
  // 调试：在骨架屏状态文字中显示进度
  const debugStatus = (msg) => {
    console.log('[SSE-DEBUG]', msg);
    const statusEl = document.querySelector('.sp-status-text');
    if (statusEl) statusEl.textContent = msg;
  };
  
  debugStatus('开始读取流...');
  
  const reader = response.body.getReader();
  console.log('[SSE] Got reader:', reader);
  
  const decoder = new TextDecoder();
  let buffer = '';
  let isStreaming = false;
  let chunkCount = 0;

  const ensureStreamPre = () => {
    if (streamPreEl) return streamPreEl;
    streamPreEl = document.getElementById('sp-stream-rendered');
    if (streamPreEl) {
      const wrapper = document.getElementById('sp-stream-wrapper');
      const skeleton = document.getElementById('sp-skeleton');
      console.log('[Stream] Found stream element, hiding skeleton');
      if (wrapper) wrapper.style.display = 'block';
      if (skeleton) skeleton.style.display = 'none';
      return streamPreEl;
    }
    console.log('[Stream] Stream element not found, creating...');
    // 如果元素不存在，创建它
    const wrapper = document.createElement('div');
    wrapper.id = 'sp-stream-wrapper';
    wrapper.className = 'sp-stream-content';
    wrapper.style.display = 'block';
    const rendered = document.createElement('div');
    rendered.id = 'sp-stream-rendered';
    rendered.className = 'sp-summary-content sp-stream-rendered';
    wrapper.appendChild(rendered);
    elements.genContent.appendChild(wrapper);
    // 隐藏骨架屏
    const skeleton = document.getElementById('sp-skeleton');
    if (skeleton) skeleton.style.display = 'none';
    streamPreEl = rendered;
    return streamPreEl;
  };

  const scheduleStreamRender = () => {
    if (streamRenderScheduled) return;
    streamRenderScheduled = true;
    requestAnimationFrame(() => {
      streamRenderScheduled = false;
      const el = ensureStreamPre();
      if (el) {
        // Strip incomplete tags block during streaming (hide [TAGSSTART] etc.)
        let displayContent = currentGeneratingContent;
        displayContent = displayContent.replace(/\[TAGS_?START\][\s\S]*$/gi, '');
        console.log('[Stream] Rendering content:', displayContent.length, 'chars');
        el.innerHTML = renderMarkdown(displayContent) + '<span class="sp-summary-cursor">▌</span>';
        el.scrollIntoView({ behavior: 'smooth', block: 'end' });
      } else {
        console.log('[Stream] No element to render to');
      }
    });
  };

  try {
    console.log('[SSE] Starting read loop...');
    debugStatus('进入读取循环...');
    
    while (true) {
      console.log('[SSE] Calling reader.read()...');
      debugStatus(`等待数据... (已收到 ${chunkCount} 块)`);
      
      const { done, value } = await reader.read();
      chunkCount++;
      
      console.log('[SSE] Read result - done:', done, 'value length:', value?.length);
      debugStatus(`收到数据块 #${chunkCount}, done=${done}, size=${value?.length || 0}`);
      
      if (done) {
        console.log('[SSE] Stream ended');
        debugStatus('流结束');
        break;
      }

      const chunk = decoder.decode(value, { stream: true });
      console.log('[SSE] Raw chunk:', chunk.substring(0, 200));
      
      // 直接处理每一行（和 hotnews 网站一样，不使用 buffer）
      const lines = chunk.split('\n');

      for (const line of lines) {
        if (!line.startsWith('data: ')) continue;

        try {
          const data = JSON.parse(line.slice(6));
          console.log('[SSE] Parsed event type:', data.type);
          debugStatus(`事件: ${data.type}`);

          switch (data.type) {
            case 'status':
              // 更新加载提示文字
              const loadingText = elements.messages.querySelector('.sp-message-streaming .sp-loading-text');
              if (loadingText) {
                loadingText.textContent = data.message || '正在分析内容';
              }
              break;

            case 'type':
              currentSummaryState.articleType = data.article_type;
              currentSummaryState.articleTypeName = data.article_type_name;
              if (elements.genPrompt) {
                elements.genPrompt.textContent = data.article_type_name || '智能分析';
              }
              break;

            case 'chunk':
              console.log('[Stream] Received chunk:', data.content?.length, 'chars');
              currentGeneratingContent += data.content;
              // 直接更新消息内容
              const streamingMsg = elements.messages.querySelector('.sp-message-streaming');
              const contentEl = streamingMsg?.querySelector('.sp-message-content');
              if (contentEl) {
                let displayContent = currentGeneratingContent;
                displayContent = displayContent.replace(/\[TAGS_?START\][\s\S]*$/gi, '');
                contentEl.innerHTML = renderMarkdown(displayContent) + '<span class="sp-summary-cursor">▌</span>';
              }
              break;

            case 'cached':
              currentGeneratingContent = stripTagsBlock(data.summary || '');
              currentSummaryState.articleType = data.article_type;
              currentSummaryState.articleTypeName = data.article_type_name;
              currentSummaryState.usageRemaining = data.usage_remaining;
              currentSummaryState.usageQuota = data.usage_quota;
              currentSummaryState.newsId = data.news_id;
              
              // 直接更新消息内容
              const cachedMsg = elements.messages.querySelector('.sp-message-streaming');
              const cachedContentEl = cachedMsg?.querySelector('.sp-message-content');
              if (cachedContentEl) {
                cachedContentEl.innerHTML = renderMarkdown(currentGeneratingContent);
              }
              
              finishSummary(tab, true);
              return;

            case 'done':
              currentSummaryState.usageRemaining = data.usage_remaining;
              currentSummaryState.usageQuota = data.usage_quota;
              currentSummaryState.newsId = data.news_id;
              
              // Strip tags block
              currentGeneratingContent = stripTagsBlock(currentGeneratingContent);
              
              // 移除光标
              const doneMsg = elements.messages.querySelector('.sp-message-streaming');
              const cursor = doneMsg?.querySelector('.sp-summary-cursor');
              if (cursor) cursor.remove();
              
              finishSummary(tab, false);
              return;

            case 'error':
              throw new Error(data.message);
          }
        } catch (parseErr) {
          if (parseErr.message && !parseErr.message.includes('JSON')) {
            throw parseErr;
          }
        }
      }
    }

    if (isStreaming && currentGeneratingContent) {
      finishSummary(tab, false);
    }

  } catch (error) {
    throw error;
  }
}

/**
 * 完成总结处理
 */
function finishSummary(tab, isCached) {
  const pageInfo = window._currentPageInfo || {};
  
  let displayPromptName = '智能分析';
  if (currentSummaryState.articleTypeName) {
    displayPromptName = currentSummaryState.articleTypeName;
  }

  const newMessage = {
    id: Date.now().toString(),
    timestamp: Date.now(),
    pageTitle: tab.title || pageInfo.title || '未知页面',
    pageUrl: tab.url || pageInfo.url || '',
    promptName: displayPromptName,
    promptId: 'backend-api',
    articleType: currentSummaryState.articleType || '',
    content: currentGeneratingContent,
    usageRemaining: currentSummaryState.usageRemaining,
    usageQuota: currentSummaryState.usageQuota,
    newsId: currentSummaryState.newsId
  };

  chatHistory.push(newMessage);
  saveHistory();

  if (isGeneratingFavorited) {
    favorites.push({
      id: `fav-${Date.now()}-${Math.random().toString(36).slice(2)}`,
      summaryId: newMessage.id,
      pageTitle: newMessage.pageTitle,
      pageUrl: newMessage.pageUrl,
      promptName: newMessage.promptName,
      content: newMessage.content,
      createdAt: Date.now()
    });
    saveFavorites();
    showToast('总结已保存并收藏');
  }

  // 更新流式消息为最终状态（不重新渲染）
  const streamingMsg = elements.messages.querySelector('.sp-message-streaming');
  if (streamingMsg) {
    streamingMsg.classList.remove('sp-message-streaming');
    streamingMsg.dataset.id = newMessage.id;
    streamingMsg.dataset.index = chatHistory.length - 1;
    
    // 更新标题和类型
    const titleEl = streamingMsg.querySelector('.sp-message-title');
    const promptEl = streamingMsg.querySelector('.sp-message-prompt');
    if (titleEl) titleEl.textContent = newMessage.pageTitle;
    if (promptEl) promptEl.textContent = displayPromptName;
    
    // 更新 header 操作区（移除停止按钮，添加打开链接）
    const headerActionsEl = streamingMsg.querySelector('.sp-message-header-actions');
    if (headerActionsEl) {
      const openLinkBtn = newMessage.pageUrl
        ? `<button class="sp-msg-open-link" title="打开原页面" data-url="${escapeHtml(newMessage.pageUrl)}">↗</button>`
        : '';
      
      headerActionsEl.innerHTML = `
        <span class="sp-message-time">${formatTime(newMessage.timestamp)}</span>
        ${openLinkBtn}
      `;
    }
    
    // 显示底部操作栏
    const footerEl = streamingMsg.querySelector('.sp-message-footer');
    if (footerEl) {
      footerEl.style.display = '';
      // 更新 data-index
      footerEl.querySelectorAll('[data-index]').forEach(btn => {
        btn.dataset.index = chatHistory.length - 1;
      });
      // 更新收藏状态
      const favBtn = footerEl.querySelector('.sp-msg-favorite');
      if (favBtn && isGeneratingFavorited) {
        favBtn.classList.add('is-active');
        favBtn.title = '取消收藏';
        favBtn.querySelector('svg').setAttribute('fill', 'currentColor');
      }
    }
    
    // 移除光标
    const cursor = streamingMsg.querySelector('.sp-summary-cursor');
    if (cursor) cursor.remove();
  }
  
  // 重新绑定事件
  bindMessageActions();

  // 更新用户使用次数信息
  if (currentSummaryState.usageRemaining !== null && authState.user) {
    authState.user.usage_remaining = currentSummaryState.usageRemaining;
    authState.user.usage_quota = currentSummaryState.usageQuota;
  }

  isProcessing = false;
  elements.summarizeBtn.disabled = false;
}

/**
 * 显示总结底部信息（文章类型 + 剩余次数）
 */
function showSummaryFooter() {
  const wrapper = document.getElementById('sp-stream-wrapper');
  if (!wrapper) return;

  const existingFooter = wrapper.querySelector('.sp-summary-footer');
  if (existingFooter) existingFooter.remove();

  const footer = document.createElement('div');
  footer.className = 'sp-summary-footer';

  let footerHtml = '<div class="sp-summary-footer-left">';

  if (currentSummaryState.articleTypeName) {
    const icon = ARTICLE_TYPE_ICONS[currentSummaryState.articleType] || '📝';
    footerHtml += `
      <span class="sp-summary-type-tag">
        ${icon} ${escapeHtml(currentSummaryState.articleTypeName)}
      </span>
    `;
  }

  // 显示剩余次数
  if (currentSummaryState.usageRemaining !== null && currentSummaryState.usageRemaining !== undefined) {
    const isLow = currentSummaryState.usageRemaining <= 5;
    footerHtml += `
      <span class="sp-summary-balance-tag ${isLow ? 'low-balance' : ''}">
        📊 剩余 ${formatUsageDisplay(currentSummaryState.usageRemaining, currentSummaryState.usageQuota)} 次
        ${isLow ? `<a href="${API_BASE_URL}/user/payment" target="_blank" class="sp-summary-recharge-link">升级</a>` : ''}
      </span>
    `;
  }

  footerHtml += '</div>';
  footer.innerHTML = footerHtml;
  wrapper.appendChild(footer);
}

// 处理生成时的收藏点击
let isGeneratingFavorited = false;

function handleGenFavorite() {
  isGeneratingFavorited = !isGeneratingFavorited;
  const btn = elements.genFavoriteBtn;
  if (!btn) return;

  if (isGeneratingFavorited) {
    btn.textContent = '⭐';
    btn.classList.add('is-favorited');
    btn.title = '取消收藏';
    showToast('将在生成完成后自动收藏');
  } else {
    btn.textContent = '☆';
    btn.classList.remove('is-favorited');
    btn.title = '收藏';
  }
}

// 处理来自 background 的消息
function handleMessage(message) {
  // 如果请求已被中止，忽略后续消息
  if (requestAborted && message.type !== 'SUMMARIZE_DONE' && message.type !== 'SUMMARIZE_ERROR') {
    if (message.type === 'SUMMARIZE_CHUNK') {
      // 仍然更新内容，以便取消时可以保存已生成的部分
      currentGeneratingContent = message.fullContent;
    }
    return;
  }

  const ensureStreamPre = () => {
    if (streamPreEl) return streamPreEl;
    // 尝试在现有结构中找到渲染容器
    streamPreEl = document.getElementById('sp-stream-rendered');
    if (streamPreEl) {
      // 显示流式内容区域，隐藏骨架屏
      const wrapper = document.getElementById('sp-stream-wrapper');
      const skeleton = document.getElementById('sp-skeleton');
      if (wrapper) wrapper.style.display = 'block';
      if (skeleton) skeleton.style.display = 'none';
      return streamPreEl;
    }
    // 如果没有，创建新的渲染容器
    const wrapper = document.createElement('div');
    wrapper.id = 'sp-stream-wrapper';
    wrapper.className = 'sp-stream-content';
    const rendered = document.createElement('div');
    rendered.id = 'sp-stream-rendered';
    rendered.className = 'sp-message-content sp-stream-rendered';
    wrapper.appendChild(rendered);
    elements.genContent.appendChild(wrapper);
    // 隐藏骨架屏
    const skeleton = document.getElementById('sp-skeleton');
    if (skeleton) skeleton.style.display = 'none';
    streamPreEl = rendered;
    return streamPreEl;
  };

  const scheduleStreamRender = () => {
    if (streamRenderScheduled) return;
    streamRenderScheduled = true;
    requestAnimationFrame(() => {
      streamRenderScheduled = false;
      const el = ensureStreamPre();
      if (el) {
        // Strip incomplete tags block during streaming (hide [TAGSSTART] etc.)
        let displayContent = currentGeneratingContent;
        displayContent = displayContent.replace(/\[TAGS_?START\][\s\S]*$/gi, '');
        // 实时渲染 Markdown，让用户看到格式化后的内容
        el.innerHTML = renderMarkdown(displayContent);
        // 让正在生成的内容底部滚动到可视区域
        el.scrollIntoView({ behavior: 'smooth', block: 'end' });
      }
    });
  };

  switch (message.type) {
    case 'LOCATE_SUMMARY':
      locateSummaryByUrl(message.url, { showToast: true });
      break;

    case 'SUMMARIZE_START':
      // 更新骨架屏状态文本
      updateSkeletonStatus(message.phase === 'classifying' ? '正在分析文章类型' : '正在生成总结');

      if (!currentGeneratingContent) {
        streamPreEl = null;
      }
      if (message.pageTitle || message.pageUrl) {
        window._currentPageInfo = {
          ...(window._currentPageInfo || {}),
          title: message.pageTitle || (window._currentPageInfo || {}).title,
          url: message.pageUrl || (window._currentPageInfo || {}).url
        };
      }
      break;

    case 'SUMMARIZE_CHUNK':
      // 收到内容后，隐藏骨架屏，显示流式内容
      currentGeneratingContent = message.fullContent;
      ensureStreamPre();
      scheduleStreamRender();
      // 保持在顶部可见
      break;

    case 'SUMMARIZE_DONE':
      streamPreEl = null;
      // 保存到历史
      const pageInfo = window._currentPageInfo || {};
      // 移除临时的"正在生成总结"提示
      let finalContent = message.result || '';
      finalContent = finalContent.replace(/🤖 正在生成总结\.\.\.\n\n/g, '');

      // 构建 promptName，智能分析模式下显示文章类型
      let displayPromptName = pageInfo.promptName || '默认';
      if (message.articleType && message.matchedPrompt) {
        // 智能分析模式：显示文章类型
        const typeNames = {
          'tech-tutorial': '技术教程',
          'news': '新闻资讯',
          'opinion': '观点评论',
          'research': '研究论文',
          'product': '产品介绍',
          'trend': '行业趋势',
          'lifestyle': '生活方式',
          'business': '商业财经',
          'ad': '广告宣传',
          'learning-deep': '深度学习型',
          'learning-simple': '科普型',
          'other': '其他'
        };
        const typeName = typeNames[message.articleType] || '其他';
        displayPromptName = `智能分析 · ${typeName}`;
      }

      const newMessage = {
        id: Date.now().toString(),
        timestamp: Date.now(),
        pageTitle: message.pageTitle || pageInfo.title || '未知页面',
        pageUrl: message.pageUrl || pageInfo.url || '',
        promptName: displayPromptName,
        promptId: pageInfo.promptId || '',
        articleType: message.articleType || '',
        content: finalContent
      };

      chatHistory.push(newMessage);
      saveHistory();

      // 如果生成过程中点了收藏，现在添加到收藏
      if (isGeneratingFavorited) {
        favorites.push({
          id: `fav-${Date.now()}-${Math.random().toString(36).slice(2)}`,
          summaryId: newMessage.id,
          pageTitle: newMessage.pageTitle,
          pageUrl: newMessage.pageUrl,
          promptName: newMessage.promptName,
          preview: newMessage.content.substring(0, 200),
          createdAt: Date.now()
        });
        saveFavorites();
        showToast('总结已保存并收藏');
      }

      // 隐藏生成中，恢复历史消息显示，重新渲染历史
      elements.generating.style.display = 'none';
      elements.messages.style.display = '';  // 恢复历史消息显示
      renderHistory();

      // 滚动到顶部，显示刚完成的消息
      scrollToTop();

      isProcessing = false;
      elements.summarizeBtn.disabled = false;
      break;

    case 'SUMMARIZE_ERROR':
      streamPreEl = null;
      elements.messages.style.display = '';  // 恢复历史消息显示
      elements.genContent.innerHTML = `
        <div class="sp-error">
          <p><strong>总结失败</strong></p>
          <p>${escapeHtml(message.error)}</p>
          <ul>
            <li>检查 Ollama 是否已启动</li>
            <li>确认模型已下载</li>
            <li>查看网络连接</li>
          </ul>
        </div>
      `;
      isProcessing = false;
      elements.summarizeBtn.disabled = false;
      break;
  }
}

// ============ 工具函数 ============

// 更新骨架屏状态文本
function updateSkeletonStatus(text) {
  const statusText = document.querySelector('.sp-status-text');
  if (statusText) {
    statusText.textContent = text;
  }
}

// 滚动到顶部
function scrollToTop() {
  elements.chatContainer.scrollTop = 0;
}

// 滚动到底部
function scrollToBottom() {
  elements.chatContainer.scrollTop = elements.chatContainer.scrollHeight;
}

// 格式化时间
function formatTime(timestamp) {
  const date = new Date(timestamp);
  const now = new Date();
  const diff = now - date;

  // 1分钟内
  if (diff < 60000) {
    return '刚刚';
  }

  // 1小时内
  if (diff < 3600000) {
    return `${Math.floor(diff / 60000)} 分钟前`;
  }

  // 今天
  if (date.toDateString() === now.toDateString()) {
    return date.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });
  }

  // 昨天
  const yesterday = new Date(now);
  yesterday.setDate(yesterday.getDate() - 1);
  if (date.toDateString() === yesterday.toDateString()) {
    return `昨天 ${date.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })}`;
  }

  // 更早
  return date.toLocaleDateString('zh-CN', { month: 'short', day: 'numeric' });
}

// HTML 转义
function escapeHtml(text) {
  if (!text) return '';
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

/**
 * Strip tags block from summary text for display
 * Removes [TAGS_START]...[TAGS_END] or [TAGSSTART]...[TAGSEND] blocks
 */
function stripTagsBlock(text) {
    if (!text) return text;
    // Match various formats: [TAGS_START], [TAGSSTART], with or without underscore, case insensitive
    // Also handle mismatched tags like [TAGSSTART]...[TAGS_END]
    let result = text.replace(/\[TAGS_?START\][\s\S]*?\[TAGS_?END\]/gi, '');
    // Clean up any trailing dashes or whitespace
    result = result.replace(/\n*-{3,}\s*$/g, '');
    return result.trim();
}

// 简单 Markdown 渲染（带 XSS 防护）- 从 hotnews 网站复制
function renderMarkdown(text) {
    if (!text) return '';
    
    // Pre-process: convert HTML br tags to newlines before escaping
    let html = text
        .replace(/<br\s*\/?>/gi, '\n')
        .replace(/<\/br>/gi, '\n');
    
    // Remove checkbox markers [ ] from action lists
    html = html.replace(/- \[ \]/g, '-');
    html = html.replace(/- \[\]/g, '-');
    
    // Escape HTML
    html = html
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
    
    // Code blocks (must be before other processing)
    html = html.replace(/```(\w*)\n([\s\S]*?)```/g, '<pre><code class="language-$1">$2</code></pre>');
    html = html.replace(/`([^`]+)`/g, '<code>$1</code>');
    
    // Headers (with optional leading #)
    html = html.replace(/^#{4}\s+(.+)$/gm, '<h4>$1</h4>');
    html = html.replace(/^#{3}\s+(.+)$/gm, '<h3>$1</h3>');
    html = html.replace(/^#{2}\s+(.+)$/gm, '<h2>$1</h2>');
    html = html.replace(/^#{1}\s+(.+)$/gm, '<h1>$1</h1>');
    
    // Bold and italic (handle ** and * properly)
    html = html.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
    html = html.replace(/\*([^*]+)\*/g, '<em>$1</em>');
    html = html.replace(/__([^_]+)__/g, '<strong>$1</strong>');
    html = html.replace(/_([^_]+)_/g, '<em>$1</em>');
    
    // Links
    html = html.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
    
    // Blockquotes (> at start of line)
    html = html.replace(/^&gt;\s*(.*)$/gm, '<blockquote>$1</blockquote>');
    // Merge consecutive blockquotes
    html = html.replace(/<\/blockquote>\n<blockquote>/g, '\n');
    
    // Horizontal rules (---, ***, ___) - only when alone on a line
    html = html.replace(/^[-]{3,}\s*$/gm, '<hr>');
    html = html.replace(/^[*]{3,}\s*$/gm, '<hr>');
    html = html.replace(/^[_]{3,}\s*$/gm, '<hr>');
    
    // Process line by line for lists and tables
    const lines = html.split('\n');
    let result = [];
    let inTable = false;
    let tableRows = [];
    let inList = false;
    let listItems = [];
    
    for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        const trimmedLine = line.trim();
        
        // Check for table row
        const isTableRow = /^\|(.+)\|$/.test(trimmedLine);
        const isTableSeparator = /^\|[\s\-:|]+\|$/.test(trimmedLine);
        
        // Check for list item (- or * followed by space, or numbered list)
        const unorderedMatch = trimmedLine.match(/^[-*]\s+(.+)$/);
        const orderedMatch = trimmedLine.match(/^\d+\.\s+(.+)$/);
        const isListItem = unorderedMatch || orderedMatch;
        
        // Handle table
        if (isTableRow) {
            // Close any open list first
            if (inList && listItems.length > 0) {
                result.push('<ul>' + listItems.join('') + '</ul>');
                listItems = [];
                inList = false;
            }
            
            if (!inTable) {
                inTable = true;
                tableRows = [];
            }
            if (!isTableSeparator) {
                const cells = trimmedLine.slice(1, -1).split('|').map(c => c.trim());
                const isHeader = tableRows.length === 0;
                const tag = isHeader ? 'th' : 'td';
                const row = '<tr>' + cells.map(c => `<${tag}>${c}</${tag}>`).join('') + '</tr>';
                tableRows.push(row);
            }
            continue;
        } else if (inTable && tableRows.length > 0) {
            result.push('<table>' + tableRows.join('') + '</table>');
            tableRows = [];
            inTable = false;
        }
        
        // Handle list item
        if (isListItem) {
            const content = unorderedMatch ? unorderedMatch[1] : orderedMatch[1];
            inList = true;
            listItems.push('<li>' + content + '</li>');
            continue;
        } else if (inList && listItems.length > 0) {
            result.push('<ul>' + listItems.join('') + '</ul>');
            listItems = [];
            inList = false;
        }
        
        result.push(line);
    }
    
    // Close any remaining table or list
    if (inTable && tableRows.length > 0) {
        result.push('<table>' + tableRows.join('') + '</table>');
    }
    if (inList && listItems.length > 0) {
        result.push('<ul>' + listItems.join('') + '</ul>');
    }
    
    html = result.join('\n');
    
    // Convert double newlines to paragraph breaks
    html = html.split(/\n{2,}/).map(block => {
        block = block.trim();
        if (!block) return '';
        // Don't wrap block elements
        if (/^<(h[1-6]|ul|ol|table|pre|blockquote|hr)/.test(block)) {
            return block;
        }
        // Don't wrap if it ends with a block element
        if (/<\/(h[1-6]|ul|ol|table|pre|blockquote)>$/.test(block)) {
            return block;
        }
        return '<p>' + block.replace(/\n/g, '<br>') + '</p>';
    }).join('\n');
    
    // Clean up empty paragraphs and stray tags
    html = html.replace(/<p>\s*<\/p>/g, '');
    html = html.replace(/<p><hr><\/p>/g, '<hr>');
    html = html.replace(/<p>(<table>)/g, '$1');
    html = html.replace(/(<\/table>)<\/p>/g, '$1');
    html = html.replace(/<p>(<ul>)/g, '$1');
    html = html.replace(/(<\/ul>)<\/p>/g, '$1');
    html = html.replace(/<p>(<blockquote>)/g, '$1');
    html = html.replace(/(<\/blockquote>)<\/p>/g, '$1');
    
    return html;
}

// 简单 Markdown 渲染别名
const renderMarkdownSimple = renderMarkdown;

// 显示 Toast
function showToast(message) {
  const existing = document.querySelector('.sp-toast');
  if (existing) existing.remove();

  const toast = document.createElement('div');
  toast.className = 'sp-toast';
  toast.textContent = message;
  document.body.appendChild(toast);

  setTimeout(() => toast.remove(), 2000);
}

// 显示确认对话框
function showConfirm(title, message, onConfirm) {
  const overlay = document.createElement('div');
  overlay.className = 'sp-confirm-overlay';
  overlay.innerHTML = `
    <div class="sp-confirm-dialog">
      <h4>${escapeHtml(title)}</h4>
      <p>${escapeHtml(message)}</p>
      <div class="sp-confirm-actions">
        <button class="sp-confirm-cancel">取消</button>
        <button class="sp-confirm-ok">确定</button>
      </div>
    </div>
  `;

  document.body.appendChild(overlay);

  overlay.querySelector('.sp-confirm-cancel').addEventListener('click', () => {
    overlay.remove();
  });

  overlay.querySelector('.sp-confirm-ok').addEventListener('click', () => {
    overlay.remove();
    onConfirm();
  });

  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) {
      overlay.remove();
    }
  });
}

// 生成分享图片 Canvas - 简洁阅读风格
async function generateShareCanvas(msg) {
  try {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    
    // 设计参数
    const scale = 2;
    const width = 720;
    const sidePadding = 48;
    const contentFontSize = 15;
    const lineHeight = 28;
    
    // 内容处理
    const title = msg.pageTitle || '未知标题';
    const content = msg.content || '';
    const source = msg.pageUrl ? new URL(msg.pageUrl).hostname.replace('www.', '') : '';
    
    // 解析内容
    const sections = parseMarkdownToSections(content);
    
    // 预计算高度
    ctx.font = `600 20px "PingFang SC", "Microsoft YaHei", sans-serif`;
    const titleLines = wrapText(ctx, title, width - sidePadding * 2);
    
    // 计算内容高度
    let contentHeight = 0;
    ctx.font = `${contentFontSize}px "PingFang SC", "Microsoft YaHei", sans-serif`;
    const contentWidth = width - sidePadding * 2;
    
    sections.forEach((section, idx) => {
      if (section.type === 'heading') {
        contentHeight += (idx > 0 ? 24 : 0) + 36;
      } else if (section.type === 'text') {
        const lines = wrapText(ctx, section.content, contentWidth);
        contentHeight += lines.length * lineHeight + 8;
      } else if (section.type === 'bullet') {
        const lines = wrapText(ctx, section.content, contentWidth - 20);
        contentHeight += lines.length * lineHeight + 6;
      }
    });
    
    // 总高度
    const headerHeight = 56;
    const titleHeight = titleLines.length * 28 + 32;
    const dividerHeight = 32;
    const footerHeight = 56;
    const totalHeight = headerHeight + titleHeight + dividerHeight + contentHeight + footerHeight;
    
    // 设置画布
    canvas.width = width * scale;
    canvas.height = totalHeight * scale;
    ctx.scale(scale, scale);
    
    // 背景 - 温暖的米白色
    ctx.fillStyle = '#FAFAF8';
    ctx.fillRect(0, 0, width, totalHeight);
    
    // Header - 品牌
    let y = 38;
    ctx.fillStyle = '#86868B';
    ctx.font = `500 13px "PingFang SC", "Microsoft YaHei", sans-serif`;
    ctx.fillText('uihash · 智能总结', sidePadding, y);
    
    // 标题
    y = headerHeight + 8;
    ctx.fillStyle = '#1D1D1F';
    ctx.font = `600 20px "PingFang SC", "Microsoft YaHei", sans-serif`;
    titleLines.forEach(line => {
      ctx.fillText(line, sidePadding, y);
      y += 28;
    });
    
    // 分隔线
    y += 16;
    ctx.strokeStyle = '#E8E6E3';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(sidePadding, y);
    ctx.lineTo(width - sidePadding, y);
    ctx.stroke();
    y += 24;
    
    // 内容
    sections.forEach((section, idx) => {
      if (section.type === 'heading') {
        if (idx > 0) y += 24;
        ctx.fillStyle = '#1D1D1F';
        ctx.font = `600 16px "PingFang SC", "Microsoft YaHei", sans-serif`;
        ctx.fillText(section.content, sidePadding, y + 20);
        y += 36;
      } else if (section.type === 'text') {
        ctx.font = `${contentFontSize}px "PingFang SC", "Microsoft YaHei", sans-serif`;
        const lines = wrapText(ctx, section.content, contentWidth);
        lines.forEach(line => {
          drawStyledText(ctx, line, sidePadding, y + lineHeight - 8, contentFontSize);
          y += lineHeight;
        });
        y += 8;
      } else if (section.type === 'bullet') {
        ctx.fillStyle = '#86868B';
        ctx.beginPath();
        ctx.arc(sidePadding + 4, y + lineHeight - 12, 3, 0, Math.PI * 2);
        ctx.fill();
        ctx.font = `${contentFontSize}px "PingFang SC", "Microsoft YaHei", sans-serif`;
        const lines = wrapText(ctx, section.content, contentWidth - 20);
        lines.forEach((line) => {
          drawStyledText(ctx, line, sidePadding + 16, y + lineHeight - 8, contentFontSize);
          y += lineHeight;
        });
        y += 6;
      }
    });
    
    // Footer
    const footerY = totalHeight - 32;
    ctx.font = `500 14px "PingFang SC", "Microsoft YaHei", sans-serif`;
    if (source) {
      ctx.fillStyle = '#86868B';
      ctx.fillText(`来源：${source}`, sidePadding, footerY);
    }
    ctx.textAlign = 'right';
    ctx.fillStyle = '#007AFF';
    ctx.fillText('uihash智能总结', width - sidePadding, footerY);
    ctx.textAlign = 'left';
    
    return canvas;
    
  } catch (err) {
    console.error('生成图片失败:', err);
    showToast('生成图片失败');
    return null;
  }
}

// 解析 Markdown 为结构化内容
function parseMarkdownToSections(md) {
  const sections = [];
  const lines = md.split('\n');
  
  lines.forEach(line => {
    const trimmed = line.trim();
    if (!trimmed) return;
    
    // 标题 - 去掉 # 号
    const headingMatch = trimmed.match(/^#{1,3}\s*(.+)$/);
    if (headingMatch) {
      sections.push({ type: 'heading', content: headingMatch[1] });
      return;
    }
    
    // 列表项
    const bulletMatch = trimmed.match(/^[-*•]\s*(.+)$/);
    if (bulletMatch) {
      sections.push({ type: 'bullet', content: bulletMatch[1] });
      return;
    }
    
    // 普通文本
    if (trimmed.length > 0) {
      sections.push({ type: 'text', content: trimmed });
    }
  });
  
  return sections;
}

// 绘制带样式的文字（支持加粗）
function drawStyledText(ctx, text, x, y, fontSize) {
  const parts = text.split(/(\*\*[^*]+\*\*)/g);
  let currentX = x;
  
  parts.forEach(part => {
    const boldMatch = part.match(/^\*\*(.+)\*\*$/);
    if (boldMatch) {
      ctx.fillStyle = '#1D1D1F';
      ctx.font = `600 ${fontSize}px "PingFang SC", "Microsoft YaHei", sans-serif`;
      ctx.fillText(boldMatch[1], currentX, y);
      currentX += ctx.measureText(boldMatch[1]).width;
    } else if (part) {
      ctx.fillStyle = '#424245';
      ctx.font = `400 ${fontSize}px "PingFang SC", "Microsoft YaHei", sans-serif`;
      ctx.fillText(part, currentX, y);
      currentX += ctx.measureText(part).width;
    }
  });
}

// 文本换行
function wrapText(ctx, text, maxWidth) {
  const lines = [];
  if (!text) return lines;
  
  let currentLine = '';
  
  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    const testLine = currentLine + char;
    const cleanLine = testLine.replace(/\*\*/g, '');
    const metrics = ctx.measureText(cleanLine);
    
    if (metrics.width > maxWidth && currentLine) {
      lines.push(currentLine);
      currentLine = char;
    } else {
      currentLine = testLine;
    }
  }
  
  if (currentLine) {
    lines.push(currentLine);
  }
  
  return lines;
}

// 绘制圆角矩形
function roundRect(ctx, x, y, width, height, radius) {
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + width - radius, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
  ctx.lineTo(x + width, y + height - radius);
  ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
  ctx.lineTo(x + radius, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();
}

// 动态加载脚本
function loadScript(src) {
  return new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = src;
    script.onload = resolve;
    script.onerror = reject;
    document.head.appendChild(script);
  });
}

// 显示错误
function showError(message) {
  elements.genContent.innerHTML = `
    <div class="sp-error">
      <p><strong>出错了</strong></p>
      <p>${escapeHtml(message)}</p>
    </div>
  `;
}

function initDrawerResizer(resizer, drawer) {
  let startX, startWidth;

  const onMouseDown = (e) => {
    startX = e.clientX;
    startWidth = parseInt(document.defaultView.getComputedStyle(drawer).width, 10);

    document.body.classList.add('is-resizing');
    resizer.classList.add('is-active');

    // 禁用 iframe 指针事件防止拖动卡顿
    const iframes = document.querySelectorAll('iframe');
    iframes.forEach(el => el.style.pointerEvents = 'none');

    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseup', onMouseUp);
    e.preventDefault(); // 防止文本选中
  };

  const onMouseMove = (e) => {
    // requestAnimationFrame 优化性能
    requestAnimationFrame(() => {
      // 这一步很重要：因为面板固定在右侧，向左拖拽（clientX 减小）应该增加宽度
      // 变化量 delta = startX - currentX
      const delta = startX - e.clientX;
      const newWidth = startWidth + delta;

      const minW = 320;
      const maxW = window.innerWidth - 40; // 留一点余地

      if (newWidth >= minW && newWidth <= maxW) {
        drawer.style.width = newWidth + 'px';
      }
    });
  };

  const onMouseUp = () => {
    document.body.classList.remove('is-resizing');
    resizer.classList.remove('is-active');

    const iframes = document.querySelectorAll('iframe');
    iframes.forEach(el => el.style.pointerEvents = '');

    document.removeEventListener('mousemove', onMouseMove);
    document.removeEventListener('mouseup', onMouseUp);
  };

  resizer.addEventListener('mousedown', onMouseDown);
}

// ============ WeChat 面板功能 ============

let wechatStatus = null;
let wechatSyncing = false;
// qrLoginState is already declared above for QR code login

function openWechatDrawer() {
  const drawer = document.getElementById('sp-wechat-drawer');
  const overlay = document.getElementById('sp-wechat-overlay');
  if (drawer) {
    drawer.classList.add('is-open');
    drawer.setAttribute('aria-hidden', 'false');
  }
  if (overlay) overlay.style.display = 'block';
  
  // 打开时自动刷新状态
  refreshWechatStatus();
}

function closeWechatDrawer() {
  const drawer = document.getElementById('sp-wechat-drawer');
  const overlay = document.getElementById('sp-wechat-overlay');
  if (drawer) {
    drawer.classList.remove('is-open');
    drawer.setAttribute('aria-hidden', 'true');
  }
  if (overlay) overlay.style.display = 'none';
  
  // 关闭时停止 QR 轮询
  stopQRPolling();
}

function toggleWechatDrawer() {
  const drawer = document.getElementById('sp-wechat-drawer');
  if (drawer && drawer.classList.contains('is-open')) {
    closeWechatDrawer();
  } else {
    openWechatDrawer();
  }
}

async function refreshWechatStatus() {
  const statusCard = document.getElementById('sp-wechat-status-card');
  const actionsArea = document.getElementById('sp-wechat-actions-area');
  
  if (!statusCard) return;
  
  // 显示加载状态
  statusCard.innerHTML = `
    <div class="sp-wechat-status-loading">
      <div class="sp-wechat-spinner"></div>
      <span>正在检查状态...</span>
    </div>
  `;
  
  try {
    const response = await new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: 'WECHAT_GET_STATUS' }, resolve);
    });
    
    wechatStatus = response;
    renderWechatStatus(response);
    renderWechatActions(response);
  } catch (err) {
    statusCard.innerHTML = `
      <div class="sp-wechat-result is-error">
        <span class="sp-wechat-result-icon">❌</span>
        <span>获取状态失败: ${escapeHtml(err.message || '未知错误')}</span>
      </div>
    `;
  }
}

function renderWechatStatus(status) {
  const statusCard = document.getElementById('sp-wechat-status-card');
  if (!statusCard) return;
  
  const hotnewsLoggedIn = status?.hotnewsLoggedIn;
  const wechatAuth = status?.wechatAuth;
  
  let html = '';
  
  // hotnews 登录状态
  html += `
    <div class="sp-wechat-status-item">
      <span class="sp-wechat-status-label">
        <span>🔥</span> hotnews 账号
      </span>
      <span class="sp-wechat-status-value ${hotnewsLoggedIn ? 'is-success' : 'is-muted'}">
        ${hotnewsLoggedIn ? '✓ 已登录' : '未登录'}
      </span>
    </div>
  `;
  
  // 公众号授权状态（只有登录后才显示）
  if (hotnewsLoggedIn) {
    const authorized = wechatAuth?.authorized;
    const expireSoon = wechatAuth?.expireSoon;
    
    let authStatusClass = 'is-muted';
    let authStatusText = '未授权';
    
    if (authorized) {
      if (expireSoon) {
        authStatusClass = 'is-warning';
        authStatusText = '⚠️ 即将过期';
      } else {
        authStatusClass = 'is-success';
        authStatusText = '✓ 已授权';
      }
    }
    
    html += `
      <div class="sp-wechat-status-item">
        <span class="sp-wechat-status-label">
          <span>📱</span> 公众号授权
        </span>
        <span class="sp-wechat-status-value ${authStatusClass}">
          ${authStatusText}
        </span>
      </div>
    `;
  }
  
  statusCard.innerHTML = html;
}

function renderWechatActions(status) {
  const actionsArea = document.getElementById('sp-wechat-actions-area');
  if (!actionsArea) return;
  
  const hotnewsLoggedIn = status?.hotnewsLoggedIn;
  const wechatLoggedIn = status?.wechatLoggedIn;  // 浏览器中是否登录了公众号后台
  const wechatAuth = status?.wechatAuth;
  
  let html = '';
  
  if (!hotnewsLoggedIn) {
    // 未登录 hotnews
    if (wechatLoggedIn) {
      // 浏览器已登录公众号后台 - 推荐使用 Cookie 同步方式
      html = `
        <div class="sp-wechat-tip is-success">
          <span>✅ 检测到公众号登录态</span>
        </div>
        <button id="sp-wechat-cookie-login" class="sp-wechat-action-btn sp-btn-primary">
          <span class="sp-btn-icon">🚀</span>
          <span>一键登录并授权</span>
        </button>
        <div class="sp-wechat-help-text">
          使用当前浏览器的公众号登录态，快速完成授权
        </div>
        <div class="sp-wechat-divider">
          <span>或</span>
        </div>
        <button id="sp-wechat-qr-login" class="sp-wechat-action-btn sp-btn-outline sp-btn-small">
          <span class="sp-btn-icon">📷</span>
          <span>扫码登录</span>
        </button>
      `;
    } else {
      // 浏览器未登录公众号后台 - 提供两种选择
      html = `
        <button id="sp-wechat-goto-mp" class="sp-wechat-action-btn sp-btn-primary">
          <span class="sp-btn-icon">🔗</span>
          <span>前往公众号后台登录</span>
        </button>
        <div class="sp-wechat-help-text">
          登录后返回此处，即可一键授权（推荐）
        </div>
        <div class="sp-wechat-divider">
          <span>或</span>
        </div>
        <button id="sp-wechat-qr-login" class="sp-wechat-action-btn sp-btn-outline sp-btn-small">
          <span class="sp-btn-icon">📷</span>
          <span>扫码登录</span>
        </button>
        <div class="sp-wechat-help-text sp-text-muted">
          扫码方式可能受限流影响
        </div>
      `;
    }
  } else {
    // 已登录 hotnews，显示公众号相关操作
    const authorized = wechatAuth?.authorized;
    const expireSoon = wechatAuth?.expireSoon;
    
    if (!authorized || expireSoon) {
      // 需要授权或即将过期
      if (wechatLoggedIn) {
        // 浏览器已登录公众号 - 推荐 Cookie 同步
        html = `
          <div class="sp-wechat-tip is-success">
            <span>✅ 检测到公众号登录态</span>
          </div>
          <button id="sp-wechat-cookie-sync" class="sp-wechat-action-btn sp-btn-primary">
            <span class="sp-btn-icon">🔄</span>
            <span>${authorized ? '刷新授权' : '一键授权'}</span>
          </button>
          <div class="sp-wechat-divider">
            <span>或</span>
          </div>
          <button id="sp-wechat-qr-auth" class="sp-wechat-action-btn sp-btn-outline sp-btn-small">
            <span class="sp-btn-icon">📷</span>
            <span>扫码授权</span>
          </button>
        `;
      } else {
        // 浏览器未登录公众号
        html = `
          <button id="sp-wechat-goto-mp" class="sp-wechat-action-btn sp-btn-primary">
            <span class="sp-btn-icon">🔗</span>
            <span>前往公众号后台登录</span>
          </button>
          <div class="sp-wechat-help-text">
            登录后返回此处，即可一键授权（推荐）
          </div>
          <div class="sp-wechat-divider">
            <span>或</span>
          </div>
          <button id="sp-wechat-qr-auth" class="sp-wechat-action-btn sp-btn-outline sp-btn-small">
            <span class="sp-btn-icon">📷</span>
            <span>扫码授权</span>
          </button>
        `;
      }
    } else {
      // 已授权且有效
      html = `
        <div class="sp-wechat-result is-success">
          <span class="sp-wechat-result-icon">✅</span>
          <span>公众号已授权，hotnews 将自动抓取文章</span>
        </div>
        <button id="sp-wechat-cookie-sync" class="sp-wechat-action-btn sp-btn-outline sp-btn-small">
          <span class="sp-btn-icon">🔄</span>
          <span>刷新授权</span>
        </button>
      `;
    }
  }
  
  actionsArea.innerHTML = html;
  
  // 绑定事件
  const cookieLoginBtn = document.getElementById('sp-wechat-cookie-login');
  const cookieSyncBtn = document.getElementById('sp-wechat-cookie-sync');
  const qrLoginBtn = document.getElementById('sp-wechat-qr-login');
  const qrAuthBtn = document.getElementById('sp-wechat-qr-auth');
  const gotoMpBtn = document.getElementById('sp-wechat-goto-mp');
  
  if (cookieLoginBtn) cookieLoginBtn.addEventListener('click', handleCookieLogin);
  if (cookieSyncBtn) cookieSyncBtn.addEventListener('click', handleCookieSync);
  if (qrLoginBtn) qrLoginBtn.addEventListener('click', startQRLoginFlow);
  if (qrAuthBtn) qrAuthBtn.addEventListener('click', startQRLoginFlow);
  if (gotoMpBtn) gotoMpBtn.addEventListener('click', openWechatMp);
}

function openWechatMp() {
  chrome.tabs.create({ url: 'https://mp.weixin.qq.com/' });
}

// ============ Cookie 方式登录/同步（推荐，低风控） ============

async function handleCookieLogin() {
  const actionsArea = document.getElementById('sp-wechat-actions-area');
  if (!actionsArea) return;
  
  // 显示加载状态
  actionsArea.innerHTML = `
    <div class="sp-wechat-status-loading">
      <div class="sp-wechat-spinner"></div>
      <span>正在登录并授权...</span>
    </div>
  `;
  
  try {
    // 1. 先尝试从 hotnews 获取 token（如果用户已在网页登录）
    let tokenResult = await new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: 'WECHAT_TRY_GET_TOKEN' }, resolve);
    });
    
    let needCreateAccount = !tokenResult?.success;
    
    // 2. 同步 Cookie 到 hotnews
    const syncResult = await new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: 'WECHAT_SYNC_REQUEST' }, resolve);
    });
    
    if (syncResult?.success) {
      showToast('登录并授权成功！');
      await refreshWechatStatus();
    } else if (syncResult?.needLogin) {
      // 需要先登录 hotnews - 提示用户
      actionsArea.innerHTML = `
        <div class="sp-wechat-result is-warning">
          <span class="sp-wechat-result-icon">⚠️</span>
          <span>需要先登录 hotnews 账号</span>
        </div>
        <button id="sp-wechat-qr-login-fallback" class="sp-wechat-action-btn sp-btn-primary">
          <span class="sp-btn-icon">📷</span>
          <span>扫码登录</span>
        </button>
        <div class="sp-wechat-help-text">
          首次使用需要扫码创建账号
        </div>
      `;
      const fallbackBtn = document.getElementById('sp-wechat-qr-login-fallback');
      if (fallbackBtn) fallbackBtn.addEventListener('click', startQRLoginFlow);
    } else {
      throw new Error(syncResult?.error || '授权失败');
    }
  } catch (err) {
    actionsArea.innerHTML = `
      <div class="sp-wechat-result is-error">
        <span class="sp-wechat-result-icon">❌</span>
        <span>${escapeHtml(err.message || '操作失败')}</span>
      </div>
      <button id="sp-wechat-retry" class="sp-wechat-action-btn sp-btn-outline">
        <span class="sp-btn-icon">🔄</span>
        <span>重试</span>
      </button>
    `;
    const retryBtn = document.getElementById('sp-wechat-retry');
    if (retryBtn) retryBtn.addEventListener('click', () => refreshWechatStatus());
  }
}

async function handleCookieSync() {
  const actionsArea = document.getElementById('sp-wechat-actions-area');
  if (!actionsArea) return;
  
  // 显示加载状态
  actionsArea.innerHTML = `
    <div class="sp-wechat-status-loading">
      <div class="sp-wechat-spinner"></div>
      <span>正在同步授权...</span>
    </div>
  `;
  
  try {
    const result = await new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: 'WECHAT_SYNC_REQUEST' }, resolve);
    });
    
    if (result?.success) {
      showToast('授权刷新成功！');
      await refreshWechatStatus();
    } else {
      throw new Error(result?.error || '同步失败');
    }
  } catch (err) {
    showToast(err.message || '同步失败');
    await refreshWechatStatus();
  }
}

// ============ QR 登录流程 ============

async function startQRLoginFlow() {
  const actionsArea = document.getElementById('sp-wechat-actions-area');
  if (!actionsArea) return;
  
  // 显示加载状态
  actionsArea.innerHTML = `
    <div class="sp-wechat-qr-container">
      <div class="sp-wechat-status-loading">
        <div class="sp-wechat-spinner"></div>
        <span>正在生成二维码...</span>
      </div>
    </div>
  `;
  
  try {
    // 1. 创建登录会话
    const startResult = await new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: 'WECHAT_QR_START' }, resolve);
    });
    
    if (!startResult?.success) {
      throw new Error(startResult?.error || '创建登录会话失败');
    }
    
    const tempUserId = startResult.tempUserId;
    
    // 2. 获取二维码 URL
    const qrUrlResult = await new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: 'WECHAT_QR_IMAGE_URL', tempUserId }, resolve);
    });
    
    const qrUrl = qrUrlResult?.url;
    if (!qrUrl) {
      throw new Error('获取二维码失败');
    }
    
    // 3. 显示二维码
    renderQRCode(qrUrl, tempUserId);
    
    // 4. 开始轮询状态
    startQRPolling(tempUserId);
    
  } catch (err) {
    actionsArea.innerHTML = `
      <div class="sp-wechat-result is-error">
        <span class="sp-wechat-result-icon">❌</span>
        <span>${escapeHtml(err.message || '生成二维码失败')}</span>
      </div>
      <button id="sp-wechat-retry" class="sp-wechat-action-btn sp-btn-outline">
        <span class="sp-btn-icon">🔄</span>
        <span>重试</span>
      </button>
    `;
    
    const retryBtn = document.getElementById('sp-wechat-retry');
    if (retryBtn) retryBtn.addEventListener('click', startQRLoginFlow);
  }
}

function renderQRCode(qrUrl, tempUserId) {
  const actionsArea = document.getElementById('sp-wechat-actions-area');
  if (!actionsArea) return;
  
  actionsArea.innerHTML = `
    <div class="sp-wechat-qr-container">
      <div class="sp-wechat-qr-title">请使用微信扫描二维码</div>
      <div class="sp-wechat-qr-wrapper">
        <img src="${escapeHtml(qrUrl)}" alt="登录二维码" class="sp-wechat-qr-image" />
        <div class="sp-wechat-qr-overlay" id="sp-wechat-qr-overlay" style="display:none;">
          <div class="sp-wechat-qr-overlay-text"></div>
        </div>
      </div>
      <div class="sp-wechat-qr-status" id="sp-wechat-qr-status">等待扫码...</div>
      <button id="sp-wechat-qr-cancel" class="sp-wechat-action-btn sp-btn-outline sp-btn-small">
        <span>取消</span>
      </button>
    </div>
  `;
  
  const cancelBtn = document.getElementById('sp-wechat-qr-cancel');
  if (cancelBtn) {
    cancelBtn.addEventListener('click', () => {
      stopQRPolling();
      chrome.runtime.sendMessage({ type: 'WECHAT_QR_CANCEL', tempUserId });
      refreshWechatStatus();
    });
  }
}

function startQRPolling(tempUserId) {
  stopQRPolling(); // 先停止之前的轮询
  
  qrLoginState = {
    tempUserId,
    polling: true,
    pollTimer: null,
  };
  
  const poll = async () => {
    if (!qrLoginState?.polling) return;
    
    try {
      const result = await new Promise((resolve) => {
        chrome.runtime.sendMessage({ type: 'WECHAT_QR_STATUS', tempUserId }, resolve);
      });
      
      updateQRStatus(result, tempUserId);
      
      if (result.status === 'confirmed') {
        // 扫码确认，完成登录
        await completeQRLogin(tempUserId);
        return;
      }
      
      if (result.needRefresh) {
        // 二维码过期，需要刷新
        showQRExpired(tempUserId);
        return;
      }
      
      // 继续轮询
      if (qrLoginState?.polling) {
        qrLoginState.pollTimer = setTimeout(poll, 2000);
      }
    } catch (err) {
      console.error('QR polling error:', err);
      if (qrLoginState?.polling) {
        qrLoginState.pollTimer = setTimeout(poll, 3000);
      }
    }
  };
  
  // 开始轮询
  poll();
}

function stopQRPolling() {
  if (qrLoginState?.pollTimer) {
    clearTimeout(qrLoginState.pollTimer);
  }
  if (qrLoginState) {
    qrLoginState.polling = false;
  }
  qrLoginState = null;
}

function updateQRStatus(result, tempUserId) {
  const statusEl = document.getElementById('sp-wechat-qr-status');
  const overlayEl = document.getElementById('sp-wechat-qr-overlay');
  
  if (!statusEl) return;
  
  switch (result.status) {
    case 'waiting':
      statusEl.textContent = '等待扫码...';
      statusEl.className = 'sp-wechat-qr-status';
      if (overlayEl) overlayEl.style.display = 'none';
      break;
    case 'scanned':
      statusEl.textContent = '已扫码，请在手机上确认';
      statusEl.className = 'sp-wechat-qr-status is-scanned';
      if (overlayEl) {
        overlayEl.style.display = 'flex';
        overlayEl.querySelector('.sp-wechat-qr-overlay-text').textContent = '请在手机上确认';
      }
      break;
    case 'confirmed':
      statusEl.textContent = '登录成功，正在处理...';
      statusEl.className = 'sp-wechat-qr-status is-success';
      break;
    case 'expired':
      statusEl.textContent = '二维码已过期';
      statusEl.className = 'sp-wechat-qr-status is-error';
      break;
    case 'error':
      statusEl.textContent = result.message || '出错了';
      statusEl.className = 'sp-wechat-qr-status is-error';
      break;
  }
}

function showQRExpired(tempUserId) {
  stopQRPolling();
  
  const actionsArea = document.getElementById('sp-wechat-actions-area');
  if (!actionsArea) return;
  
  actionsArea.innerHTML = `
    <div class="sp-wechat-result is-warning">
      <span class="sp-wechat-result-icon">⏰</span>
      <span>二维码已过期</span>
    </div>
    <button id="sp-wechat-qr-refresh" class="sp-wechat-action-btn sp-btn-primary">
      <span class="sp-btn-icon">🔄</span>
      <span>刷新二维码</span>
    </button>
  `;
  
  const refreshBtn = document.getElementById('sp-wechat-qr-refresh');
  if (refreshBtn) refreshBtn.addEventListener('click', startQRLoginFlow);
}

async function completeQRLogin(tempUserId) {
  stopQRPolling();
  
  const statusEl = document.getElementById('sp-wechat-qr-status');
  if (statusEl) {
    statusEl.textContent = '登录成功，正在处理...';
    statusEl.className = 'sp-wechat-qr-status is-success';
  }
  
  try {
    const result = await new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: 'WECHAT_QR_COMPLETE', tempUserId }, resolve);
    });
    
    if (result?.success) {
      showToast('登录成功！');
      // 刷新状态
      await refreshWechatStatus();
    } else {
      throw new Error(result?.error || '登录失败');
    }
  } catch (err) {
    const actionsArea = document.getElementById('sp-wechat-actions-area');
    if (actionsArea) {
      actionsArea.innerHTML = `
        <div class="sp-wechat-result is-error">
          <span class="sp-wechat-result-icon">❌</span>
          <span>${escapeHtml(err.message || '登录失败')}</span>
        </div>
        <button id="sp-wechat-retry" class="sp-wechat-action-btn sp-btn-outline">
          <span class="sp-btn-icon">🔄</span>
          <span>重试</span>
        </button>
      `;
      
      const retryBtn = document.getElementById('sp-wechat-retry');
      if (retryBtn) retryBtn.addEventListener('click', startQRLoginFlow);
    }
  }
}

async function syncWechatToHotnews() {
  if (wechatSyncing) return;
  
  const syncBtn = document.getElementById('sp-wechat-sync');
  
  wechatSyncing = true;
  
  // 更新按钮状态
  if (syncBtn) {
    syncBtn.disabled = true;
    syncBtn.innerHTML = `
      <div class="sp-wechat-spinner" style="width:16px;height:16px;border-width:2px;"></div>
      <span>同步中...</span>
    `;
  }
  
  try {
    const response = await new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: 'WECHAT_SYNC_REQUEST' }, resolve);
    });
    
    if (response?.success) {
      showToast('授权同步成功！');
      // 刷新状态
      await refreshWechatStatus();
    } else if (response?.needLogin) {
      // 需要登录 hotnews - 启动 QR 登录
      startQRLoginFlow();
    } else {
      showToast(response?.error || '同步失败，请重试');
    }
  } catch (err) {
    showToast('同步失败: ' + (err.message || '未知错误'));
  } finally {
    wechatSyncing = false;
    
    // 恢复按钮状态
    if (syncBtn) {
      syncBtn.disabled = false;
      syncBtn.innerHTML = `
        <span class="sp-btn-icon">🔄</span>
        <span>同步授权到 hotnews</span>
      `;
    }
  }
}
