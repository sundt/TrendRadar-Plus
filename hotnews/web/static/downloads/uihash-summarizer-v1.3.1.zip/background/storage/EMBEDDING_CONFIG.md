# 嵌入配置说明 - 共享供应商模式

## 🎯 新的配置方式

现在嵌入功能可以直接复用您的主 AI 供应商配置，无需单独设置！

## ⚙️ 配置选项

### 1. 使用与总结相同的供应商（推荐，默认）

```javascript
{
    embeddingEnabled: true,           // 启用嵌入
    embeddingUseSameProvider: true,   // 使用与总结相同的供应商
    
    // 只需配置使用的模型名称
    embeddingModel: 'mxbai-embed-large',  // Ollama 模型
    embeddingOpenAIModel: 'text-embedding-3-small'  // OpenAI 模型
}
```

**优点**：
- ✅ 配置简单，无需重复设置
- ✅ 自动跟随主配置
- ✅ 一键切换供应商

**示例场景**：
- 如果主配置使用 **Ollama + qwen3:8b**，嵌入将使用 **Ollama + mxbai-embed-large**
- 如果主配置使用 **OpenAI + gpt-4o**，嵌入将使用 **OpenAI + text-embedding-3-small**

---

### 2. 使用单独的供应商（高级）

```javascript
{
    embeddingEnabled: true,
    embeddingUseSameProvider: false,  // 使用单独配置
    
    // 嵌入专用配置
    embeddingProvider: 'openai',      // 可以与主供应商不同
    embeddingApiKey: 'sk-your-key',   // 嵌入专用 API Key
    embeddingBaseUrl: '',              // 留空则使用默认
    embeddingModel: 'mxbai-embed-large',
    embeddingOpenAIModel: 'text-embedding-3-small'
}
```

**使用场景**：
- 💰 总结用昂贵的 GPT-4o，嵌入用便宜的 OpenAI embedding
- 🔒 总结用本地 Ollama（隐私），嵌入用云端（更快）
- ⚡ 总结用云端（质量），嵌入用本地（免费）

---

## 📊 配置对照表

| 配置 | embeddingUseSameProvider: true | embeddingUseSameProvider: false |
|------|-------------------------------|--------------------------------|
| **供应商** | 跟随主配置 | 独立配置 `embeddingProvider` |
| **API Key** | 使用主配置的 `openaiApiKey` | 使用 `embeddingApiKey` (fallback 到主配置) |
| **Base URL** | 使用主配置的 `openaiBaseUrl` | 使用 `embeddingBaseUrl` (fallback 到主配置) |
| **模型** | `embeddingModel` 或 `embeddingOpenAIModel` | 同左 |

---

## 🚀 快速配置

### 场景1：全部使用 Ollama（推荐）

```javascript
// 在选项页面设置
{
    provider: 'ollama',
    model: 'qwen3:8b',
    ollamaUrl: 'http://localhost:11434',
    
    // 嵌入配置
    embeddingEnabled: true,
    embeddingUseSameProvider: true,
    embeddingModel: 'mxbai-embed-large'
}
```

**结果**：
- 总结：Ollama + qwen3:8b
- 嵌入：Ollama + mxbai-embed-large

---

### 场景2：总结用 OpenAI，嵌入也用 OpenAI

```javascript
{
    provider: 'openai',
    model: 'gpt-4o-mini',
    openaiApiKey: 'sk-your-key',
    
    // 嵌入配置
    embeddingEnabled: true,
    embeddingUseSameProvider: true,
    embeddingOpenAIModel: 'text-embedding-3-small'
}
```

**结果**：
- 总结：OpenAI + gpt-4o-mini
- 嵌入：OpenAI + text-embedding-3-small
- API Key：共用同一个

---

### 场景3：总结用 Ollama，嵌入用 OpenAI（混合）

```javascript
{
    provider: 'ollama',
    model: 'qwen3:8b',
    
    // 嵌入单独配置
    embeddingEnabled: true,
    embeddingUseSameProvider: false,
    embeddingProvider: 'openai',
    embeddingApiKey: 'sk-your-embedding-key',
    embeddingOpenAIModel: 'text-embedding-3-small'
}
```

**结果**：
- 总结：Ollama + qwen3:8b（免费，本地）
- 嵌入：OpenAI + text-embedding-3-small（云端，付费）

---

## 🛠️ 如何修改配置

### 方法1：通过控制台（临时测试）

```javascript
// 打开扩展 background 页面控制台
const { config } = await chrome.storage.local.get(['config']);

// 使用相同供应商（推荐）
config.embeddingUseSameProvider = true;

// 或使用单独供应商
config.embeddingUseSameProvider = false;
config.embeddingProvider = 'openai';
config.embeddingApiKey = 'sk-your-key';

await chrome.storage.local.set({ config });
console.log('✅ 配置已更新');
```

### 方法2：通过选项页面（未来）

将在选项页面添加可视化配置界面。

---

## 💡 推荐配置

### 个人用户（节省成本）
```javascript
embeddingUseSameProvider: true  // 全部用 Ollama，免费
```

### 专业用户（最佳质量）
```javascript
embeddingUseSameProvider: true  // 全部用 OpenAI
embeddingOpenAIModel: 'text-embedding-3-large'  // 使用最好的嵌入模型
```

### 混合用户（平衡性能与成本）
```javascript
embeddingUseSameProvider: false
provider: 'openai'                 // 总结用 OpenAI（质量好）
embeddingProvider: 'ollama'        // 嵌入用 Ollama（免费）
```

---

## ❓ 常见问题

### Q: 默认配置是什么？
A: 默认 `embeddingUseSameProvider: true`，跟随主配置。

### Q: 我想总结用 GPT-4，嵌入用免费的 Ollama，怎么配置？
A: 
```javascript
provider: 'openai'
embeddingUseSameProvider: false
embeddingProvider: 'ollama'
```

### Q: 切换主供应商后，嵌入会自动跟随吗？
A: 如果 `embeddingUseSameProvider: true`，会自动跟随。否则使用单独配置。

### Q: 可以禁用嵌入吗？
A: 可以，设置 `embeddingEnabled: false` 即可。

---

**现在配置更简单了！大多数用户只需保持默认的共享配置即可。** 🎉
