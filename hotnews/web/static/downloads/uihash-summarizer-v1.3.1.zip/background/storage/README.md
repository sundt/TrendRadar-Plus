# Storage System Usage Guide

## 📖 Overview

The self-evolving storage system has been successfully implemented! This guide shows you how to use the new features.

## 🎯 What's New?

### 1. **Automatic Storage**
Every summary you generate is now automatically saved to IndexedDB with:
- Quality score (0-100)
- Article type classification
- Semantic vector embeddings
- Metadata (model, provider, etc.)

### 2. **Quality Scoring**
Each summary is evaluated based on:
- **Structure** (25%): Headers, lists, bold text
- **Links** (20%): Technical product links
- **Depth** (30%): Analysis depth and insights
- **Term Explanation** (15%): Glossary quality
- **Formatting** (10%): Markdown correctness

### 3. **Vector Search**
Summaries are semantically indexed using Ollama embeddings, enabling:
- Find similar summaries
- Identify patterns in high-quality content
- Power the evolution engine

## 🚀 Quick Start

### Using the Storage API

```javascript
// In the browser console or from sidepanel.js:

// Import the modules (if using ES modules)
import {
 saveSummary,
  getSummaries,
  toggleFavorite,
  getStats
} from './background/storage/db.js';

// Get all summaries
const summaries = await getSummaries({ limit: 10 });
console.log(summaries);

// Get only favorites
const favorites = await getSummaries({ favoritesOnly: true });

// Toggle favorite status
await toggleFavorite(summaryId);

// Get database statistics
const stats = await getStats();
console.log(stats); // { totalSummaries, favorites, avgScore }
```

### Quality Scoring Example

```javascript
import { calculateQualityScore } from './background/evolution/scorer.js';

const summary = "## Core Points\\n\\n- Use [Next.js](https://nextjs.org/)\\n- Deploy to [Vercel](https://vercel.com/)";
const scoreResult = calculateQualityScore(summary);

console.log(`Score: ${scoreResult.score}/100`);
console.log('Breakdown:', scoreResult.breakdown);
console.log('Suggestions:', scoreResult.suggestions);
```

### Vector Similarity Search

```javascript
import { findSimilarGoodSummaries } from './background/storage/vector_store.js';

// Find similar high-quality summaries
const similar = await findSimilarGoodSummaries(summaryId, 5);
console.log(similar);
// [{ summaryId: 123, similarity: 0.89, score: 85, title: "..." }, ...]
```

## 🔧 Integration with Existing Code

The storage system is **non-intrusive**:
- Summaries are saved automatically after generation
- If storage fails, summarization still works
- All modules are lazy-loaded (no performance impact)

To manually trigger a save:

```javascript
import { saveSummaryWithMetadata } from './background/storage/integration.js';

await saveSummaryWithMetadata({
    content: summaryText,
    originalContent: pageContent,
    pageUrl: url,
    pageTitle: title,
    articleType: type,
    promptInfo: { id: 'prompt-id', name: 'Prompt Name' },
    config: { provider: 'ollama', model: 'qwen3:8b', ollamaUrl: 'http://localhost:11434' }
});
```

##  🧪 Testing

Run the test script to verify everything works:

```bash
# Open Chrome DevTools Console on the extension background page
# Then run:
```

```javascript
// Test database
import { saveSummary, getSummaries } from './background/storage/db.js';

const testId = await saveSummary({
    url: 'https://example.com',
    title: 'Test Summary',
    type: 'tech-tutorial',
    content: '## Test\\n\\nThis is a test.',
    score: 75
});

console.log('Saved test summary:', testId);

const all = await getSummaries({ limit: 5 });
console.log('Recent summaries:', all);
```

## 🎨 Evolution Engine (Coming Soon)

The evolution engine will run periodically to:
1. Analyze top-scoring summaries
2. Identify common patterns
3. Generate improved prompts using AI
4. A/B test new prompts

To manually trigger evolution:

```javascript
import { runEvolutionCycle } from './background/evolution/evolver.js';

const config = { provider: 'ollama', model: 'qwen3:8b', ollamaUrl: 'http://localhost:11434' };
const result = await runEvolutionCycle(config, 'default-knowledge-extractor');

if (result.success) {
    console.log('Evolution complete!');
    console.log('New prompt:', result.newPrompt);
}
```

## 📊 Database Schema

### `summaries` Table
- `id`: Auto-increment primary key
- `url`: Source URL
- `title`: Page title
- `type`: Article type (tech-tutorial, news, etc.)
- `content`: Summary markdown
- `originalContent`: Original page content (truncated)
- `createdAt`: Timestamp
- `updatedAt`: Timestamp
- `score`: Quality score (0-100)
- `isFavorite`: Boolean
- `parentId`: For evolved versions
- `promptId`: Which prompt was used
- `metadata`: JSON object with additional data

### `vectors` Table
- `summaryId`: Foreign key to summaries
- `embedding`: Float32Array (as array)
- `model`: Embedding model name
- `createdAt`: Timestamp

## 🐛 Troubleshooting

### "Dexie is not defined"
Make sure you're using the CDN import in `db.js`:
```javascript
import Dexie from 'https://cdn.jsdelivr.net/npm/dexie@4.0.11/dist/modern/dexie.min.mjs';
```

### "Embedding generation failed"
- Check if Ollama is running: `curl http://localhost:11434/api/tags`
- Verify `nomic-embed-text` model is installed: `ollama pull nomic-embed-text`

### "Storage failed" errors
- Open Chrome DevTools → Application → IndexedDB
- Check if `SummarizerBrain` database exists
- Clear and recreate: `await db.delete(); await db.open();`

## 📝 Next Steps

1. **manual integration**: modify `background.js` line ~1660 to call `saveSummaryWithMetadata()`
2. **Add UI**: Create a "History" tab in the sidepanel
3. **Implement favorites**: Add a star button to summaries
4. **Evolution scheduling**: Set up Chrome alarms for weekly evolution

---

**Note**: The storage system is fully functional but requires manual integration into `background.js`. See implementation plan for detailed steps.
