# Embedding Configuration Guide - Shared Provider Mode

## 🎯 New Configuration System

We've simplified embedding configuration! You can now share your main AI provider settings for embedding, or configure them separately.

## ⚙️ Configuration Options

### 1. Shared Mode (Recommended & Default)

Uses the same provider and credentials as your summarization AI.

```javascript
{
    embeddingEnabled: true,
    embeddingUseSameProvider: true,   // ✅ Enable shared mode
    
    // Just configure the model names
    embeddingModel: 'mxbai-embed-large',         // If using Ollama
    embeddingOpenAIModel: 'text-embedding-3-small' // If using OpenAI
}
```

**How it works**:
- If you summarize with **Ollama**, embeddings use **Ollama**.
- If you summarize with **OpenAI**, embeddings use **OpenAI**.
- API Keys and URLs are automatically reused.

---

### 2. Separate Mode (Advanced)

Allows using a different provider for embeddings (e.g., GPT-4 for summary, local Ollama for embeddings).

```javascript
{
    embeddingEnabled: true,
    embeddingUseSameProvider: false,  // ❌ Disable shared mode
    
    // Dedicated embedding config
    embeddingProvider: 'ollama',      // 'ollama' | 'openai' | 'custom'
    embeddingApiKey: '',              // Optional separate key
    embeddingBaseUrl: '',              // Optional separate URL
    
    // Models
    embeddingModel: 'mxbai-embed-large',
    embeddingOpenAIModel: 'text-embedding-3-small'
}
```

### 3. 在选项页面配置 (UI 方式)

插件更新后的选项页面提供了直观的配置界面：

1.  进入 **"🧠 知识库与进化配置"** 面板。
2.  勾选 **"启用语义搜索与自动进化"**。
3.  **共享模式 (推荐)**：
    *   勾选 "使用主 AI 服务商"。
    *   插件会自动复用您在 "AI 模型配置" 中设置的 API Key 和 Base URL。
    *   嵌入模型会自动匹配（例如主模型是 OpenAI，嵌入模型默认为 `text-embedding-3-small`）。

4.  **混合模式 (高级)**：
    *   取消勾选 "使用主 AI 服务商"。
    *   **嵌入服务商**：选择 Ollama, OpenAI 或 自定义。
    *   **API 端点**：
        *   Ollama/OpenAI: 可选 (支持自动填充默认值)。
        *   自定义: **必填** (标记为红色 *)。
    *   **API Key**：
        *   Ollama: 无需。
        *   OpenAI: 可选 (默认复用主配置 Key)。
        *   自定义: **必填** (标记为红色 *)。
    *   **嵌入模型**：输入您的模型名称 (如 `mxbai-embed-large`)。
    *   **测试连接**：点击 "🔗 测试连接" 按钮，验证配置是否正确（系统会尝试生成一次嵌入向量）。

### 4. 验证配置
配置完成后，您可以在选项页面直接点击 **"🔗 测试连接"** 按钮进行验证。如果显示 "✅ 测试成功! 维度: 1536" 等信息，即表示配置成功。

### 5. 关于 URL 路径的说明
插件会自动处理 API 路径后缀：
*   **Ollama**: `http://localhost:11434` -> 自动追加 `/api/embed`
*   **OpenAI / Custom**: `https://api.openai.com/v1` -> 自动去除 `/chat/completions` (如果存在) 并追加 `/embeddings`

因此，您只需填入基础的 Base URL 即可 (例如 `https://api.openai.com/v1`)。

## 🚀 Quick Setup Examples

### Scenario A: Pure Local (Ollama)
```javascript
// Defaults work perfectly!
provider: 'ollama',
embeddingUseSameProvider: true
```

### Scenario B: Pure Cloud (OpenAI)
```javascript
provider: 'openai',
openaiApiKey: 'sk-...',
embeddingUseSameProvider: true
// Will use OpenAI for both Summary and Embeddings
```

### Scenario C: Hybrid (Cloud Summary + Local Embedding)
```javascript
provider: 'openai',           // Use OpenAI for high-quality summaries
embeddingUseSameProvider: false, 
embeddingProvider: 'ollama'   // Use Ollama for free local embeddings
```

## 🔍 How to Test

1. **Open Extension Background Console**
2. **Run Config Check**:

```javascript
const { config } = await chrome.storage.local.get(['config']);
console.log('Mode:', config.embeddingUseSameProvider ? 'SHARED' : 'SEPARATE');
console.log('Provider:', config.provider);
```

3. **Generate a Summary**
   Check the logs to see which provider is used for embeddings:
   ```
   [Storage] Using same provider as summary for embedding
   [Storage] Generating embedding using openai (text-embedding-3-small)
   ```

---

**Enjoy the flexibility!** 🚀
