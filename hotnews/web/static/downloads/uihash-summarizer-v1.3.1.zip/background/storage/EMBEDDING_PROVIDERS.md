# Embedding Provider Configuration Guide

## 🎯 Overview

The storage system now supports **multiple embedding providers**, allowing you to choose between:
- **Ollama** (local, free, privacy-preserving)
- **OpenAI** (cloud, high quality, requires API key)
- **Custom API** (any OpenAI-compatible service)

## ⚙️ Configuration

All embedding settings are in the `config` object. You can modify them via the extension settings UI or directly in code.

### Default Configuration

```javascript
{
    // Embedding provider selection
    embeddingProvider: 'ollama',  // 'ollama' | 'openai' | 'custom'
    
    // Ollama settings
    embeddingModel: 'mxbai-embed-large',  // Ollama model name
    
    // OpenAI settings
    embeddingOpenAIModel: 'text-embedding-3-small',  // OpenAI model
    embeddingApiKey: '',  // API key (optional, uses openaiApiKey if empty)
    embeddingBaseUrl: '',  // Custom API URL (optional, uses openaiBaseUrl if empty)
    
    // General
    embeddingEnabled: true  // Toggle embedding generation
}
```

## 🚀 Quick Setup

### Option 1: Use Ollama (Recommended for Privacy)

1. **Install Ollama**: https://ollama.ai
2. **Pull a model**:
   ```bash
   ollama pull mxbai-embed-large
   ```
3. **Configure** (already default):
   ```javascript
   embeddingProvider: 'ollama'
   embeddingModel: 'mxbai-embed-large'
   ```

### Option 2: Use OpenAI

1. **Get API key**: https://platform.openai.com/api-keys
2. **Configure**:
   ```javascript
   embeddingProvider: 'openai'
   embeddingOpenAIModel: 'text-embedding-3-small'
   embeddingApiKey: 'sk-your-api-key-here'
   ```

### Option 3: Use Custom API (e.g., Azure, Cloudflare AI)

For any OpenAI-compatible API:

```javascript
embeddingProvider: 'custom'
embeddingModel: 'your-model-name'
embeddingApiKey: 'your-api-key'
embeddingBaseUrl: 'https://your-api.com/v1'
```

## 📊 Provider Comparison

| Feature | Ollama | OpenAI | Custom |
|---------|--------|--------|--------|
| **Cost** | Free | ~$0.0001/1k tokens | Varies |
| **Privacy** | 100% local | Cloud | Depends |
| **Setup** | One-time install | API key | API key + URL |
| **Speed** | Fast (local) | Fast (API) | Varies |
| **Quality** | Excellent | Excellent | Depends |

## 🔧 How to Change Settings

### Method 1: Via Code (Temporary)

Edit `background/config/defaults.js`:

```javascript
const DEFAULT_CONFIG = {
    // ... other settings ...
    
    // Switch to OpenAI
    embeddingProvider: 'openai',
    embeddingOpenAIModel: 'text-embedding-3-large',
    embeddingApiKey: 'sk-your-key-here'
};
```

### Method 2: Via Chrome Storage (Persistent)

In the extension background console:

```javascript
// Get current config
const { config } = await chrome.storage.local.get(['config']);

// Update embedding settings
config.embeddingProvider = 'openai';
config.embeddingOpenAIModel = 'text-embedding-3-small';
config.embeddingApiKey = 'sk-your-key-here';

// Save
await chrome.storage.local.set({ config });
console.log('✅ Embedding settings updated!');
```

### Method 3: Via Settings UI (Future Enhancement)

A settings UI for embedding configuration will be added in a future update.

## 🎨 Recommended Models

### For Ollama

| Model | Size | Dimensions | Best For |
|-------|------|------------|----------|
| `mxbai-embed-large` | 1.5GB | 1024 | Best quality |
| `bge-m3` | 2.2GB | 1024 | Multilingual |
| `nomic-embed-text` | 274MB | 768 | Balanced |
| `all-minilm` | 46MB | 384 | Lightweight |

```bash
# Install
ollama pull mxbai-embed-large
```

### For OpenAI

| Model | Price/1M tokens | Dimensions | Best For |
|-------|----------------|------------|----------|
| `text-embedding-3-small` | $0.02 | 1536 | Cost-effective |
| `text-embedding-3-large` | $0.13 | 3072 | Best quality |
| `text-embedding-ada-002` | $0.10 | 1536 | Legacy |

## 🧪 Testing Your Configuration

Run this in the extension background console:

```javascript
// Import the function
const { generateEmbedding } = await import('./background/storage/vector_store.js');

// Get current config
const { config } = await chrome.storage.local.get(['config']);

// Build embedding config
const embeddingConfig = {
    provider: config.embeddingProvider || 'ollama',
    ollamaUrl: config.ollamaUrl,
    model: config.embeddingProvider === 'openai' 
        ? config.embeddingOpenAIModel 
        : config.embeddingModel,
    apiKey: config.embeddingApiKey || config.openaiApiKey,
    baseUrl: config.embeddingBaseUrl || config.openaiBaseUrl
};

// Test embedding generation
const testText = "This is a test embedding";
const embedding = await generateEmbedding(testText, embeddingConfig);

if (embedding) {
    console.log(`✅ Embedding generated successfully!`);
    console.log(`   Provider: ${embeddingConfig.provider}`);
    console.log(`   Model: ${embeddingConfig.model}`);
    console.log(`   Dimensions: ${embedding.length}`);
} else {
    console.error('❌ Embedding generation failed');
}
```

## 💰 Cost Estimation (OpenAI)

Assuming average summary length of 500 tokens:

| Summaries/Month | Model | Cost/Month |
|-----------------|-------|------------|
| 100 | text-embedding-3-small | $0.001 |
| 1,000 | text-embedding-3-small | $0.01 |
| 10,000 | text-embedding-3-small | $0.10 |
| 100 | text-embedding-3-large | $0.0065 |
| 1,000 | text-embedding-3-large | $0.065 |

**Verdict**: Even for heavy users, OpenAI embeddings are very affordable!

## 🔒 Security Best Practices

1. **Never commit API keys** to version control
2. **Use environment variables** or secure storage
3. **Rotate keys** periodically
4. **Use separate keys** for development and production

## ❓ FAQ

### Q: Can I switch providers without losing data?
**A**: Yes! Each embedding stores which model was used. However, embeddings from different providers **cannot be compared**.

### Q: Which provider should I use?
**A**: 
- **Ollama**: Best for privacy, free, great quality
- **OpenAI**: Best if you already use OpenAI, very affordable, no local setup

### Q: Can I disable embeddings completely?
**A**: Yes! Set `embeddingEnabled: false` in config.

### Q: What happens if embedding fails?
**A**: The summary is still saved successfully. Embeddings are optional and don't block the main workflow.

## 🚀 Next Steps

1. Choose your provider
2. Configure settings (see above)
3. Reload the extension
4. Generate a summary - embedding will be created automatically!

Check the console for logs like:
```
[Storage] Generating embedding using openai (text-embedding-3-small)
[Storage] Generated embedding for summary #1 (dim=1536)
```

---

**You now have full flexibility to use any embedding provider you prefer!** 🎉
