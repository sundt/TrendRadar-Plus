# 嵌入模型选择指南

## 🎯 快速选择

根据您的需求选择合适的模型：

| 需求 | 推荐模型 | 大小 | 安装命令 |
|------|---------|------|----------|
| 🚀 **最佳质量** | `mxbai-embed-large` | 1.5GB | `ollama pull mxbai-embed-large` |
| 🌏 **中英文混合** | `bge-m3` | 2.2GB | `ollama pull bge-m3` |
| ⚡ **速度优先** | `all-minilm` | 46MB | `ollama pull all-minilm` |
| 💾 **平衡** | `nomic-embed-text` | 274MB | `ollama pull nomic-embed-text` |
| 🔍 **检索优化** | `snowflake-arctic-embed` | 669MB | `ollama pull snowflake-arctic-embed` |

## 📊 详细对比

### 1. mxbai-embed-large ⭐ (当前默认)
```bash
ollama pull mxbai-embed-large
```
- **维度**: 1024
- **大小**: 1.5GB
- **优点**:
  - ✅ 质量最高，OpenAI 兼容
  - ✅ MTEB 排行榜领先
  - ✅ 适合生产环境
- **缺点**:
  - ❌ 文件较大
  - ❌ 速度中等

**适合**：追求最佳质量，不在乎文件大小

---

### 2. bge-m3 (多语言之王)
```bash
ollama pull bge-m3
```
- **维度**: 1024
- **大小**: 2.2GB
- **优点**:
  - ✅ 多语言支持
  - ✅ 中文表现优秀
  - ✅ 支持混合检索（稠密+稀疏+多向量）
- **缺点**:
  - ❌ 文件最大
  - ❌ 速度较慢

**适合**：中文内容为主，或需要多语言混合搜索

---

### 3. all-minilm (轻量之选)
```bash
ollama pull all-minilm
```
- **维度**: 384
- **大小**: 46MB
- **优点**:
  - ✅ 极小的文件体积
  - ✅ 速度最快
  - ✅ 下载和加载迅速
- **缺点**:
  - ❌ 质量略低
  - ❌ 维度较低

**适合**：个人使用，对质量要求不高，重视速度

---

### 4. nomic-embed-text (原默认模型)
```bash
ollama pull nomic-embed-text
```
- **维度**: 768
- **大小**: 274MB
- **优点**:
  - ✅ 质量与大小平衡
  - ✅ 开源且活跃维护
  - ✅ 速度较快
- **缺点**:
  - ❌ 质量不如 mxbai-embed-large

**适合**：不想下载大文件，但需要不错的质量

---

### 5. snowflake-arctic-embed
```bash
ollama pull snowflake-arctic-embed
```
- **维度**: 1024
- **大小**: 669MB
- **优点**:
  - ✅ 专为检索优化
  - ✅ 大小适中
  - ✅ 质量优秀
- **缺点**:
  - ❌ 没有特别突出的优势

**适合**：语义搜索场景，平衡质量和大小

---

## 🔧 如何更换模型

### 方法1：编辑配置文件（推荐）

打开 `background/storage/vector_store.js`，修改第 18 行：

```javascript
// 将这一行改成你想要的模型
const DEFAULT_EMBEDDING_MODEL = 'bge-m3';  // 例如换成 bge-m3
```

### 方法2：不修改代码，安装默认模型

```bash
# 安装当前默认的 mxbai-embed-large
ollama pull mxbai-embed-large
```

---

## 🧪 测试模型

安装后测试一下模型是否工作：

```bash
# 检查模型是否安装
ollama list

# 测试生成嵌入
curl http://localhost:11434/api/embed -d '{
  "model": "mxbai-embed-large",
  "input": "测试文本"
}'
```

如果返回一个向量数组，说明模型运行正常！

---

## 💡 我的推荐

### 对于您的场景（技术文章总结）

**推荐使用 `mxbai-embed-large`**（已设为默认）：
- ✅ 质量最高，能更准确地捕捉技术内容的语义
- ✅ 1.5GB 大小可接受（现代计算机都能轻松运行）
- ✅ 未来如果需要进化功能，高质量嵌入会更有帮助

### 如果您经常处理中文内容

**推荐使用 `bge-m3`**：
```javascript
const DEFAULT_EMBEDDING_MODEL = 'bge-m3';
```

### 如果只是想快速测试

**推荐使用 `all-minilm`**：
```javascript
const DEFAULT_EMBEDDING_MODEL = 'all-minilm';
```

---

## ❓ 常见问题

### Q: 更换模型后，旧的嵌入怎么办？
A: 数据库会记录每个嵌入使用的模型。不同模型的嵌入**不能直接比较**，但不影响已有数据。

### Q: 可以同时使用多个模型吗？
A: 理论上可以，但需要额外开发。当前只支持一个默认模型。

### Q: 模型文件存在哪里？
A: Ollama 默认存储在：
- macOS: `~/.ollama/models`
- Linux: `/usr/share/ollama/.ollama/models`
- Windows: `C:\Users\<用户名>\.ollama\models`

---

## 🚀 快速开始

1. **选择模型**（见上方表格）
2. **安装模型**：
   ```bash
   ollama pull mxbai-embed-large
   ```
3. **重新加载扩展**
4. **生成一个总结** - 嵌入会自动生成！

现在向量嵌入错误应该会消失，而且您可以随时换成任何您喜欢的模型！
