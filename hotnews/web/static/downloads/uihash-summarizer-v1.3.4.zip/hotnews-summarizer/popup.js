// Custom Summarizer - Popup Script

async function init() {
  const response = await chrome.runtime.sendMessage({ type: 'GET_CONFIG' });
  const { config, prompts } = response;
  
  // 显示当前模型
  document.getElementById('current-model').textContent = config.model || '未设置';
  
  // 显示当前提示词
  const activePrompt = prompts.find(p => p.id === config.activePromptId);
  document.getElementById('current-prompt').textContent = activePrompt?.name || '默认';
  
  // 检查连接状态
  if (config.provider === 'ollama') {
    const result = await chrome.runtime.sendMessage({ 
      type: 'TEST_OLLAMA', 
      url: config.ollamaUrl 
    });
    
    const statusEl = document.getElementById('connection-status');
    if (result.success) {
      statusEl.textContent = '✅ 已连接';
      statusEl.classList.add('success');
    } else {
      statusEl.textContent = '❌ 未连接';
      statusEl.classList.add('error');
    }
  } else {
    document.getElementById('connection-status').textContent = 
      config.openaiApiKey ? '✅ API Key 已配置' : '⚠️ 未配置 API Key';
  }
}

// 打开侧边栏（主要按钮）
document.getElementById('open-sidepanel').addEventListener('click', async () => {
  // 获取当前窗口并打开侧边栏
  const currentWindow = await chrome.windows.getCurrent();
  await chrome.sidePanel.open({ windowId: currentWindow.id });
  window.close();
});

// 总结当前页面（打开侧边栏并自动总结）
document.getElementById('summarize-current').addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  
  if (tab.url.startsWith('chrome://') || tab.url.startsWith('edge://')) {
    alert('无法在浏览器内部页面使用');
    return;
  }
  
  // 标记待处理任务
  await chrome.storage.local.set({ pendingTask: { type: 'summarize' } });
  
  // 打开侧边栏
  const currentWindow = await chrome.windows.getCurrent();
  await chrome.sidePanel.open({ windowId: currentWindow.id });
  window.close();
});

// 打开设置页面
document.getElementById('open-options').addEventListener('click', () => {
  chrome.runtime.openOptionsPage();
});

init();
