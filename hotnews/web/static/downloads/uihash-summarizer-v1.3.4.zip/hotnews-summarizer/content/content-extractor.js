// Content Extractor - 页面内容提取模块
// 用于从当前页面提取正文内容，支持内容反哺功能

(function() {
  'use strict';

  // 避免重复注入
  if (window.__contentExtractorInjected) return;
  window.__contentExtractorInjected = true;

  // ============ 敏感页面过滤 ============
  const SENSITIVE_PATTERNS = [
    /mail\./i,
    /bank\./i,
    /pay\./i,
    /login\./i,
    /account\./i,
    /password/i,
    /alipay\.com/i,
    /weixin\.qq\.com\/cgi-bin/i,  // 微信后台
    /console\./i,                  // 云控制台
    /admin\./i,
    /signin/i,
    /signup/i,
    /checkout/i,
    /payment/i,
    /billing/i,
    /wallet/i,
    /transfer/i,
    /wechatpay/i,
    /tenpay/i,
    /unionpay/i
  ];

  /**
   * 检查是否为敏感页面
   * @param {string} url - 页面 URL
   * @returns {boolean} 是否为敏感页面
   */
  function isSensitivePage(url) {
    return SENSITIVE_PATTERNS.some(pattern => pattern.test(url));
  }

  // ============ 简化版 Readability 实现 ============
  
  /**
   * 移除不需要的元素
   * @param {Document} doc - 文档对象
   */
  function removeUnwantedElements(doc) {
    const removeSelectors = [
      'script', 'style', 'noscript', 'iframe', 'nav', 'header', 'footer',
      'aside', '.sidebar', '.nav', '.navigation', '.menu', '.ad', '.ads',
      '.advertisement', '.comment', '.comments', '#comments', '.social',
      '.share', '.related', '[role="navigation"]', '[role="banner"]',
      '[role="complementary"]', '.cookie', '.popup', '.modal', '.overlay',
      '.newsletter', '.subscribe', '.subscription', '.promo', '.promotion',
      '.sponsor', '.sponsored', '.widget', '.breadcrumb', '.pagination',
      '.author-bio', '.author-info', '.tags', '.tag-list', '.category',
      '.meta', '.post-meta', '.entry-meta', '.byline', '.dateline',
      '[aria-hidden="true"]', '[hidden]', '.hidden', '.hide',
      '.toc', '.table-of-contents', '#toc', '.outline'
    ];
    
    removeSelectors.forEach(selector => {
      try {
        doc.querySelectorAll(selector).forEach(el => el.remove());
      } catch (e) {
        // 忽略选择器错误
      }
    });
  }

  /**
   * 计算元素的文本密度得分
   * @param {Element} element - DOM 元素
   * @returns {number} 文本密度得分
   */
  function calculateTextDensity(element) {
    const text = element.textContent || '';
    const textLength = text.trim().length;
    const linkLength = Array.from(element.querySelectorAll('a'))
      .reduce((sum, a) => sum + (a.textContent || '').length, 0);
    
    // 文本密度 = (总文本长度 - 链接文本长度) / 总文本长度
    if (textLength === 0) return 0;
    return (textLength - linkLength) / textLength;
  }

  /**
   * 查找主要内容区域
   * @param {Document} doc - 文档对象
   * @returns {Element|null} 主要内容元素
   */
  function findMainContent(doc) {
    // 优先级从高到低的内容选择器
    const contentSelectors = [
      'article[role="main"]',
      'main article',
      'article',
      '[role="main"]',
      'main',
      '.post-content',
      '.article-content',
      '.entry-content',
      '.content-body',
      '.post-body',
      '.article-body',
      '.story-body',
      '.rich_media_content',  // 微信公众号
      '#js_content',          // 微信公众号
      '.content',
      '#content',
      '.post',
      '.article',
      '.story'
    ];
    
    for (const selector of contentSelectors) {
      try {
        const element = doc.querySelector(selector);
        if (element) {
          const text = element.textContent || '';
          // 确保内容足够长
          if (text.trim().length > 200) {
            return element;
          }
        }
      } catch (e) {
        // 忽略选择器错误
      }
    }
    
    // 如果没找到，尝试通过文本密度找到最佳候选
    const candidates = doc.querySelectorAll('div, section');
    let bestCandidate = null;
    let bestScore = 0;
    
    candidates.forEach(candidate => {
      const text = candidate.textContent || '';
      const textLength = text.trim().length;
      
      // 跳过太短的内容
      if (textLength < 200) return;
      
      const density = calculateTextDensity(candidate);
      const paragraphs = candidate.querySelectorAll('p').length;
      
      // 综合得分 = 文本长度 * 文本密度 * (段落数 + 1)
      const score = textLength * density * (paragraphs + 1);
      
      if (score > bestScore) {
        bestScore = score;
        bestCandidate = candidate;
      }
    });
    
    return bestCandidate;
  }

  /**
   * 提取文本内容
   * @param {Element} element - DOM 元素
   * @returns {string} 提取的文本
   */
  function extractText(element) {
    let text = '';
    const walker = document.createTreeWalker(
      element,
      NodeFilter.SHOW_TEXT,
      null,
      false
    );
    
    let node;
    while (node = walker.nextNode()) {
      const trimmed = node.textContent.trim();
      if (trimmed.length > 0) {
        text += trimmed + '\n';
      }
    }
    
    // 清理多余空行
    text = text.replace(/\n{3,}/g, '\n\n').trim();
    
    return text;
  }

  /**
   * 提取页面内容（主函数）
   * @returns {Object} 提取结果 { title, content, url, excerpt }
   */
  function extractPageContent() {
    const url = window.location.href;
    
    // 检查敏感页面
    if (isSensitivePage(url)) {
      console.log('[ContentExtractor] Sensitive page detected, skipping extraction');
      return {
        title: document.title,
        content: '',
        url: url,
        excerpt: '',
        isSensitive: true
      };
    }
    
    try {
      // 克隆文档以避免修改原始 DOM
      const docClone = document.cloneNode(true);
      
      // 移除不需要的元素
      removeUnwantedElements(docClone);
      
      // 查找主要内容区域
      let mainContent = findMainContent(docClone);
      
      // 如果没找到，使用 body
      if (!mainContent) {
        mainContent = docClone.body;
      }
      
      // 提取文本
      const content = extractText(mainContent);
      
      // 生成摘要（前 200 字）
      const excerpt = content.substring(0, 200).replace(/\n/g, ' ').trim();
      
      // 限制内容长度（最多 50000 字符）
      const truncatedContent = content.length > 50000 
        ? content.substring(0, 50000) + '\n\n[内容已截断...]'
        : content;
      
      console.log('[ContentExtractor] Extracted content length:', truncatedContent.length);
      
      return {
        title: document.title,
        content: truncatedContent,
        url: url,
        excerpt: excerpt,
        isSensitive: false
      };
    } catch (error) {
      console.error('[ContentExtractor] Extraction failed:', error);
      return {
        title: document.title,
        content: '',
        url: url,
        excerpt: '',
        error: error.message
      };
    }
  }

  // ============ 消息监听 ============
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'EXTRACT_CONTENT') {
      const result = extractPageContent();
      sendResponse(result);
      return true;
    }
  });

  // 导出函数供其他脚本使用
  window.__extractPageContent = extractPageContent;
  window.__isSensitivePage = isSensitivePage;

})();
