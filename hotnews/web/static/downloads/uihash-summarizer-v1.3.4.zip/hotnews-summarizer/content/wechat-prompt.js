/**
 * WeChat MP Login Detection & Sync Prompt
 * 
 * Automatically detects when user logs into WeChat MP backend
 * and shows a prompt to sync credentials to hotnews.
 * 
 * Trigger frequency:
 * - After successful sync: 24 hours cooldown
 * - After clicking "稍后": 2 hours cooldown (session-based)
 * - After clicking "不再提示": Never show again
 */

(function() {
  'use strict';

  const PROMPT_ID = 'hotnews-wechat-sync-prompt';
  const CHECK_DELAY = 2000; // Wait 2s for page to fully load
  const SYNC_COOLDOWN = 24 * 60 * 60 * 1000; // 24 hours after successful sync
  const LATER_COOLDOWN = 2 * 60 * 60 * 1000; // 2 hours after clicking "稍后"

  /**
   * Check if user is logged into WeChat MP backend
   */
  function isLoggedIn() {
    const url = window.location.href;
    
    // Method 1: URL-based detection
    if (url.includes('/cgi-bin/home') || 
        url.includes('/cgi-bin/appmsg') ||
        url.includes('/cgi-bin/message')) {
      return true;
    }
    
    // Method 2: Element-based detection
    const userInfo = document.querySelector('.weui-desktop-account__nickname');
    if (userInfo) return true;
    
    // Method 3: Check for logged-in specific elements
    const menuItems = document.querySelectorAll('.weui-desktop-menu__item');
    if (menuItems.length > 3) return true;
    
    return false;
  }

  /**
   * Create and show the sync prompt bar
   */
  function showSyncPrompt() {
    // Don't show if already exists
    if (document.getElementById(PROMPT_ID)) return;

    const prompt = document.createElement('div');
    prompt.id = PROMPT_ID;
    prompt.className = 'hotnews-prompt';
    prompt.innerHTML = `
      <div class="hotnews-prompt-content">
        <span class="hotnews-prompt-icon">🔔</span>
        <span class="hotnews-prompt-text">检测到公众号登录态，是否同步到 hotnews？</span>
        <button class="hotnews-prompt-btn primary" id="hotnews-sync-btn">同步</button>
        <button class="hotnews-prompt-btn secondary" id="hotnews-later-btn">稍后</button>
        <button class="hotnews-prompt-btn secondary" id="hotnews-never-btn">不再提示</button>
      </div>
    `;

    document.body.prepend(prompt);

    // Bind events
    document.getElementById('hotnews-sync-btn').addEventListener('click', handleSync);
    document.getElementById('hotnews-later-btn').addEventListener('click', handleLater);
    document.getElementById('hotnews-never-btn').addEventListener('click', handleNeverShow);
  }

  /**
   * Hide the prompt bar
   */
  function hidePrompt() {
    const prompt = document.getElementById(PROMPT_ID);
    if (prompt) {
      prompt.classList.add('hiding');
      setTimeout(() => prompt.remove(), 300);
    }
  }

  /**
   * Handle "稍后" button - set a 2-hour cooldown
   */
  function handleLater() {
    chrome.storage.local.set({ lastWechatLaterTime: Date.now() });
    hidePrompt();
  }

  /**
   * Show success message
   */
  function showSuccess() {
    const prompt = document.getElementById(PROMPT_ID);
    if (prompt) {
      prompt.className = 'hotnews-prompt success';
      prompt.innerHTML = `
        <div class="hotnews-prompt-content">
          <span class="hotnews-prompt-icon">✅</span>
          <span class="hotnews-prompt-text">同步成功！hotnews 将自动抓取您的公众号文章</span>
          <button class="hotnews-prompt-btn primary" id="hotnews-view-btn">查看详情</button>
        </div>
      `;
      
      document.getElementById('hotnews-view-btn').addEventListener('click', () => {
        window.open('https://hot.uihash.com/wechat', '_blank');
        hidePrompt();
      });

      // Auto hide after 5 seconds
      setTimeout(hidePrompt, 5000);
    }
  }

  /**
   * Show error message
   */
  function showError(message) {
    const prompt = document.getElementById(PROMPT_ID);
    if (prompt) {
      prompt.className = 'hotnews-prompt error';
      prompt.innerHTML = `
        <div class="hotnews-prompt-content">
          <span class="hotnews-prompt-icon">❌</span>
          <span class="hotnews-prompt-text">${message}</span>
          <button class="hotnews-prompt-btn primary" id="hotnews-retry-btn">重试</button>
          <button class="hotnews-prompt-btn secondary" id="hotnews-close-btn">关闭</button>
        </div>
      `;
      
      document.getElementById('hotnews-retry-btn').addEventListener('click', handleSync);
      document.getElementById('hotnews-close-btn').addEventListener('click', hidePrompt);
    }
  }

  /**
   * Show login required message
   */
  function showLoginRequired() {
    const prompt = document.getElementById(PROMPT_ID);
    if (prompt) {
      prompt.className = 'hotnews-prompt login';
      prompt.innerHTML = `
        <div class="hotnews-prompt-content">
          <span class="hotnews-prompt-icon">🔐</span>
          <span class="hotnews-prompt-text">请先登录 hotnews 账号</span>
          <button class="hotnews-prompt-btn primary" id="hotnews-login-btn">登录 hotnews</button>
          <button class="hotnews-prompt-btn secondary" id="hotnews-cancel-btn">取消</button>
        </div>
      `;
      
      document.getElementById('hotnews-login-btn').addEventListener('click', () => {
        // Send message to background to open login
        chrome.runtime.sendMessage({ 
          type: 'WECHAT_OPEN_HOTNEWS_LOGIN' 
        });
      });
      document.getElementById('hotnews-cancel-btn').addEventListener('click', hidePrompt);
    }
  }

  /**
   * Handle sync button click
   */
  async function handleSync() {
    const btn = document.getElementById('hotnews-sync-btn');
    if (btn) {
      btn.disabled = true;
      btn.textContent = '同步中...';
    }

    try {
      // Send message to background script to handle sync
      const response = await chrome.runtime.sendMessage({ 
        type: 'WECHAT_SYNC_REQUEST' 
      });

      if (response.success) {
        // Record sync time
        chrome.storage.local.set({ lastWechatSyncTime: Date.now() });
        showSuccess();
      } else if (response.needLogin) {
        showLoginRequired();
      } else {
        showError(response.error || '同步失败，请稍后重试');
      }
    } catch (error) {
      console.error('Sync error:', error);
      showError('同步失败：' + error.message);
    }
  }

  /**
   * Handle "never show" button click
   */
  function handleNeverShow() {
    chrome.storage.local.set({ wechatSyncDismissed: true });
    hidePrompt();
  }

  /**
   * Check if should show prompt
   */
  async function shouldShowPrompt() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['wechatSyncDismissed', 'lastWechatSyncTime', 'lastWechatLaterTime'], (data) => {
        // User chose "never show"
        if (data.wechatSyncDismissed) {
          resolve(false);
          return;
        }

        const now = Date.now();

        // Already synced within cooldown period (24 hours)
        const lastSync = data.lastWechatSyncTime || 0;
        if (now - lastSync < SYNC_COOLDOWN) {
          resolve(false);
          return;
        }

        // User clicked "稍后" within cooldown period (2 hours)
        const lastLater = data.lastWechatLaterTime || 0;
        if (now - lastLater < LATER_COOLDOWN) {
          resolve(false);
          return;
        }

        resolve(true);
      });
    });
  }

  /**
   * Initialize detection
   */
  async function init() {
    // Only run on WeChat MP domain
    if (window.location.hostname !== 'mp.weixin.qq.com') return;

    // Wait for page to load
    await new Promise(resolve => setTimeout(resolve, CHECK_DELAY));

    // Check if logged in
    if (!isLoggedIn()) return;

    // Check if should show prompt
    const shouldShow = await shouldShowPrompt();
    if (!shouldShow) return;

    // Show the prompt
    showSyncPrompt();
  }

  // Run on page load
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // Also check on URL changes (SPA navigation)
  let lastUrl = location.href;
  new MutationObserver(() => {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      setTimeout(init, CHECK_DELAY);
    }
  }).observe(document, { subtree: true, childList: true });

})();
