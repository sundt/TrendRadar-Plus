#!/bin/bash
# uihash 总结助手 - 打包脚本

VERSION=$(grep '"version"' manifest.json | sed 's/.*: "\(.*\)".*/\1/')
OUTPUT_NAME="uihash-summarizer-v${VERSION}.zip"

echo "📦 打包 uihash 总结助手 v${VERSION}..."

# 删除旧的打包文件
rm -f "../${OUTPUT_NAME}"

# 创建 zip，排除开发文件
zip -r "../${OUTPUT_NAME}" . \
  -x "*.DS_Store" \
  -x "build.sh" \
  -x "*.md" \
  -x "*-preview.html" \
  -x "test-*.html" \
  -x "sidepanel-rendermarkdown-new.js" \
  -x "content/content-extractor.js" \
  -x "icons/*.svg" \
  -x ".git/*" \
  -x ".vscode/*" \
  -x ".claude/*" \
  -x ".agent/*" \
  -x ".kilocode/*" \
  -x ".windsurf/*" \
  -x ".venv/*" \
  -x "node_modules/*" \
  -x "openspec/*" \
  -x "reports/*" \
  -x "scripts/*" \
  -x "skills/*" \
  -x "docs/*" \
  -x "design-outputs/*" \
  -x "store/*"

echo "✅ 打包完成: ../${OUTPUT_NAME}"
echo ""
echo "📋 包含文件:"
unzip -l "../${OUTPUT_NAME}"
echo ""
ls -lh "../${OUTPUT_NAME}"
