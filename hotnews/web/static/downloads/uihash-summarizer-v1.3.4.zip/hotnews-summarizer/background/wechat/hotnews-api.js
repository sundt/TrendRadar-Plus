/**
 * hotnews API Client
 * 
 * Handles communication with hotnews backend for WeChat credential sync.
 */

const DEFAULT_SERVER = 'https://hot.uihash.com';

/**
 * Get configured server URL
 * @returns {Promise<string>}
 */
export async function getServerUrl() {
  const { hotnewsServer } = await chrome.storage.local.get('hotnewsServer');
  return hotnewsServer || DEFAULT_SERVER;
}

/**
 * Get stored auth token
 * @returns {Promise<string|null>}
 */
export async function getAuthToken() {
  const { hotnewsToken } = await chrome.storage.local.get('hotnewsToken');
  return hotnewsToken || null;
}

/**
 * Save auth token
 * @param {string} token 
 */
export async function saveAuthToken(token) {
  await chrome.storage.local.set({ hotnewsToken: token });
}

/**
 * Clear auth token
 */
export async function clearAuthToken() {
  await chrome.storage.local.remove('hotnewsToken');
}

/**
 * Check if user is logged into hotnews
 * @returns {Promise<{loggedIn: boolean, user: object|null}>}
 */
export async function checkHotnewsLogin() {
  const serverUrl = await getServerUrl();
  const token = await getAuthToken();
  
  if (!token) {
    return { loggedIn: false, user: null };
  }
  
  try {
    const response = await fetch(`${serverUrl}/api/user/me`, {
      headers: { 
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });
    
    if (response.ok) {
      const user = await response.json();
      return { loggedIn: true, user };
    }
    
    // Token expired or invalid
    if (response.status === 401) {
      await clearAuthToken();
    }
    
    return { loggedIn: false, user: null };
  } catch (error) {
    console.error('Check hotnews login error:', error);
    return { loggedIn: false, user: null };
  }
}

/**
 * Sync WeChat credentials to hotnews
 * @param {string} cookieStr - WeChat MP cookie string
 * @returns {Promise<{success: boolean, needLogin?: boolean, error?: string, data?: object}>}
 */
export async function syncWechatCredentials(cookieStr) {
  const serverUrl = await getServerUrl();
  const token = await getAuthToken();
  
  // Check if logged in
  if (!token) {
    return { success: false, needLogin: true };
  }
  
  try {
    const response = await fetch(`${serverUrl}/api/wechat/auth/plugin`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ credentials: cookieStr })
    });
    
    // Token expired
    if (response.status === 401) {
      await clearAuthToken();
      return { success: false, needLogin: true };
    }
    
    const data = await response.json();
    
    if (response.ok) {
      return { success: true, data };
    }
    
    return { 
      success: false, 
      error: data.detail || data.message || '同步失败'
    };
  } catch (error) {
    console.error('Sync wechat credentials error:', error);
    return { 
      success: false, 
      error: error.message || '网络错误，请稍后重试'
    };
  }
}

/**
 * Get WeChat auth status from hotnews
 * @returns {Promise<{authorized: boolean, valid?: boolean, lastSync?: number}>}
 */
export async function getWechatAuthStatus() {
  const serverUrl = await getServerUrl();
  const token = await getAuthToken();
  
  if (!token) {
    return { authorized: false };
  }
  
  try {
    const response = await fetch(`${serverUrl}/api/wechat/auth/status`, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });
    
    if (response.ok) {
      const data = await response.json();
      return {
        authorized: data.status === 'valid',
        status: data.status,
        expiresAt: data.expires_at,
        updatedAt: data.updated_at,
        expireSoon: data.expires_at && (data.expires_at - Date.now() / 1000) < 3600,
      };
    }
    
    return { authorized: false };
  } catch (error) {
    console.error('Get wechat auth status error:', error);
    return { authorized: false };
  }
}

/**
 * Open hotnews login page
 */
export async function openHotnewsLogin() {
  const serverUrl = await getServerUrl();
  
  // Open hotnews in a new tab - user will login there
  // After login, they can use the "Get Token" feature to copy their token
  const loginUrl = `${serverUrl}/login`;
  
  // Open in new tab
  await chrome.tabs.create({ url: loginUrl });
}

/**
 * Try to get token from hotnews if user is logged in there
 * This works by making a request to /api/auth/token which returns
 * the session token if the user has a valid session cookie
 */
export async function tryGetTokenFromHotnews() {
  const serverUrl = await getServerUrl();
  
  try {
    // This request will include cookies if user is logged in on hotnews
    const response = await fetch(`${serverUrl}/api/auth/token`, {
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json'
      }
    });
    
    if (!response.ok) {
      return { success: false };
    }
    
    const data = await response.json();
    
    if (data.ok && data.token) {
      // Save the token
      await saveAuthToken(data.token);
      return { success: true, user: data.user };
    }
    
    return { success: false };
  } catch (error) {
    console.error('Failed to get token from hotnews:', error);
    return { success: false };
  }
}


// ==================== QR Login API ====================

/**
 * Start QR login session
 * @returns {Promise<{success: boolean, sessionId?: string, tempUserId?: number, error?: string}>}
 */
export async function startQRLogin() {
  const serverUrl = await getServerUrl();
  
  try {
    const response = await fetch(`${serverUrl}/api/auth/qr/start`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      }
    });
    
    const data = await response.json();
    
    if (data.ok) {
      return {
        success: true,
        sessionId: data.session_id,
        tempUserId: data.temp_user_id,
      };
    }
    
    return { success: false, error: data.error || '创建登录会话失败' };
  } catch (error) {
    console.error('Start QR login error:', error);
    return { success: false, error: error.message || '网络错误' };
  }
}

/**
 * Get QR code image URL
 * @param {number} tempUserId 
 * @returns {string}
 */
export async function getQRCodeUrl(tempUserId) {
  const serverUrl = await getServerUrl();
  return `${serverUrl}/api/auth/qr/image/${tempUserId}?t=${Date.now()}`;
}

/**
 * Check QR login scan status
 * @param {number} tempUserId 
 * @returns {Promise<{ok: boolean, status: string, message: string, needRefresh: boolean}>}
 */
export async function checkQRStatus(tempUserId) {
  const serverUrl = await getServerUrl();
  
  try {
    const response = await fetch(`${serverUrl}/api/auth/qr/status/${tempUserId}`, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
    
    const data = await response.json();
    return {
      ok: data.ok,
      status: data.status,
      message: data.message,
      needRefresh: data.need_refresh,
    };
  } catch (error) {
    console.error('Check QR status error:', error);
    return { ok: false, status: 'error', message: error.message, needRefresh: false };
  }
}

/**
 * Complete QR login and get session token
 * @param {number} tempUserId 
 * @returns {Promise<{success: boolean, token?: string, user?: object, error?: string}>}
 */
export async function completeQRLogin(tempUserId) {
  const serverUrl = await getServerUrl();
  
  try {
    const response = await fetch(`${serverUrl}/api/auth/qr/complete/${tempUserId}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      }
    });
    
    const data = await response.json();
    
    if (data.ok && data.token) {
      // Save the token
      await saveAuthToken(data.token);
      return {
        success: true,
        token: data.token,
        user: data.user,
      };
    }
    
    return { success: false, error: data.error || '登录失败' };
  } catch (error) {
    console.error('Complete QR login error:', error);
    return { success: false, error: error.message || '网络错误' };
  }
}

/**
 * Cancel QR login session
 * @param {number} tempUserId 
 */
export async function cancelQRLogin(tempUserId) {
  const serverUrl = await getServerUrl();
  
  try {
    await fetch(`${serverUrl}/api/auth/qr/cancel/${tempUserId}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      }
    });
  } catch (error) {
    console.error('Cancel QR login error:', error);
  }
}
