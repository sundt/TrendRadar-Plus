/**
 * WeChat Integration Module
 * 
 * Handles WeChat MP credential sync to hotnews.
 */

import { getWechatCookies, checkWechatLogin } from './cookie-reader.js';
import { 
  syncWechatCredentials, 
  checkHotnewsLogin, 
  openHotnewsLogin,
  getWechatAuthStatus,
  tryGetTokenFromHotnews,
  startQRLogin,
  getQRCodeUrl,
  checkQRStatus,
  completeQRLogin,
  cancelQRLogin,
} from './hotnews-api.js';

/**
 * Handle sync request from content script
 * @returns {Promise<{success: boolean, needLogin?: boolean, error?: string}>}
 */
export async function handleSyncRequest() {
  // 1. Check if logged into WeChat MP
  const isWechatLoggedIn = await checkWechatLogin();
  if (!isWechatLoggedIn) {
    return { 
      success: false, 
      error: '未检测到公众号登录态，请先登录公众号后台' 
    };
  }
  
  // 2. Check if logged into hotnews
  let { loggedIn } = await checkHotnewsLogin();
  
  // 2.1 If not logged in, try to get token from hotnews (if user is logged in there)
  if (!loggedIn) {
    const tokenResult = await tryGetTokenFromHotnews();
    if (tokenResult.success) {
      loggedIn = true;
    }
  }
  
  if (!loggedIn) {
    return { success: false, needLogin: true };
  }
  
  // 3. Get WeChat cookies
  const cookieStr = await getWechatCookies();
  if (!cookieStr) {
    return { 
      success: false, 
      error: '无法读取公众号登录信息，请刷新页面后重试' 
    };
  }
  
  // 4. Sync to hotnews
  const result = await syncWechatCredentials(cookieStr);
  return result;
}

/**
 * Handle open hotnews login request
 */
export async function handleOpenLogin() {
  await openHotnewsLogin();
}

/**
 * Get current sync status
 * @returns {Promise<object>}
 */
export async function getSyncStatus() {
  const isWechatLoggedIn = await checkWechatLogin();
  const { loggedIn: isHotnewsLoggedIn, user } = await checkHotnewsLogin();
  const authStatus = isHotnewsLoggedIn ? await getWechatAuthStatus() : null;
  
  return {
    wechatLoggedIn: isWechatLoggedIn,
    hotnewsLoggedIn: isHotnewsLoggedIn,
    hotnewsUser: user,
    wechatAuth: authStatus
  };
}

/**
 * Setup message listeners for WeChat integration
 */
export function setupWechatMessageListeners() {
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'WECHAT_SYNC_REQUEST') {
      handleSyncRequest().then(sendResponse);
      return true; // Keep channel open for async response
    }
    
    if (message.type === 'WECHAT_OPEN_HOTNEWS_LOGIN') {
      handleOpenLogin().then(() => sendResponse({ success: true }));
      return true;
    }
    
    if (message.type === 'WECHAT_GET_STATUS') {
      getSyncStatus().then(sendResponse);
      return true;
    }
    
    if (message.type === 'WECHAT_TRY_GET_TOKEN') {
      tryGetTokenFromHotnews().then(sendResponse);
      return true;
    }
    
    // QR Login handlers
    if (message.type === 'WECHAT_QR_START') {
      startQRLogin().then(sendResponse);
      return true;
    }
    
    if (message.type === 'WECHAT_QR_IMAGE_URL') {
      getQRCodeUrl(message.tempUserId).then(url => sendResponse({ url }));
      return true;
    }
    
    if (message.type === 'WECHAT_QR_STATUS') {
      checkQRStatus(message.tempUserId).then(sendResponse);
      return true;
    }
    
    if (message.type === 'WECHAT_QR_COMPLETE') {
      completeQRLogin(message.tempUserId).then(sendResponse);
      return true;
    }
    
    if (message.type === 'WECHAT_QR_CANCEL') {
      cancelQRLogin(message.tempUserId).then(() => sendResponse({ success: true }));
      return true;
    }
  });
}
