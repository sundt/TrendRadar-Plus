/**
 * WeChat MP Cookie Reader
 * 
 * Reads necessary cookies from WeChat MP backend for authentication.
 */

// Required cookies for WeChat MP API access
const REQUIRED_COOKIES = ['slave_user', 'slave_sid', 'data_ticket', 'data_bizuin'];

/**
 * Get all WeChat MP cookies
 * @returns {Promise<string>} Cookie string in "name=value; name=value" format
 */
export async function getWechatCookies() {
  const cookies = await chrome.cookies.getAll({ 
    domain: 'mp.weixin.qq.com' 
  });
  
  // Only extract necessary cookies
  const cookieStr = cookies
    .filter(c => REQUIRED_COOKIES.includes(c.name))
    .map(c => `${c.name}=${c.value}`)
    .join('; ');
  
  return cookieStr;
}

/**
 * Check if user is logged into WeChat MP
 * @returns {Promise<boolean>}
 */
export async function checkWechatLogin() {
  const cookies = await chrome.cookies.getAll({ 
    domain: 'mp.weixin.qq.com' 
  });
  
  // Check if all required cookies exist and have values
  return REQUIRED_COOKIES.every(name => 
    cookies.some(c => c.name === name && c.value)
  );
}

/**
 * Get cookie expiration info
 * @returns {Promise<{valid: boolean, expiresAt: number|null}>}
 */
export async function getCookieExpiration() {
  const cookies = await chrome.cookies.getAll({ 
    domain: 'mp.weixin.qq.com' 
  });
  
  const relevantCookies = cookies.filter(c => REQUIRED_COOKIES.includes(c.name));
  
  if (relevantCookies.length < REQUIRED_COOKIES.length) {
    return { valid: false, expiresAt: null };
  }
  
  // Find the earliest expiration
  const expirations = relevantCookies
    .map(c => c.expirationDate)
    .filter(Boolean);
  
  if (expirations.length === 0) {
    // Session cookies, no expiration
    return { valid: true, expiresAt: null };
  }
  
  const earliestExpiration = Math.min(...expirations);
  const now = Date.now() / 1000;
  
  return {
    valid: earliestExpiration > now,
    expiresAt: earliestExpiration * 1000 // Convert to milliseconds
  };
}
