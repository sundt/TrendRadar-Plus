// Inline Storage System Tests (No Dynamic Imports)
// Copy and paste this entire script into Chrome DevTools console on the extension background page

(async function () {
    console.log('🧪 Starting Storage System Tests...\n');
    console.log('═'.repeat(60));

    // Test 1: Check if modules are loaded
    console.log('Test 1: Checking Module Availability');
    try {
        // These should be available from background.js imports
        const hasDb = typeof saveSummaryWithMetadata !== 'undefined';
        const hasToggle = typeof toggleFavorite !== 'undefined';
        const hasGet = typeof getSummaries !== 'undefined';
        const hasStats = typeof getStats !== 'undefined';

        console.log(`✅ saveSummaryWithMetadata: ${hasDb ? 'Available' : 'Missing'}`);
        console.log(`✅ toggleFavorite: ${hasToggle ? 'Available' : 'Missing'}`);
        console.log(`✅ getSummaries: ${hasGet ? 'Available' : 'Missing'}`);
        console.log(`✅ getStats: ${hasStats ? 'Available' : 'Missing'}`);

        if (!hasDb || !hasToggle || !hasGet || !hasStats) {
            console.error('❌ Some functions are not available. Make sure background.js is loaded.');
            return;
        }
    } catch (error) {
        console.error('❌ Module check failed:', error);
        return;
    }

    // Test 2: Send message to get summaries
    console.log('\nTest 2: Get Summaries via Message API');
    try {
        const response = await chrome.runtime.sendMessage({
            type: 'GET_SUMMARIES',
            options: { limit: 5 }
        });

        if (response.success) {
            console.log(`✅ Retrieved ${response.summaries.length} summaries`);
            response.summaries.forEach((s, i) => {
                console.log(`   ${i + 1}. ${s.title} (Score: ${s.score || 'N/A'})`);
            });
        } else {
            console.log('⚠️  No summaries yet or error:', response.error);
        }
    } catch (error) {
        console.error('❌ Get summaries failed:', error);
    }

    // Test 3: Get statistics
    console.log('\nTest 3: Get Database Statistics');
    try {
        const response = await chrome.runtime.sendMessage({
            type: 'GET_STORAGE_STATS'
        });

        if (response.success) {
            console.log('✅ Statistics:', response.stats);
            console.log(`   Total Summaries: ${response.stats.totalSummaries}`);
            console.log(`   Favorites: ${response.stats.favorites}`);
            console.log(`   Average Score: ${response.stats.avgScore}`);
        } else {
            console.error('❌ Get stats failed:', response.error);
        }
    } catch (error) {
        console.error('❌ Get stats failed:', error);
    }

    // Test 4: Direct database access
    console.log('\nTest 4: Direct Database Access');
    try {
        // Try to access the database directly
        const summaries = await getSummaries({ limit: 3 });
        console.log(`✅ Direct access successful: ${summaries.length} summaries retrieved`);
    } catch (error) {
        console.error('❌ Direct database access failed:', error);
        console.log('   This might be a module loading issue.');
    }

    // Test 5: Check IndexedDB directly
    console.log('\nTest 5: Check IndexedDB Browser Storage');
    try {
        const databases = await indexedDB.databases();
        const summarizerDb = databases.find(db => db.name === 'SummarizerBrain');

        if (summarizerDb) {
            console.log('✅ SummarizerBrain database exists');
            console.log(`   Version: ${summarizerDb.version}`);
        } else {
            console.log('⚠️  SummarizerBrain database not found yet');
            console.log('   It will be created when you generate your first summary.');
        }
    } catch (error) {
        console.error('❌ IndexedDB check failed:', error);
    }

    console.log('\n' + '═'.repeat(60));
    console.log('📊 Test Complete');
    console.log('═'.repeat(60));

    console.log('\n💡 Next Steps:');
    console.log('1. Generate a summary to test auto-save');
    console.log('2. Check: Chrome DevTools → Application → IndexedDB → SummarizerBrain');
    console.log('3. Run this script again to see the saved summary');

})().catch(error => {
    console.error('Fatal error:', error);
});
