// Storage Integration Module
// Integrates storage into the summarization workflow (simplified version)

import { saveSummary } from './db.js';
import { generateEmbedding, storeEmbedding } from './vector_store.js';

/**
 * Simple quality score calculation (simplified version)
 * @param {string} content - Summary content
 * @returns {Object} Quality result
 */
function calculateSimpleQualityScore(content) {
    let score = 50; // Base score
    
    // Check content length
    if (content.length > 500) score += 10;
    if (content.length > 1000) score += 10;
    
    // Check for structure (headers, lists)
    if (content.includes('##')) score += 10;
    if (content.includes('- ') || content.includes('* ')) score += 10;
    
    // Check for links
    if (content.includes('](')) score += 5;
    
    // Cap at 100
    score = Math.min(100, score);
    
    return {
        score,
        breakdown: {},
        suggestions: []
    };
}

/**
 * Save a summary to the database with quality scoring and embedding
 * @param {Object} params
 * @param {string} params.content - Summary content
 * @param {string} params.originalContent - Original page content
 * @param {string} params.pageUrl - Page URL
 * @param {string} params.pageTitle - Page title
 * @param {string} params.articleType - Article type
 * @param {Object} params.promptInfo - Prompt information
 * @param {Object} params.config - AI config
 * @returns {Promise<number>} Summary ID
 */
export async function saveSummaryWithMetadata(params) {
    const {
        content,
        originalContent,
        pageUrl,
        pageTitle,
        articleType,
        promptInfo,
        config
    } = params;

    // Calculate quality score (simplified)
    const qualityResult = calculateSimpleQualityScore(content);

    console.log(`[Storage] Quality Score: ${qualityResult.score}/100`);

    // Save summary to IndexedDB
    const summaryId = await saveSummary({
        url: pageUrl || '',
        title: pageTitle || 'Untitled',
        type: articleType || 'other',
        content: content,
        originalContent: originalContent,
        score: qualityResult.score,
        promptId: promptInfo?.id || 'backend-api',
        metadata: {
            provider: config?.provider || 'backend',
            model: config?.model || 'backend-api',
            matchedPrompt: promptInfo?.name || '智能分析',
            qualityBreakdown: qualityResult.breakdown,
            suggestions: qualityResult.suggestions
        }
    });

    console.log(`[Storage] Saved summary #${summaryId}: "${pageTitle}"`);

    // Skip embedding generation for simplified version
    // (Backend API handles this)

    return summaryId;
}
