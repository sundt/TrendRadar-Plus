// VectorStore - Local vector embeddings and similarity search
// Powers the semantic intelligence layer for self-evolution

import { getDB } from './db.js';

/**
 * VectorStore handles embedding storage and similarity search
 * Uses Ollama's embedding API and brute-force cosine similarity
 */

// Default embedding model - you can change this to any Ollama-supported embedding model
// Recommended alternatives:
//   - 'mxbai-embed-large' (1.5GB, 1024 dims, excellent quality, OpenAI compatible)
//   - 'nomic-embed-text' (274MB, 768 dims, good balance)
//   - 'all-minilm' (46MB, 384 dims, fast and lightweight)
//   - 'bge-m3' (2.2GB, 1024 dims, multilingual, best for Chinese/English)
//   - 'snowflake-arctic-embed' (669MB, 1024 dims, good for retrieval)
const DEFAULT_EMBEDDING_MODEL = 'mxbai-embed-large';

/**
 * Generate embedding for text using configured provider
 * @param {string} text - Text to embed
 * @param {Object} config - Embedding configuration
 * @param {string} config.provider - Provider: 'ollama' | 'openai' | 'custom'
 * @param {string} config.ollamaUrl - Ollama server URL
 * @param {string} config.model - Model name
 * @param {string} config.apiKey - API key (for OpenAI/custom)
 * @param {string} config.baseUrl - Base URL (for OpenAI/custom)
 * @returns {Promise<Float32Array|null>}
 */
export async function generateEmbedding(text, config = {}) {
    // Default config
    const {
        provider = 'ollama',
        ollamaUrl = 'http://localhost:11434',
        model = DEFAULT_EMBEDDING_MODEL,
        apiKey = '',
        baseUrl = 'https://api.openai.com/v1'
    } = config;

    try {
        // Truncate text to avoid token limits
        const truncated = text.substring(0, 8000);

        let embedding = null;

        switch (provider) {
            case 'ollama':
                embedding = await generateOllamaEmbedding(truncated, ollamaUrl, model);
                break;

            case 'openai':
                embedding = await generateOpenAIEmbedding(truncated, model, apiKey, baseUrl);
                break;

            case 'custom':
                // Custom API should follow OpenAI format
                embedding = await generateOpenAIEmbedding(truncated, model, apiKey, baseUrl);
                break;

            default:
                // Treat other providers as OpenAI-compatible endpoints
                embedding = await generateOpenAIEmbedding(truncated, model, apiKey, baseUrl);
                break;
        }

        return embedding;
    } catch (error) {
        console.error('[VectorStore] Failed to generate embedding:', error);
        return null;
    }
}

/**
 * Generate embedding using Ollama
 * @private
 */
async function generateOllamaEmbedding(text, ollamaUrl, model) {
    const response = await fetch(`${ollamaUrl}/api/embed`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            model: model,
            input: text
        })
    });

    if (!response.ok) {
        throw new Error(`Ollama API error: ${response.status}`);
    }

    const data = await response.json();

    // Ollama returns { embeddings: [[...]] } for single input
    if (data.embeddings && data.embeddings[0]) {
        return new Float32Array(data.embeddings[0]);
    }

    // Fallback for older Ollama versions
    if (data.embedding) {
        return new Float32Array(data.embedding);
    }

    throw new Error('Unexpected Ollama response format');
}

/**
 * Generate embedding using OpenAI-compatible API
 * @private
 */
async function generateOpenAIEmbedding(text, model, apiKey, baseUrl) {
    // Normalize URL: remove trailing slash and /chat/completions suffix
    const cleanUrl = baseUrl.replace(/\/+$/, '').replace(/\/chat\/completions$/, '');

    const response = await fetch(`${cleanUrl}/embeddings`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiKey}`
        },
        body: JSON.stringify({
            model: model,
            input: text,
            encoding_format: 'float'
        })
    });

    if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`OpenAI API error: ${response.status} - ${errorText}`);
    }

    const data = await response.json();

    if (data.data && data.data[0] && data.data[0].embedding) {
        return new Float32Array(data.data[0].embedding);
    }

    throw new Error('Unexpected OpenAI response format');
}

/**
 * Store embedding for a summary
 * @param {number} summaryId 
 * @param {Float32Array} embedding 
 * @param {string} model 
 */
export async function storeEmbedding(summaryId, embedding, model = DEFAULT_EMBEDDING_MODEL) {
    const db = getDB();

    // Check if already exists
    const existing = await db.vectors.get(summaryId);
    if (existing) {
        await db.vectors.update(summaryId, {
            embedding: Array.from(embedding), // Store as regular array for IndexedDB
            model,
            updatedAt: Date.now()
        });
    } else {
        await db.vectors.add({
            summaryId,
            embedding: Array.from(embedding),
            model,
            createdAt: Date.now()
        });
    }

    console.log(`[VectorStore] Stored embedding for summary #${summaryId} (dim=${embedding.length})`);
}

/**
 * Get embedding for a summary
 * @param {number} summaryId 
 * @returns {Promise<Float32Array|null>}
 */
export async function getEmbedding(summaryId) {
    const db = getDB();
    const record = await db.vectors.get(summaryId);
    if (!record || !record.embedding) return null;
    return new Float32Array(record.embedding);
}

/**
 * Calculate cosine similarity between two vectors
 * @param {Float32Array} a 
 * @param {Float32Array} b 
 * @returns {number} Similarity score between -1 and 1
 */
export function cosineSimilarity(a, b) {
    if (a.length !== b.length) {
        throw new Error(`Vector dimension mismatch: ${a.length} vs ${b.length}`);
    }

    let dotProduct = 0;
    let normA = 0;
    let normB = 0;

    for (let i = 0; i < a.length; i++) {
        dotProduct += a[i] * b[i];
        normA += a[i] * a[i];
        normB += b[i] * b[i];
    }

    const denominator = Math.sqrt(normA) * Math.sqrt(normB);
    if (denominator === 0) return 0;

    return dotProduct / denominator;
}

/**
 * Find similar summaries using brute-force search
 * @param {Float32Array} queryEmbedding - The query vector
 * @param {Object} options
 * @param {number} options.limit - Max results (default 10)
 * @param {number} options.minScore - Minimum similarity threshold (default 0.7)
 * @param {number[]} options.excludeIds - Summary IDs to exclude
 * @param {number} options.minSummaryScore - Only include summaries with score >= this
 * @returns {Promise<Array<{summaryId: number, similarity: number}>>}
 */
export async function findSimilar(queryEmbedding, options = {}) {
    const {
        limit = 10,
        minScore = 0.7,
        excludeIds = [],
        minSummaryScore = 0
    } = options;

    const db = getDB();

    // Get all vectors
    const allVectors = await db.vectors.toArray();

    if (allVectors.length === 0) {
        return [];
    }

    // Calculate similarities
    const results = [];
    const excludeSet = new Set(excludeIds);

    for (const record of allVectors) {
        if (excludeSet.has(record.summaryId)) continue;

        const embedding = new Float32Array(record.embedding);
        const similarity = cosineSimilarity(queryEmbedding, embedding);

        if (similarity >= minScore) {
            results.push({
                summaryId: record.summaryId,
                similarity
            });
        }
    }

    // Sort by similarity descending
    results.sort((a, b) => b.similarity - a.similarity);

    // Filter by summary score if needed
    if (minSummaryScore > 0) {
        const summaryIds = results.map(r => r.summaryId);
        const summaries = await db.summaries.where('id').anyOf(summaryIds).toArray();
        const scoreMap = new Map(summaries.map(s => [s.id, s.score || 0]));

        return results
            .filter(r => (scoreMap.get(r.summaryId) || 0) >= minSummaryScore)
            .slice(0, limit);
    }

    return results.slice(0, limit);
}

/**
 * Find similar high-quality summaries (for learning)
 * @param {number} summaryId - Source summary to find similar ones for
 * @param {number} limit - Max results
 * @returns {Promise<Array<{summaryId: number, similarity: number, score: number}>>}
 */
export async function findSimilarGoodSummaries(summaryId, limit = 5) {
    const embedding = await getEmbedding(summaryId);
    if (!embedding) {
        console.warn(`[VectorStore] No embedding found for summary #${summaryId}`);
        return [];
    }

    const similar = await findSimilar(embedding, {
        limit: limit * 2, // Get more to filter
        minScore: 0.6,
        excludeIds: [summaryId],
        minSummaryScore: 70 // Only high-quality ones
    });

    // Enrich with summary data
    const db = getDB();
    const enriched = [];

    for (const item of similar) {
        const summary = await db.summaries.get(item.summaryId);
        if (summary) {
            enriched.push({
                ...item,
                score: summary.score || 0,
                title: summary.title,
                type: summary.type
            });
        }
    }

    return enriched.slice(0, limit);
}

/**
 * Batch embed and store for multiple summaries
 * @param {number[]} summaryIds 
 * @param {string} ollamaUrl 
 */
export async function batchEmbedSummaries(summaryIds, ollamaUrl = 'http://localhost:11434') {
    const db = getDB();

    for (const id of summaryIds) {
        const summary = await db.summaries.get(id);
        if (!summary) continue;

        // Check if already has embedding
        const existing = await db.vectors.get(id);
        if (existing) continue;

        // Generate embedding from summary content
        const textToEmbed = `${summary.title}\n\n${summary.content}`;
        const embedding = await generateEmbedding(textToEmbed, ollamaUrl);

        if (embedding) {
            await storeEmbedding(id, embedding);
        }

        // Small delay to avoid overwhelming Ollama
        await new Promise(resolve => setTimeout(resolve, 100));
    }
}

/**
 * Get vector store statistics
 * @returns {Promise<Object>}
 */
export async function getVectorStats() {
    const db = getDB();
    const count = await db.vectors.count();
    const sample = await db.vectors.limit(1).toArray();
    const dimension = sample[0]?.embedding?.length || 0;

    return {
        totalVectors: count,
        dimension,
        model: sample[0]?.model || 'unknown'
    };
}
