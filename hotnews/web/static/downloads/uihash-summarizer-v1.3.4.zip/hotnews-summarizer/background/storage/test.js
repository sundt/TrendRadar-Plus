// Test script for storage system
// Run this in Chrome DevTools console on the extension background page

console.log('🧪 Starting Storage System Tests...\n');

// Test 1: Database Connection
async function testDatabaseConnection() {
    console.log('Test 1: Database Connection');
    try {
        const { getDB } = await import('./background/storage/db.js');
        const db = getDB();
        console.log('✅ Database initialized:', db.name);
        return true;
    } catch (error) {
        console.error('❌ Database connection failed:', error);
        return false;
    }
}

// Test 2: Save Summary
async function testSaveSummary() {
    console.log('\nTest 2: Save Summary');
    try {
        const { saveSummary } = await import('./background/storage/db.js');

        const testSummary = {
            url: 'https://example.com/test',
            title: 'Test Summary - ' + new Date().toISOString(),
            type: 'tech-tutorial',
            content: `## Test Summary

This is a test summary with [React](https://react.dev/) and [Next.js](https://nextjs.org/).

### Key Points
- Point 1
- Point 2
- Point 3

**Important**: This is just a test.`,
            originalContent: 'Original page content here...',
            score: 85,
            promptId: 'test-prompt',
            metadata: {
                provider: 'ollama',
                model: 'test-model',
                timestamp: Date.now()
            }
        };

        const id = await saveSummary(testSummary);
        console.log(`✅ Summary saved with ID: ${id}`);
        return id;
    } catch (error) {
        console.error('❌ Save summary failed:', error);
        return null;
    }
}

// Test 3: Get Summaries
async function testGetSummaries() {
    console.log('\nTest 3: Get Summaries');
    try {
        const { getSummaries } = await import('./background/storage/db.js');
        const summaries = await getSummaries({ limit: 5 });
        console.log(`✅ Retrieved ${summaries.length} summaries`);
        summaries.forEach((s, i) => {
            console.log(`   ${i + 1}. ${s.title} (Score: ${s.score})`);
        });
        return summaries;
    } catch (error) {
        console.error('❌ Get summaries failed:', error);
        return [];
    }
}

// Test 4: Quality Scoring
async function testQualityScoring() {
    console.log('\nTest 4: Quality Scoring');
    try {
        const { calculateQualityScore } = await import('./background/evolution/scorer.js');

        const testContent = `## Technical Overview

This project uses [React](https://react.dev/) and [TypeScript](https://www.typescriptlang.org/).

### Architecture
- **Frontend**: React with Vite
- **Backend**: Node.js + Express
- **Database**: PostgreSQL

The core principle is separation of concerns.

### Terms
- **SPA**: Single Page Application
- **SSR**: Server Side Rendering`;

        const result = calculateQualityScore(testContent);
        console.log(`✅ Quality Score: ${result.score}/100`);
        console.log('   Breakdown:', result.breakdown);
        if (result.suggestions.length > 0) {
            console.log('   Suggestions:', result.suggestions);
        }
        return result;
    } catch (error) {
        console.error('❌ Quality scoring failed:', error);
        return null;
    }
}

// Test 5: Toggle Favorite
async function testToggleFavorite(summaryId) {
    console.log('\nTest 5: Toggle Favorite');
    try {
        const { toggleFavorite } = await import('./background/storage/db.js');
        const newStatus = await toggleFavorite(summaryId);
        console.log(`✅ Favorite status changed to: ${newStatus}`);
        return newStatus;
    } catch (error) {
        console.error('❌ Toggle favorite failed:', error);
        return false;
    }
}

// Test 6: Get Stats
async function testGetStats() {
    console.log('\nTest 6: Get Statistics');
    try {
        const { getStats } = await import('./background/storage/db.js');
        const stats = await getStats();
        console.log('✅ Statistics:', stats);
        return stats;
    } catch (error) {
        console.error('❌ Get stats failed:', error);
        return null;
    }
}

// Test 7: Vector Embedding (requires Ollama)
async function testVectorEmbedding() {
    console.log('\nTest 7: Vector Embedding');
    try {
        const { generateEmbedding } = await import('./background/storage/vector_store.js');

        const testText = 'This is a test summary about React and TypeScript';
        console.log('   Generating embedding... (this may take a few seconds)');

        const embedding = await generateEmbedding(testText, 'http://localhost:11434');

        if (embedding) {
            console.log(`✅ Embedding generated successfully (dimension: ${embedding.length})`);
            return embedding;
        } else {
            console.warn('⚠️  Embedding generation returned null (is Ollama running?)');
            return null;
        }
    } catch (error) {
        console.error('❌ Vector embedding failed:', error);
        console.log('   Tip: Make sure Ollama is running: `ollama serve`');
        console.log('   Install embedding model: `ollama pull nomic-embed-text`');
        return null;
    }
}

// Run all tests
async function runAllTests() {
    console.log('═'.repeat(60));
    console.log('🚀 Storage System Integration Tests');
    console.log('═'.repeat(60));

    const results = {
        dbConnection: await testDatabaseConnection(),
        saveSummary: null,
        getSummaries: null,
        qualityScore: null,
        toggleFavorite: null,
        stats: null,
        embedding: null
    };

    results.saveSummary = await testSaveSummary();
    results.getSummaries = await testGetSummaries();
    results.qualityScore = await testQualityScoring();

    if (results.saveSummary) {
        results.toggleFavorite = await testToggleFavorite(results.saveSummary);
    }

    results.stats = await testGetStats();
    results.embedding = await testVectorEmbedding();

    console.log('\n' + '═'.repeat(60));
    console.log('📊 Test Summary');
    console.log('═'.repeat(60));
    console.log(`✅ Database Connection: ${results.dbConnection ? 'PASS' : 'FAIL'}`);
    console.log(`✅ Save Summary: ${results.saveSummary ? 'PASS' : 'FAIL'}`);
    console.log(`✅ Get Summaries: ${results.getSummaries?.length > 0 ? 'PASS' : 'FAIL'}`);
    console.log(`✅ Quality Scoring: ${results.qualityScore ? 'PASS' : 'FAIL'}`);
    console.log(`✅ Toggle Favorite: ${results.toggleFavorite !== null ? 'PASS' : 'FAIL'}`);
    console.log(`✅ Statistics: ${results.stats ? 'PASS' : 'FAIL'}`);
    console.log(`⚠️  Vector Embedding: ${results.embedding ? 'PASS' : 'SKIP (Ollama not available)'}`);

    const passCount = Object.values(results).filter(r => r !== null && r !== false).length;
    const totalTests = 7;

    console.log('\n' + '═'.repeat(60));
    console.log(`🎯 Result: ${passCount}/${totalTests} tests passed`);
    console.log('═'.repeat(60));

    if (passCount === totalTests) {
        console.log('🎉 All tests passed! Storage system is working perfectly.');
    } else if (passCount >= 6) {
        console.log('✅ Core functionality working. Vector embeddings require Ollama.');
    } else {
        console.log('⚠️  Some tests failed. Check the errors above.');
    }

    return results;
}

// Auto-run tests
runAllTests().catch(error => {
    console.error('Fatal error during tests:', error);
});

// Export for manual testing
window.storageTests = {
    runAllTests,
    testDatabaseConnection,
    testSaveSummary,
    testGetSummaries,
    testQualityScoring,
    testToggleFavorite,
    testGetStats,
    testVectorEmbedding
};

console.log('\n💡 Tip: Run individual tests with window.storageTests.testName()');
