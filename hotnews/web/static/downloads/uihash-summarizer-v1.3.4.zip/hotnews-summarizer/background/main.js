// Background Service Worker - Modular Entry Point
// This is a minimal modular version - full refactoring in progress

// Import utilities
import * as CacheUtils from './utils/cache.js';
import { AppError, safeFetch } from './utils/errors.js';
import {
    normalizeTypeCode,
    isLikelyAdContent,
    isLikelyTechContent,
    findPromptByType,
    adjustSystemPromptByPreference
} from './utils/helpers.js';

// Import config
import { ARTICLE_TYPES, CLASSIFY_PROMPT, DEFAULT_CONFIG } from './config/defaults.js';
import { deepMergeConfig, mergePrompts } from './config/merger.js';
import { initConfig as init, getConfig as get } from './config/manager.js';

// Re-export for use in main code
export {
    CacheUtils,
    AppError,
    safeFetch,
    normalizeTypeCode,
    isLikelyAdContent,
    isLikelyTechContent,
    findPromptByType,
    adjustSystemPromptByPreference,
    ARTICLE_TYPES,
    CLASSIFY_PROMPT,
    DEFAULT_CONFIG,
    deepMergeConfig,
    mergePrompts
};

// Temporary: Import remaining code from background.js
// TODO: Extract AI modules, features, and data managers
// For now, we keep background.js as-is and this serves as preparation

console.log('[Modular Background] Utilities loaded');
