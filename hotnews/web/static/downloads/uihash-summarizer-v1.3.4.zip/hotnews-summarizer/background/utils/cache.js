// Cache utilities for AI responses
// Prevents redundant API calls for identical content

const responseCache = new Map();
const CACHE_MAX_SIZE = 50;
const CACHE_TTL_MS = 30 * 60 * 1000; // 30分钟过期

function getCacheKey(content, promptId, modelId) {
    // 使用内容hash + promptId + modelId 作为缓存key
    const contentHash = hashString(content.substring(0, 2000));
    return `${contentHash}_${promptId}_${modelId}`;
}

function hashString(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
        const char = str.charCodeAt(i);
        hash = ((hash << 5) - hash) + char;
        hash = hash & hash; // Convert to 32bit integer
    }
    return hash.toString(36);
}

function getFromCache(key) {
    const cached = responseCache.get(key);
    if (!cached) return null;
    if (Date.now() - cached.timestamp > CACHE_TTL_MS) {
        responseCache.delete(key);
        return null;
    }
    return cached.data;
}

function setToCache(key, data) {
    // 超过最大缓存数时，删除最旧的
    if (responseCache.size >= CACHE_MAX_SIZE) {
        const oldestKey = responseCache.keys().next().value;
        responseCache.delete(oldestKey);
    }
    responseCache.set(key, { data, timestamp: Date.now() });
}

function clearCache() {
    responseCache.clear();
}

export {
    getCacheKey,
    getFromCache,
    setToCache,
    clearCache
};
