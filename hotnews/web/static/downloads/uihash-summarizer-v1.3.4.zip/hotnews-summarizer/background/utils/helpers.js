// Helper utilities for content analysis and prompt matching

// Type normalization
function normalizeTypeCode(raw) {
    const s = String(raw || '')
        .trim()
        .toLowerCase()
        .replace(/[`'"\\s]/g, '')
        .replace(/[，,。.!！?？:：]/g, '');

    if (!s) return 'other';
    if (s === 'advertorial' || s === 'advertisement' || s === 'marketing' || s === 'ads' || s === 'ad') return 'ad';
    if (s.includes('广告') || s.includes('推广') || s.includes('营销')) return 'ad';
    return s;
}

// Ad content detection
function isLikelyAdContent(content) {
    const text = String(content || '').toLowerCase();
    const keywords = [
        '广告', '推广', '赞助', '软文', '营销', '促销', '优惠', '折扣', '限时', '购买',
        '下单', '立即购买', '立即下单', '领取优惠', '领券', '扫码', '下载app', '注册',
        '联系客服', '咨询', '加微信', 'vx', 'weixin', '推荐码'
    ];
    let hit = 0;
    for (const k of keywords) {
        if (text.includes(k)) hit += 1;
        if (hit >= 4) return true;
    }
    return false;
}

// Technical content detection
function isLikelyTechContent(content) {
    const text = String(content || '');
    const lower = text.toLowerCase();
    let score = 0;

    // 强信号：代码块/代码符号
    if (text.includes('```')) score += 4;
    const punctHits = (text.match(/[{}[\];]/g) || []).length;
    if (punctHits >= 20) score += 2;

    // 强信号：常见技术命令/关键字
    const strongPatterns = [
        /\b(npm install|git clone|docker run|pip install|cargo build|go get|apt-get|brew install)\b/i,
        /\b(import .+ from|const .+ =|function |class |interface |type |async |await )\b/,
        /\b(react|vue|angular|node\.?js|python|rust|go|typescript|kubernetes|webpack)\b/i
    ];
    for (const pat of strongPatterns) {
        if (pat.test(text)) score += 3;
    }

    // 弱信号
    if (/(api|sdk|cli|ide|配置|部署|运行|安装|调试)/i.test(text)) score += 1;

    return score >= 4;
}

// 根据文章类型找到最匹配的提示词（增强版：深度学习偏好全局生效）
function findPromptByType(prompts, articleType, userConfig = {}) {
    const learningPref = userConfig.learningPreference || 'auto';

    // === 学习型内容的特殊处理 ===
    if (articleType === 'learning-deep') {
        if (learningPref === 'deep') {
            const learningMatch = prompts.find(p => p.id === 'learning-methodology');
            if (learningMatch) return learningMatch;
        } else if (learningPref === 'simple') {
            const feynmanMatch = prompts.find(p => p.id === 'feynman-learning');
            if (feynmanMatch) return feynmanMatch;
        }
        const learningMatch = prompts.find(p => p.id === 'learning-methodology');
        if (learningMatch) return learningMatch;
    }

    if (articleType === 'learning-simple') {
        if (learningPref === 'deep') {
            const learningMatch = prompts.find(p => p.id === 'learning-methodology');
            if (learningMatch) return learningMatch;
        } else if (learningPref === 'simple') {
            const feynmanMatch = prompts.find(p => p.id === 'feynman-learning');
            if (feynmanMatch) return feynmanMatch;
        }
        const feynmanMatch = prompts.find(p => p.id === 'feynman-learning');
        if (feynmanMatch) return feynmanMatch;
    }

    // === 非学习型内容：根据全局偏好调整 ===
    if (learningPref === 'deep' && articleType !== 'ad') {
        const deepTemplates = ['learning-methodology', 'opinion-analysis', 'business-analysis'];
        for (const templateId of deepTemplates) {
            const match = prompts.find(p => p.id === templateId && p.applicableTypes?.includes(articleType));
            if (match) return match;
        }
    }

    if (learningPref === 'simple' && articleType !== 'ad') {
        const simpleTemplates = ['feynman-learning', 'quick-tldr', 'simple-summary'];
        for (const templateId of simpleTemplates) {
            const match = prompts.find(p => p.id === templateId);
            if (match) return match;
        }
    }

    // === 标准匹配逻辑 ===
    const exactMatch = prompts.find(p =>
        !p.isSmartMode && p.applicableTypes?.includes(articleType)
    );
    if (exactMatch) return exactMatch;

    const generalMatch = prompts.find(p =>
        !p.isSmartMode && p.applicableTypes?.includes('all')
    );
    if (generalMatch) return generalMatch;

    return prompts.find(p => !p.isSmartMode) || prompts[0];
}

/**
 * 根据学习偏好调整 System Prompt
 * @param {string} originalPrompt - 原始 System Prompt
 * @param {string} learningPreference - 学习偏好（auto/deep/simple/standard）
 * @returns {string} 调整后的 System Prompt
 */
function adjustSystemPromptByPreference(originalPrompt, learningPreference) {
    if (!learningPreference || learningPreference === 'auto' || learningPreference === 'standard') {
        return originalPrompt;
    }

    const preferenceInstructions = {
        deep: `
【深度学习模式】
请严格遵循以下要求：
1. 挖掘底层逻辑和第一性原理，不做表面总结
2. 识别文中的隐含假设和不变量
3. 提供批判性思考和反常识洞见
4. 使用 SQ3R、RIA 等学习方法论框架
5. 输出深度而非宽度`,

        simple: `
【简化学习模式】
请严格遵循以下要求：
1. 用通俗语言解释，避免专业术语堆砌
2. 使用生活化的类比和比喻（如费曼学习法）
3. 提炼核心概念，删除次要细节
4. 把复杂概念拆解成小学生都能理解的语言
5. 输出简洁而非冗长`
    };

    const instruction = preferenceInstructions[learningPreference];
    if (!instruction) return originalPrompt;

    return `${originalPrompt}\n\n${instruction}`;
}

export {
    normalizeTypeCode,
    isLikelyAdContent,
    isLikelyTechContent,
    findPromptByType,
    adjustSystemPromptByPreference
};
