// Error handling utilities

class AppError extends Error {
    constructor(message, code = 'UNKNOWN_ERROR', details = null) {
        super(message);
        this.code = code;
        this.details = details;
        this.timestamp = new Date().toISOString();
    }

    toJSON() {
        return {
            message: this.message,
            code: this.code,
            details: this.details,
            timestamp: this.timestamp
        };
    }
}

// 错误代码定义
const ERROR_CODES = {
    NETWORK_ERROR: '网络连接失败，请检查网络设置',
    API_ERROR: 'API 请求失败',
    TIMEOUT_ERROR: '请求超时，请稍后重试',
    ABORT_ERROR: '请求已取消',
    CONFIG_ERROR: '配置错误，请检查设置',
    CONTENT_ERROR: '无法提取页面内容',
    UNKNOWN_ERROR: '发生未知错误'
};

// 安全的 fetch 封装
async function safeFetch(url, options = {}, timeoutMs = 60000) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

    try {
        const response = await fetch(url, {
            ...options,
            signal: options.signal || controller.signal
        });
        clearTimeout(timeoutId);

        if (!response.ok) {
            const errorText = await response.text().catch(() => '');
            throw new AppError(
                `HTTP ${response.status}: ${response.statusText}`,
                'API_ERROR',
                { status: response.status, body: errorText.substring(0, 500) }
            );
        }
        return response;
    } catch (error) {
        clearTimeout(timeoutId);
        if (error.name === 'AbortError') {
            throw new AppError('请求超时或已取消', 'TIMEOUT_ERROR');
        }
        if (error instanceof AppError) throw error;
        throw new AppError(error.message, 'NETWORK_ERROR', { originalError: error.name });
    }
}

export {
    AppError,
    ERROR_CODES,
    safeFetch
};
