// uihash 总结助手 - 设置页面脚本

const API_BASE_URL = 'https://hot.uihash.com';
let isLoggedIn = false;

// 检测是否为 Mac 系统
const isMac = navigator.platform.toUpperCase().indexOf('MAC') >= 0 || 
              navigator.userAgent.toUpperCase().indexOf('MAC') >= 0;

// 初始化
document.addEventListener('DOMContentLoaded', async () => {
  await checkLoginStatus();
  updateShortcutKeys();
  
  // 绑定头像点击事件
  const avatarEl = document.getElementById('account-avatar');
  if (avatarEl) {
    avatarEl.addEventListener('click', handleAvatarClick);
  }
  
  // 绑定退出按钮事件
  const logoutBtn = document.getElementById('logout-btn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', handleLogout);
  }
  
  // 绑定快捷键设置链接
  const shortcutsLink = document.getElementById('shortcuts-link');
  if (shortcutsLink) {
    shortcutsLink.addEventListener('click', (e) => {
      e.preventDefault();
      chrome.tabs.create({ url: 'chrome://extensions/shortcuts' });
    });
  }
});

/**
 * 更新快捷键显示（Mac 使用 ⌥⇧，Windows/Linux 使用 Alt+Shift）
 */
function updateShortcutKeys() {
  const modKey = isMac ? '⌥' : 'Alt';
  const shiftKey = isMac ? '⇧' : 'Shift';
  
  // 打开侧边栏快捷键
  const toggleShortcut = document.getElementById('shortcut-toggle');
  if (toggleShortcut) {
    toggleShortcut.innerHTML = `
      <span class="key">${modKey}</span>
      <span class="key">${shiftKey}</span>
      <span class="key">U</span>
    `;
  }
  
  // 总结当前页面快捷键
  const summarizeShortcut = document.getElementById('shortcut-summarize');
  if (summarizeShortcut) {
    summarizeShortcut.innerHTML = `
      <span class="key">${modKey}</span>
      <span class="key">${shiftKey}</span>
      <span class="key">Y</span>
    `;
  }
}

/**
 * 处理头像点击
 */
function handleAvatarClick() {
  if (isLoggedIn) {
    // 已登录，跳转到个人中心
    window.open(`${API_BASE_URL}/user`, '_blank');
  } else {
    // 未登录，跳转到登录页面
    window.open(`${API_BASE_URL}/?login=1`, '_blank');
  }
}

/**
 * 检查登录状态
 */
async function checkLoginStatus() {
  const avatarEl = document.getElementById('account-avatar');
  const nameEl = document.getElementById('account-name');
  const detailEl = document.getElementById('account-detail');
  const logoutBtn = document.getElementById('logout-btn');

  try {
    const response = await fetch(`${API_BASE_URL}/api/auth/me`, {
      method: 'GET',
      credentials: 'include',
      headers: {
        'Accept': 'application/json'
      }
    });

    if (response.status === 401) {
      // 未登录
      showLoggedOutState();
      return;
    }

    if (!response.ok) {
      throw new Error('Failed to check login status');
    }

    const data = await response.json();

    if (data.ok && data.user) {
      // 已登录
      isLoggedIn = true;
      const user = data.user;
      
      if (avatarEl) {
        avatarEl.title = '点击查看个人中心';
        if (user.avatar_url) {
          avatarEl.innerHTML = `<img src="${user.avatar_url}" style="width:100%;height:100%;border-radius:50%;object-fit:cover;">`;
        } else {
          avatarEl.textContent = user.nickname ? user.nickname.charAt(0).toUpperCase() : '👤';
        }
      }
      
      if (nameEl) {
        nameEl.textContent = user.nickname || '用户';
      }
      
      if (detailEl) {
        detailEl.textContent = '已登录';
      }
      
      if (logoutBtn) {
        logoutBtn.style.display = 'inline-flex';
      }
    } else {
      showLoggedOutState();
    }
  } catch (error) {
    console.error('[Options] Check login status error:', error);
    showLoggedOutState();
  }
}

/**
 * 显示未登录状态
 */
function showLoggedOutState() {
  isLoggedIn = false;
  const avatarEl = document.getElementById('account-avatar');
  const nameEl = document.getElementById('account-name');
  const detailEl = document.getElementById('account-detail');
  const logoutBtn = document.getElementById('logout-btn');

  if (avatarEl) {
    avatarEl.textContent = '👤';
    avatarEl.title = '点击登录';
  }
  
  if (nameEl) {
    nameEl.textContent = '未登录';
  }
  
  if (detailEl) {
    detailEl.textContent = '点击头像登录';
  }
  
  if (logoutBtn) {
    logoutBtn.style.display = 'none';
  }
}

/**
 * 处理退出登录
 */
async function handleLogout() {
  if (!confirm('确定要退出登录吗？')) {
    return;
  }
  
  try {
    // 调用后端退出接口
    await fetch(`${API_BASE_URL}/api/auth/logout`, {
      method: 'POST',
      credentials: 'include'
    });
    
    // 清除本地存储的登录状态
    chrome.storage.local.remove(['authState', 'userInfo'], () => {
      console.log('[Options] Cleared local auth state');
    });
    
    // 通知其他页面（如sidepanel）登录状态已变更
    chrome.runtime.sendMessage({ type: 'LOGOUT' }).catch(() => {});
    
    // 更新UI
    showLoggedOutState();
    
    alert('已退出登录');
  } catch (error) {
    console.error('[Options] Logout error:', error);
    alert('退出失败，请重试');
  }
}
