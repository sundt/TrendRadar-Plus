// 新的 renderMarkdown 函数 - 从 hotnews 网站复制
// 这个文件用于替换 sidepanel.js 中的 renderMarkdown 函数

function renderMarkdown(text) {
    if (!text) return '';
    
    // Pre-process: convert HTML br tags to newlines before escaping
    let html = text
        .replace(/<br\s*\/?>/gi, '\n')
        .replace(/<\/br>/gi, '\n');
    
    // Remove checkbox markers [ ] from action lists
    html = html.replace(/- \[ \]/g, '-');
    html = html.replace(/- \[\]/g, '-');
    
    // Escape HTML
    html = html
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
    
    // Code blocks (must be before other processing)
    html = html.replace(/```(\w*)\n([\s\S]*?)```/g, '<pre><code class="language-$1">$2</code></pre>');
    html = html.replace(/`([^`]+)`/g, '<code>$1</code>');
    
    // Headers (with optional leading #)
    html = html.replace(/^#{4}\s+(.+)$/gm, '<h4>$1</h4>');
    html = html.replace(/^#{3}\s+(.+)$/gm, '<h3>$1</h3>');
    html = html.replace(/^#{2}\s+(.+)$/gm, '<h2>$1</h2>');
    html = html.replace(/^#{1}\s+(.+)$/gm, '<h1>$1</h1>');
    
    // Bold and italic (handle ** and * properly)
    html = html.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
    html = html.replace(/\*([^*]+)\*/g, '<em>$1</em>');
    html = html.replace(/__([^_]+)__/g, '<strong>$1</strong>');
    html = html.replace(/_([^_]+)_/g, '<em>$1</em>');
    
    // Links
    html = html.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
    
    // Blockquotes (> at start of line)
    html = html.replace(/^&gt;\s*(.*)$/gm, '<blockquote>$1</blockquote>');
    // Merge consecutive blockquotes
    html = html.replace(/<\/blockquote>\n<blockquote>/g, '\n');
    
    // Horizontal rules (---, ***, ___) - only when alone on a line
    html = html.replace(/^[-]{3,}\s*$/gm, '<hr>');
    html = html.replace(/^[*]{3,}\s*$/gm, '<hr>');
    html = html.replace(/^[_]{3,}\s*$/gm, '<hr>');
    
    // Process line by line for lists and tables
    const lines = html.split('\n');
    let result = [];
    let inTable = false;
    let tableRows = [];
    let inList = false;
    let listItems = [];
    
    for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        const trimmedLine = line.trim();
        
        // Check for table row
        const isTableRow = /^\|(.+)\|$/.test(trimmedLine);
        const isTableSeparator = /^\|[\s\-:|]+\|$/.test(trimmedLine);
        
        // Check for list item (- or * followed by space, or numbered list)
        const unorderedMatch = trimmedLine.match(/^[-*]\s+(.+)$/);
        const orderedMatch = trimmedLine.match(/^\d+\.\s+(.+)$/);
        const isListItem = unorderedMatch || orderedMatch;
        
        // Handle table
        if (isTableRow) {
            // Close any open list first
            if (inList && listItems.length > 0) {
                result.push('<ul>' + listItems.join('') + '</ul>');
                listItems = [];
                inList = false;
            }
            
            if (!inTable) {
                inTable = true;
                tableRows = [];
            }
            if (!isTableSeparator) {
                const cells = trimmedLine.slice(1, -1).split('|').map(c => c.trim());
                const isHeader = tableRows.length === 0;
                const tag = isHeader ? 'th' : 'td';
                const row = '<tr>' + cells.map(c => `<${tag}>${c}</${tag}>`).join('') + '</tr>';
                tableRows.push(row);
            }
            continue;
        } else if (inTable && tableRows.length > 0) {
            result.push('<table>' + tableRows.join('') + '</table>');
            tableRows = [];
            inTable = false;
        }
        
        // Handle list item
        if (isListItem) {
            const content = unorderedMatch ? unorderedMatch[1] : orderedMatch[1];
            inList = true;
            listItems.push('<li>' + content + '</li>');
            continue;
        } else if (inList && listItems.length > 0) {
            result.push('<ul>' + listItems.join('') + '</ul>');
            listItems = [];
            inList = false;
        }
        
        result.push(line);
    }
    
    // Close any remaining table or list
    if (inTable && tableRows.length > 0) {
        result.push('<table>' + tableRows.join('') + '</table>');
    }
    if (inList && listItems.length > 0) {
        result.push('<ul>' + listItems.join('') + '</ul>');
    }
    
    html = result.join('\n');
    
    // Convert double newlines to paragraph breaks
    html = html.split(/\n{2,}/).map(block => {
        block = block.trim();
        if (!block) return '';
        // Don't wrap block elements
        if (/^<(h[1-6]|ul|ol|table|pre|blockquote|hr)/.test(block)) {
            return block;
        }
        // Don't wrap if it ends with a block element
        if (/<\/(h[1-6]|ul|ol|table|pre|blockquote)>$/.test(block)) {
            return block;
        }
        return '<p>' + block.replace(/\n/g, '<br>') + '</p>';
    }).join('\n');
    
    // Clean up empty paragraphs and stray tags
    html = html.replace(/<p>\s*<\/p>/g, '');
    html = html.replace(/<p><hr><\/p>/g, '<hr>');
    html = html.replace(/<p>(<table>)/g, '$1');
    html = html.replace(/(<\/table>)<\/p>/g, '$1');
    html = html.replace(/<p>(<ul>)/g, '$1');
    html = html.replace(/(<\/ul>)<\/p>/g, '$1');
    html = html.replace(/<p>(<blockquote>)/g, '$1');
    html = html.replace(/(<\/blockquote>)<\/p>/g, '$1');
    
    return html;
}
