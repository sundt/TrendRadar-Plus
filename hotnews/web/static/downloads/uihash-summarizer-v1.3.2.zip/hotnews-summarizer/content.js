// Custom Summarizer - Content Script
// 浮动按钮 + 提示词选择菜单，选择后打开侧边栏

// ============ 早期注入（document_start 时机）============
// 立即注入标记，确保在页面 JS 执行前完成
(function earlyInject() {
  try {
    document.documentElement.setAttribute('data-hotnews-summarizer', 'installed');
    document.documentElement.setAttribute('data-hotnews-summarizer-version', chrome.runtime.getManifest().version);
    
    // 检测是否需要自动打开侧边栏（从 hotnews 网站跳转过来）
    const url = new URL(window.location.href);
    if (url.searchParams.get('hotnews_auto_summarize') === '1') {
      // 移除 URL 参数（避免刷新时重复触发）
      url.searchParams.delete('hotnews_auto_summarize');
      window.history.replaceState({}, '', url.toString());
      
      // 标记需要自动总结
      document.documentElement.setAttribute('data-hotnews-auto-summarize', 'pending');
    }
  } catch (e) {
    // 忽略错误（可能在特殊页面）
  }
})();

// ============ 监听网站触发侧边栏事件 ============
window.addEventListener('hotnews-summarizer-open-sidepanel', (e) => {
  const { url, title, newsId } = e.detail || {};
  
  // 立即发送确认（在实际打开之前）
  window.dispatchEvent(new CustomEvent('hotnews-summarizer-sidepanel-ack'));
  
  // 发送消息给 background 打开侧边栏
  if (chrome?.runtime?.id) {
    chrome.runtime.sendMessage({ 
      type: 'OPEN_SIDEPANEL_DIRECT', 
      url: url,
      title: title,
      newsId: newsId
    });
  }
});

(function() {
  'use strict';
  
  // 避免重复注入
  if (window.__customSummarizerInjected) return;
  window.__customSummarizerInjected = true;

  // ============ Readability 简化实现 ============
  function extractContent() {
    // 克隆文档以避免修改原始 DOM
    const docClone = document.cloneNode(true);
    
    // 移除脚本、样式、导航等
    const removeSelectors = [
      'script', 'style', 'noscript', 'iframe', 'nav', 'header', 'footer',
      'aside', '.sidebar', '.nav', '.navigation', '.menu', '.ad', '.ads',
      '.advertisement', '.comment', '.comments', '#comments', '.social',
      '.share', '.related', '[role="navigation"]', '[role="banner"]',
      '[role="complementary"]', '.cookie', '.popup', '.modal'
    ];
    
    removeSelectors.forEach(selector => {
      docClone.querySelectorAll(selector).forEach(el => el.remove());
    });
    
    // 尝试找到主要内容区域
    const contentSelectors = [
      'article',
      '[role="main"]',
      'main',
      '.post-content',
      '.article-content',
      '.entry-content',
      '.content',
      '#content',
      '.post',
      '.article'
    ];
    
    let mainContent = null;
    for (const selector of contentSelectors) {
      mainContent = docClone.querySelector(selector);
      if (mainContent && mainContent.textContent.trim().length > 200) {
        break;
      }
    }
    
    // 如果没找到，使用 body
    if (!mainContent) {
      mainContent = docClone.body;
    }
    
    // 提取文本
    let text = '';
    const walker = document.createTreeWalker(
      mainContent,
      NodeFilter.SHOW_TEXT,
      null,
      false
    );
    
    let node;
    while (node = walker.nextNode()) {
      const trimmed = node.textContent.trim();
      if (trimmed.length > 0) {
        text += trimmed + '\n';
      }
    }
    
    // 清理多余空行
    text = text.replace(/\n{3,}/g, '\n\n').trim();
    
    return {
      title: document.title,
      content: text,
      url: window.location.href
    };
  }

  // ============ 状态管理 ============
  let currentPrompts = [];
  let selectedPromptId = null;

  let selectionTodoBtn = null;

  // ============ UI 组件 ============
  
  function clampNumber(value, min, max) {
    const n = Number(value);
    if (!Number.isFinite(n)) return min;
    return Math.min(max, Math.max(min, n));
  }
  
  let cachedSafeAreaInsets = null;
  
  function getSafeAreaInsets() {
    if (cachedSafeAreaInsets) return cachedSafeAreaInsets;
    const probe = document.createElement('div');
    probe.style.cssText = 'position: fixed; top: 0; left: 0; width: 0; height: 0; padding: env(safe-area-inset-top) env(safe-area-inset-right) env(safe-area-inset-bottom) env(safe-area-inset-left); visibility: hidden; pointer-events: none;';
    document.documentElement.appendChild(probe);
    const style = getComputedStyle(probe);
    const insets = {
      top: parseFloat(style.paddingTop) || 0,
      right: parseFloat(style.paddingRight) || 0,
      bottom: parseFloat(style.paddingBottom) || 0,
      left: parseFloat(style.paddingLeft) || 0
    };
    probe.remove();
    cachedSafeAreaInsets = insets;
    return insets;
  }
  
  function getMinMargins() {
    const insets = getSafeAreaInsets();
    return {
      right: Math.max(0, insets.right),
      bottom: Math.max(8, insets.bottom + 4)
    };
  }
  
  function getBoundsForElement(element, margins) {
    const rect = element.getBoundingClientRect();
    const maxRight = Math.max(margins.right, window.innerWidth - rect.width - margins.right);
    const maxBottom = Math.max(margins.bottom, window.innerHeight - rect.height - margins.bottom);
    return { rightMin: margins.right, bottomMin: margins.bottom, maxRight, maxBottom };
  }
  
  function readRightBottomFromRect(element) {
    const rect = element.getBoundingClientRect();
    return {
      right: window.innerWidth - rect.right,
      bottom: window.innerHeight - rect.bottom
    };
  }
  
  function applyPosition(element, right, bottom) {
    element.style.right = `${right}px`;
    element.style.bottom = `${bottom}px`;
    element.style.left = 'auto';
    element.style.top = 'auto';
  }
  
  function normalizePosition(element, position, margins) {
    const bounds = getBoundsForElement(element, margins);
    const raw = {
      right: position?.right,
      bottom: position?.bottom
    };
    
    let right = clampNumber(raw.right, bounds.rightMin, bounds.maxRight);
    let bottom = clampNumber(raw.bottom, bounds.bottomMin, bounds.maxBottom);
    
    if (position?.dock === 'right') {
      right = bounds.rightMin;
    } else if (position?.dock === 'left') {
      right = bounds.maxRight;
    }
    
    applyPosition(element, right, bottom);
    return { right, bottom, dock: position?.dock };
  }
  
  // 创建浮动按钮容器
  function createFloatingButton() {
    const container = document.createElement('div');
    container.id = 'cs-floating-container';
    
    // 获取扩展的图标 URL
    const iconUrl = chrome.runtime.getURL('icons/icon48.png');
    
    container.innerHTML = `
      <div id="cs-floating-btn" title="AI 总结">
        <img src="${iconUrl}" alt="uihash" style="width: 100%; height: 100%; border-radius: 50%; object-fit: cover;">
      </div>
    `;
    document.body.appendChild(container);
    
    const button = document.getElementById('cs-floating-btn');
    
    // 点击按钮直接打开侧边栏
    button.addEventListener('click', (e) => {
      e.stopPropagation();
      openSidepanelDirectly();
    });
    
    // 拖拽功能
    makeDraggable(container);
    
    return container;
  }
  
  // 直接打开侧边栏（同一文章只总结一次）
  function openSidepanelDirectly() {
    const normalizedUrl = normalizeUrl(location.href);
    safeSendMessage({ type: 'OPEN_SIDEPANEL_DIRECT', url: normalizedUrl });
  }

  let extensionContextInvalidated = false;
  function safeSendMessage(message, callback) {
    if (extensionContextInvalidated) return;
    if (!chrome?.runtime?.id) {
      extensionContextInvalidated = true;
      return;
    }
    try {
      chrome.runtime.sendMessage(message, (response) => {
        const err = chrome.runtime?.lastError;
        const msg = err?.message || '';
        if (msg && msg.includes('Extension context invalidated')) {
          extensionContextInvalidated = true;
          return;
        }
        if (callback) callback(response);
      });
    } catch (e) {
      const msg = e?.message || String(e);
      if (msg.includes('Extension context invalidated')) {
        extensionContextInvalidated = true;
        return;
      }
      throw e;
    }
  }

  // 归一化 URL（去掉 hash）
  function normalizeUrl(href) {
    try {
      const u = new URL(href);
      u.hash = '';
      return u.toString();
    } catch {
      return href.split('#')[0];
    }
  }

  // 标记已总结过的页面（存储在 session），返回是否可以总结
  function markIfNotSummarized(url) {
    return new Promise((resolve) => {
      chrome.storage.session.get(['csSummarized'], (res) => {
        const map = res.csSummarized || {};
        if (map[url]) {
          resolve(false);
          return;
        }
        map[url] = Date.now();
        chrome.storage.session.set({ csSummarized: map }, () => resolve(true));
      });
    });
  }
  
  // 显示点击扩展图标的提示
  function showClickIconHint(error) {
    // 避免重复显示
    if (document.getElementById('cs-click-icon-hint')) return;
    
    const hint = document.createElement('div');
    hint.id = 'cs-click-icon-hint';
    hint.innerHTML = `
      <div style="
        position: fixed;
        top: 20px;
        right: 20px;
        background: #333;
        color: white;
        padding: 12px 16px;
        border-radius: 8px;
        z-index: 2147483647;
        font-size: 14px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        animation: slideIn 0.3s ease;
      ">
        <style>
          @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
          }
        </style>
        请点击右上角的扩展图标打开侧边栏 📌<br/>
        ${error ? `<div style="margin-top:6px;font-size:12px;color:#ffdd99;">原因：${error}</div>` : ''}
      </div>
    `;
    document.body.appendChild(hint);
    
    setTimeout(() => {
      hint.remove();
    }, 4000);
  }
  
  // 显示自动总结提示（从 hotnews 跳转过来时）
  function showAutoSummarizeHint() {
    // 避免重复显示
    if (document.getElementById('cs-auto-summarize-hint')) return;
    
    const hint = document.createElement('div');
    hint.id = 'cs-auto-summarize-hint';
    hint.innerHTML = `
      <div style="
        position: fixed;
        top: 20px;
        right: 20px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 16px 20px;
        border-radius: 12px;
        z-index: 2147483647;
        font-size: 14px;
        box-shadow: 0 8px 24px rgba(102, 126, 234, 0.4);
        animation: slideIn 0.3s ease;
        max-width: 280px;
      ">
        <style>
          @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
          }
          #cs-auto-summarize-hint .hint-btn {
            display: inline-block;
            margin-top: 12px;
            padding: 8px 16px;
            background: rgba(255,255,255,0.2);
            border: 1px solid rgba(255,255,255,0.3);
            border-radius: 20px;
            color: white;
            font-size: 13px;
            cursor: pointer;
            transition: all 0.2s;
          }
          #cs-auto-summarize-hint .hint-btn:hover {
            background: rgba(255,255,255,0.3);
          }
          #cs-auto-summarize-hint .hint-close {
            position: absolute;
            top: 8px;
            right: 8px;
            width: 20px;
            height: 20px;
            border: none;
            background: rgba(255,255,255,0.2);
            color: white;
            border-radius: 50%;
            cursor: pointer;
            font-size: 12px;
            line-height: 20px;
            text-align: center;
          }
        </style>
        <button class="hint-close" onclick="this.closest('#cs-auto-summarize-hint').remove()">✕</button>
        <div style="font-weight: 600; margin-bottom: 6px;">✨ 点击开始 AI 总结</div>
        <div style="font-size: 13px; opacity: 0.9;">点击下方按钮或右下角浮标开始总结这篇文章</div>
        <button class="hint-btn" id="cs-auto-summarize-btn">🚀 立即总结</button>
      </div>
    `;
    document.body.appendChild(hint);
    
    // 绑定点击事件
    const btn = document.getElementById('cs-auto-summarize-btn');
    if (btn) {
      btn.addEventListener('click', () => {
        hint.remove();
        openSidepanelDirectly();
      });
    }
    
    // 10秒后自动消失
    setTimeout(() => {
      if (hint.parentNode) {
        hint.remove();
      }
    }, 10000);
  }
  
  // 监听来自 background 的消息
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'SHOW_CLICK_ICON_HINT') {
      showClickIconHint(message.error);
      return false; // 不需要异步响应
    }
    return false;
  });
  
  // 拖拽功能
  function makeDraggable(element) {
    let isDragging = false;
    let hasMoved = false;
    let startX, startY, initialRight, initialBottom;
    let dragWidth = 0;
    let dragHeight = 0;
    let margins = getMinMargins();
    
    const button = element.querySelector('#cs-floating-btn');
    
    button.addEventListener('mousedown', (e) => {
      if (e.button !== 0) return;
      isDragging = true;
      hasMoved = false;
      margins = getMinMargins();
      startX = e.clientX;
      startY = e.clientY;
      const rect = element.getBoundingClientRect();
      dragWidth = rect.width;
      dragHeight = rect.height;
      // 计算相对于视口右下角的位置
      initialRight = window.innerWidth - rect.right;
      initialBottom = window.innerHeight - rect.bottom;
      e.preventDefault();
    });
    
    document.addEventListener('mousemove', (e) => {
      if (!isDragging) return;
      
      const dx = e.clientX - startX;
      const dy = e.clientY - startY;
      
      // 只有移动超过 5px 才认为是拖拽
      if (Math.abs(dx) > 5 || Math.abs(dy) > 5) {
        hasMoved = true;
      }
      
      // 使用 right 和 bottom 定位，这样视口变化时按钮不会被遮挡
      const maxRight = Math.max(margins.right, window.innerWidth - dragWidth - margins.right);
      const maxBottom = Math.max(margins.bottom, window.innerHeight - dragHeight - margins.bottom);
      const newRight = clampNumber(initialRight - dx, margins.right, maxRight);
      const newBottom = clampNumber(initialBottom - dy, margins.bottom, maxBottom);
      applyPosition(element, newRight, newBottom);
    });
    
    document.addEventListener('mouseup', () => {
      if (isDragging) {
        isDragging = false;
        if (hasMoved) {
          // 保存位置（使用 right 和 bottom）
          const { right: rawRight, bottom: rawBottom } = readRightBottomFromRect(element);
          const bounds = getBoundsForElement(element, margins);
          const right = clampNumber(rawRight, bounds.rightMin, bounds.maxRight);
          const bottom = clampNumber(rawBottom, bounds.bottomMin, bounds.maxBottom);
          const dock = right <= bounds.maxRight / 2 ? 'right' : 'left';
          const dockedRight = dock === 'right' ? bounds.rightMin : bounds.maxRight;
          applyPosition(element, dockedRight, bottom);
          safeSendMessage({
            type: 'SAVE_BUTTON_POSITION',
            position: { right: dockedRight, bottom, dock, userDragged: true }
          });
        }
      }
    });
  }
  
  // Toast 提示
  function showToast(message) {
    const existing = document.querySelector('.cs-toast');
    if (existing) existing.remove();
    
    const toast = document.createElement('div');
    toast.className = 'cs-toast';
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
      toast.classList.add('cs-toast-visible');
    }, 10);
    
    setTimeout(() => {
      toast.classList.remove('cs-toast-visible');
      setTimeout(() => toast.remove(), 300);
    }, 2000);
  }

  function addTodoFromSelection(text) {
    const trimmed = String(text || '').trim().replace(/\s+/g, ' ');
    if (!trimmed) return;

    const pageUrl = normalizeUrl(location.href);
    const todo = {
      id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
      createdAt: Date.now(),
      done: false,
      text: trimmed,
      source: {
        pageTitle: document.title || '未知页面',
        pageUrl
      }
    };

    chrome.storage.local.get(['todos'], (result) => {
      const list = Array.isArray(result.todos) ? result.todos : [];
      list.push(todo);
      chrome.storage.local.set({ todos: list }, () => {
        showToast('已添加到 Todo');
      });
    });
  }

  function initSelectionTodo() {
    selectionTodoBtn = document.createElement('button');
    selectionTodoBtn.className = 'cs-selection-todo-btn';
    selectionTodoBtn.type = 'button';
    selectionTodoBtn.textContent = '+Todo';
    selectionTodoBtn.style.display = 'none';
    document.body.appendChild(selectionTodoBtn);

    const hide = () => {
      selectionTodoBtn.style.display = 'none';
      selectionTodoBtn.dataset.selectionText = '';
    };

    const getSelectionData = () => {
      const sel = window.getSelection();
      if (!sel || sel.isCollapsed) return null;
      const text = sel.toString();
      if (!String(text || '').trim()) return null;

      const range = sel.rangeCount ? sel.getRangeAt(0) : null;
      if (!range) return null;

      const containerNode = range.commonAncestorContainer;
      const containerEl = containerNode?.nodeType === Node.ELEMENT_NODE ? containerNode : containerNode?.parentElement;
      if (!containerEl) return null;

      if (containerEl.closest && containerEl.closest('#cs-floating-container')) return null;
      if (containerEl.closest && containerEl.closest('.cs-toast')) return null;
      if (containerEl.closest && containerEl.closest('#cs-click-icon-hint')) return null;

      return { text, range };
    };

    const showForCurrentSelection = () => {
      const data = getSelectionData();
      if (!data) {
        hide();
        return;
      }

      const rect = data.range.getBoundingClientRect();
      if (!rect || (!rect.width && !rect.height)) {
        hide();
        return;
      }

      const btnWidth = 64;
      const btnHeight = 34;
      const margin = 8;
      const left = Math.min(window.innerWidth - btnWidth - margin, Math.max(margin, rect.right - btnWidth));
      const top = Math.min(window.innerHeight - btnHeight - margin, Math.max(margin, rect.bottom + margin));

      selectionTodoBtn.style.left = `${left}px`;
      selectionTodoBtn.style.top = `${top}px`;
      selectionTodoBtn.style.display = 'block';
      selectionTodoBtn.dataset.selectionText = data.text;
    };

    selectionTodoBtn.addEventListener('click', () => {
      const text = selectionTodoBtn.dataset.selectionText || '';
      addTodoFromSelection(text);
      try {
        window.getSelection()?.removeAllRanges();
      } catch {}
      hide();
    });

    document.addEventListener('mouseup', () => setTimeout(showForCurrentSelection, 0));
    document.addEventListener('keyup', () => setTimeout(showForCurrentSelection, 0));
    document.addEventListener('scroll', hide, true);
    window.addEventListener('resize', hide);
    document.addEventListener('mousedown', (e) => {
      if (selectionTodoBtn.contains(e.target)) return;
      hide();
    });
  }

  // ============ 消息监听 ============
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    switch (message.type) {
      case 'EXTRACT_CONTENT':
        // 侧边栏请求提取页面内容（用于内容反哺）
        const extractedContent = extractContent();
        sendResponse(extractedContent);
        return true;

      case 'EXTRACT_AND_SUMMARIZE':
        // 侧边栏请求提取内容并总结
        const extracted = extractContent();
        if (extracted.content.length < 100) {
          showToast('页面内容不足，无法分析');
          sendResponse({ success: false, error: '页面内容不足' });
        } else {
          // 发送内容到 background 进行总结
          safeSendMessage({
            type: 'SUMMARIZE',
            content: extracted.content,
            pageTitle: extracted.title,
            pageUrl: extracted.url
          });
          sendResponse({ success: true });
        }
        return true;
        
      case 'TRIGGER_SUMMARIZE':
        // 从 popup 触发，直接打开侧边栏
        openSidepanelDirectly();
        sendResponse({ success: true });
        return true;

      case 'SHOW_TOAST':
        showToast(message.message || '');
        sendResponse({ success: true });
        return true;
        
      case 'SHOW_CLICK_ICON_HINT':
        // 显示提示用户点击扩展图标
        showToast(message.message || '请点击扩展图标打开侧边栏');
        sendResponse({ success: true });
        return true;
        
      default:
        // 未知消息类型，不处理
        return false;
    }
  });

  // ============ 初始化 ============
  
  // 检查是否为不支持的页面类型
  function isUnsupportedPage(url) {
    if (!url) return true;
    if (url.startsWith('file://')) return true;
    if (url.startsWith('chrome://')) return true;
    if (url.startsWith('chrome-extension://')) return true;
    if (url.startsWith('edge://')) return true;
    if (url.startsWith('about:')) return true;
    return false;
  }
  
  function init() {
    // 不支持的页面不显示浮标
    if (isUnsupportedPage(location.href)) {
      console.log('[ContentScript] Unsupported page, skipping floating button');
      return;
    }
    
    createFloatingButton();
    initSelectionTodo();
    
    // 检查是否需要自动打开侧边栏（从 hotnews 网站跳转过来）
    const autoSummarize = document.documentElement.getAttribute('data-hotnews-auto-summarize');
    if (autoSummarize === 'pending') {
      document.documentElement.removeAttribute('data-hotnews-auto-summarize');
      console.log('[ContentScript] Auto-summarize triggered from hotnews');
      // 由于 Chrome 限制，sidePanel.open() 需要用户手势
      // 显示提示让用户点击浮动按钮
      setTimeout(() => {
        showAutoSummarizeHint();
      }, 800);
    }
    
    const handleViewportChange = () => {
      cachedSafeAreaInsets = null;
      const container = document.getElementById('cs-floating-container');
      if (!container) return;
      const margins = getMinMargins();
      
      safeSendMessage({ type: 'GET_CONFIG' }, (response) => {
        const pos = response?.config?.buttonPosition;
        if (pos?.userDragged) {
          normalizePosition(container, pos, margins);
        } else {
          const current = readRightBottomFromRect(container);
          normalizePosition(container, current, margins);
        }
      });
    };
    
    // 加载保存的按钮位置（只有用户拖拽过才应用）
    safeSendMessage({ type: 'GET_CONFIG' }, (response) => {
      if (response?.config?.buttonPosition?.userDragged) {
        const container = document.getElementById('cs-floating-container');
        const pos = response.config.buttonPosition;
        
        if (container) {
          // 检查是新格式(right/bottom)还是旧格式(x/y)
          if (pos.right !== undefined && pos.bottom !== undefined) {
            // 新格式：使用 right 和 bottom 定位
            normalizePosition(container, pos, getMinMargins());
          } else if (pos.x !== undefined && pos.y !== undefined) {
            // 旧格式：转换为 right/bottom 并保存
            const right = window.innerWidth - pos.x - 40; // 40 是按钮宽度
            const bottom = window.innerHeight - pos.y - 40; // 40 是按钮高度
            normalizePosition(container, { right: Math.max(20, right), bottom: Math.max(100, bottom) }, getMinMargins());
            
            // 保存为新格式
            const margins = getMinMargins();
            const bounds = getBoundsForElement(container, margins);
            const normalized = readRightBottomFromRect(container);
            const clampedRight = clampNumber(normalized.right, bounds.rightMin, bounds.maxRight);
            const clampedBottom = clampNumber(normalized.bottom, bounds.bottomMin, bounds.maxBottom);
            const dock = clampedRight <= bounds.maxRight / 2 ? 'right' : 'left';
            const dockedRight = dock === 'right' ? bounds.rightMin : bounds.maxRight;
            applyPosition(container, dockedRight, clampedBottom);
            safeSendMessage({
              type: 'SAVE_BUTTON_POSITION',
              position: { right: dockedRight, bottom: clampedBottom, dock, userDragged: true }
            });
          }
        }
      }
      // 否则使用 CSS 默认位置 (right: 20px, bottom: 100px)
    });
    
    // 监听视口大小变化，确保按钮不会超出可见区域
    window.addEventListener('resize', handleViewportChange);
    window.addEventListener('orientationchange', handleViewportChange);
  }
  
  // 等待 DOM 加载完成
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
  
})();
